// ===== Everyday ease: dialogs, undo and Trash, recent documents, shortcuts, dropping files anywhere,
// sorting and selecting in the Library, folding Settings cards, the shared-library status, and a first-run guide =====
const app = () => window.citekeepApp || {};
async function uxGet(k) { try { return (await app().getSettings())[k]; } catch (e) { return undefined; } }
async function uxSet(k, v) { try { await app().setSetting(k, v); } catch (e) {} }

// ---------- dialogs in Citekeep's own style ----------
function ckDialog(message, opts) {
  opts = opts || {};
  if (window.__ckAutoAnswer !== undefined) return Promise.resolve(opts.prompt ? (window.__ckAutoAnswer === false ? null : String(window.__ckAutoText || opts.value || "")) : !!window.__ckAutoAnswer);   // for tests
  return new Promise(res => {
    const box = document.createElement("div");
    box.className = "modal-back"; box.dataset.esc = "1";
    const lines = String(message).split(/\n\n+/).map(p => `<p style="margin:0 0 10px;white-space:pre-line">${esc(p)}</p>`).join("");
    box.innerHTML = `<div class="modal" role="dialog" aria-modal="true" style="max-width:480px">${opts.title ? `<h2 style="margin:0 0 8px">${esc(opts.title)}</h2>` : ""}${lines}
      ${opts.prompt ? `<input type="text" id="ckDlgIn" value="${esc(opts.value || "")}" style="width:100%;margin-bottom:10px">` : ""}
      <div class="row" style="justify-content:flex-end;margin-top:4px">${opts.alert ? "" : `<button class="btn" data-ckno>${esc(opts.cancel || "Cancel")}</button>`}<button class="btn ${opts.danger ? "danger armed" : "primary"}" data-ckok>${esc(opts.ok || "OK")}</button></div></div>`;
    const prev = document.activeElement;
    const done = v => { box.remove(); document.removeEventListener("keydown", key, true); try { prev && prev.focus(); } catch (e) {} res(v); };
    const ok = () => done(opts.prompt ? box.querySelector("#ckDlgIn").value : true);
    const no = () => done(opts.prompt ? null : (opts.alert ? true : false));
    const key = e => { if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); no(); } else if (e.key === "Enter" && (opts.prompt || document.activeElement === box.querySelector("[data-ckok]") || !box.contains(document.activeElement))) { e.preventDefault(); ok(); } };
    document.addEventListener("keydown", key, true);
    box.querySelector("[data-ckok]").onclick = ok;
    const n = box.querySelector("[data-ckno]"); if (n) n.onclick = no;
    box.addEventListener("click", e => { if (e.target === box) no(); });
    document.body.appendChild(box);
    setTimeout(() => (box.querySelector("#ckDlgIn") || box.querySelector("[data-ckok]")).focus(), 30);
  });
}
const ckConfirm = (m, o) => ckDialog(m, o);
const ckPrompt = (m, value, o) => ckDialog(m, Object.assign({ prompt: true, value }, o));
const ckAlert = (m, o) => ckDialog(m, Object.assign({ alert: true }, o));

// ---------- a message with a button (Undo) ----------
function toastAction(msg, label, fn, ms) {
  const t = $("#toast"); if (!t) return;
  t.innerHTML = `<span>${esc(msg)}</span> <button type="button" style="margin-left:10px;background:none;border:1px solid currentColor;color:inherit;border-radius:4px;padding:2px 10px;cursor:pointer;font:inherit">${esc(label)}</button>`;
  t.hidden = false; clearTimeout(toast._t);
  t.querySelector("button").onclick = async () => { t.hidden = true; await fn(); };
  toast._t = setTimeout(() => (t.hidden = true), ms || 9000);
}

// ---------- Trash: deleted references are kept 30 days ----------
const TRASH_DAYS = 30;
async function trashRead() { try { const t = JSON.parse((await app().readText("trash.json")) || "[]"); return Array.isArray(t) ? t : []; } catch (e) { return []; } }
async function trashWrite(list) { const cut = Date.now() - TRASH_DAYS * 864e5; try { await app().writeText("trash.json", JSON.stringify(list.filter(x => x.at > cut))); } catch (e) {} }
{ const del = deleteItem; deleteItem = async function (id) {
  const it = items.find(x => x.id === id);
  if (it) { const t = (await trashRead()).filter(x => x.item.id !== id); t.unshift({ item: syncClean ? syncClean(it) : it, at: Date.now() }); await trashWrite(t); }
  return del(id);
}; }
async function restoreFromTrash(ids) {
  const t = await trashRead(); let n = 0;
  for (const id of ids) { const e = t.find(x => x.item.id === id); if (!e) continue; const it = Object.assign({}, e.item); delete it.updated; await saveItem(it); n++; }
  await trashWrite(t.filter(x => !ids.includes(x.item.id)));
  return n;
}
function toastUndoDelete(list) {
  const ids = list.map(x => x.id);
  toastAction(list.length === 1 ? "Reference moved to Trash" : `${list.length} references moved to Trash`, "Undo", async () => { const n = await restoreFromTrash(ids); updateTrashLink(); if (n) { if (ids.length === 1) selectedId = ids[0]; renderAll(); toast(n === 1 ? "Restored" : `${n} restored`); } });
}
async function openTrash() {
  const t = await trashRead();
  const box = document.createElement("div"); box.className = "modal-back"; box.dataset.esc = "1";
  const draw = list => {
    box.innerHTML = `<div class="modal" role="dialog" aria-modal="true" style="max-width:640px;max-height:84vh;overflow:auto"><div class="row" style="justify-content:space-between"><h2 style="margin:0">Trash</h2><button class="copy" data-x>Close</button></div>
      <p class="note">Deleted references stay here for ${TRASH_DAYS} days, then go for good.</p>
      ${list.length ? `<ul class="stylist" style="padding-left:0;list-style:none">${list.map(x => `<li style="border-top:1px solid var(--line);padding:8px 0"><div style="font-family:var(--serif)">${formatReference(x.item)}</div><div class="row" style="margin-top:4px"><span class="note">Deleted ${esc(new Date(x.at).toLocaleDateString())}</span><button class="btn" data-restore="${esc(x.item.id)}">Restore</button><button class="copy" data-forever="${esc(x.item.id)}">Delete forever</button></div></li>`).join("")}</ul>
        <div class="row" style="justify-content:space-between;margin-top:8px"><button class="btn" data-all>Restore all</button><button class="btn danger" data-empty>Empty Trash</button></div>` : `<div class="empty"><b>Trash is empty</b></div>`}</div>`;
  };
  draw(t); document.body.appendChild(box);
  box.addEventListener("click", async e => {
    if (e.target === box || e.target.closest("[data-x]")) { box.remove(); return; }
    const r = e.target.closest("[data-restore]"), f = e.target.closest("[data-forever]");
    if (r) { await restoreFromTrash([r.dataset.restore]); renderAll(); draw(await trashRead()); toast("Restored"); updateTrashLink(); }
    if (f) { const l = (await trashRead()).filter(x => x.item.id !== f.dataset.forever); await trashWrite(l); draw(l); updateTrashLink(); }
    if (e.target.closest("[data-all]")) { const l = await trashRead(); const n = await restoreFromTrash(l.map(x => x.item.id)); renderAll(); draw([]); toast(`${n} restored`); updateTrashLink(); }
    if (e.target.closest("[data-empty]")) { if (!(await ckConfirm("Delete everything in the Trash for good?", { ok: "Empty Trash", danger: true }))) return; await trashWrite([]); draw([]); updateTrashLink(); }
  });
}
async function updateTrashLink() { const b = $("#trashBtn"); if (b) { const n = (await trashRead()).length; b.textContent = n ? `Trash (${n})` : "Trash"; } }

// ---------- recent documents ----------
async function recentList() { try { const r = JSON.parse((await uxGet("recentDocs")) || "[]"); return Array.isArray(r) ? r : []; } catch (e) { return []; } }
async function rememberDoc(path) { const name = path.split(/[\\/]/).pop(); const r = (await recentList()).filter(x => x.path !== path); r.unshift({ path, name, at: Date.now() }); await uxSet("recentDocs", JSON.stringify(r.slice(0, 8))); renderRecent(); }
async function fileFromPath(path) { const r = await app().readDoc(path); return new File([r.data], path.split(/[\\/]/).pop(), { lastModified: r.mtime || Date.now() }); }
async function openPaths(paths) {
  const files = [];
  for (const p of paths) { try { files.push(await fileFromPath(p)); await rememberDoc(p); } catch (e) { toast("Couldn't open " + p.split(/[\\/]/).pop() + ". It may have been moved or renamed."); } }
  if (files.length) { showTab("check"); openDocs(files); }
}
async function pickAndOpen() {
  if (!app().pickDocs) { $("#docIn").click(); return; }
  const paths = await app().pickDocs(); if (paths === null) { $("#docIn").click(); return; }
  if (paths.length) openPaths(paths);
}
async function renderRecent() {
  const drop = $("#drop"); if (!drop || !app().pickDocs) return;
  let box = $("#recentDocs"); if (!box) { box = document.createElement("div"); box.id = "recentDocs"; box.style.margin = "10px 0 0"; drop.after(box); }
  const r = await recentList();
  if (!r.length) { box.innerHTML = ""; return; }
  const when = t => { const d = new Date(t), now = new Date(); return d.toDateString() === now.toDateString() ? d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }) : d.toLocaleDateString([], { month: "short", day: "numeric" }); };
  box.innerHTML = `<h3 style="margin:6px 0 6px">Recent documents</h3><div style="display:grid;gap:6px">${r.map((x, i) => `<div class="row" style="justify-content:space-between;border:1px solid var(--line);border-radius:var(--r);padding:6px 10px;background:var(--surface)" data-ri="${i}">
      <span style="min-width:0;overflow-wrap:anywhere"><b style="font-weight:500">${esc(x.name)}</b> <span class="note">checked ${esc(when(x.at))}</span><span class="note" data-newer></span></span>
      <span class="row" style="gap:4px"><button class="btn" data-again="${i}">Check again</button><button class="copy" data-forget="${i}" aria-label="Remove from the list" title="Remove from the list">✕</button></span></div>`).join("")}</div>`;
  box.querySelectorAll("[data-again]").forEach(b => b.onclick = () => openPaths([r[+b.dataset.again].path]));
  box.querySelectorAll("[data-forget]").forEach(b => b.onclick = async () => { const l = (await recentList()).filter(x => x.path !== r[+b.dataset.forget].path); await uxSet("recentDocs", JSON.stringify(l)); renderRecent(); });
  // a newer version of the same file in its folder (Chapter_2_V.42 after V.41)
  r.slice(0, 4).forEach(async (x, i) => {
    try {
      const nw = app().newerSibling ? await app().newerSibling(x.path) : null; if (!nw) return;
      const slot = box.querySelector(`[data-ri="${i}"] [data-newer]`); if (!slot) return;
      slot.innerHTML = ` · newer in the folder: <b style="font-weight:500">${esc(nw.name)}</b> <button class="btn primary" style="margin-left:4px">Check it</button>`;
      slot.querySelector("button").onclick = () => openPaths([nw.path]);
    } catch (e) {}
  });
}

// ---------- adding a paper's references to the library, or not ----------
async function setupDocAdd() {
  const cb = $("#docAdd"); if (!cb) return;
  cb.checked = (await uxGet("docAddRefs")) !== "off";
  cb.onchange = () => uxSet("docAddRefs", cb.checked ? "" : "off");
}

// ---------- Library: sort and select ----------
const SORTS = { author: "Author", newest: "Newest first", oldest: "Oldest first", added: "Recently added", title: "Title" };
var LIB = { sort: "author", select: false, picked: new Set() };
sorted = function () {
  const all = items.map(x => x); assignSuffixes(all);
  const k = sortKey, tk = it => norm(it.title || "").toLowerCase().replace(/^(the|a|an)\s+/, "");
  const by = { author: (a, b) => k(a).localeCompare(k(b)), newest: (a, b) => (+(b.year || 0) - +(a.year || 0)) || k(a).localeCompare(k(b)), oldest: (a, b) => (+(a.year || 9999) - +(b.year || 9999)) || k(a).localeCompare(k(b)), added: (a, b) => (+(b.created || 0) - +(a.created || 0)) || k(a).localeCompare(k(b)), title: (a, b) => tk(a).localeCompare(tk(b)) }[LIB.sort] || ((a, b) => k(a).localeCompare(k(b)));
  return all.sort(by);
};
{ const rl = renderList; renderList = function () {
  rl();
  const list = $("#list"); if (!list) return;
  for (const b of list.querySelectorAll(".item[data-id]")) {
    const it = items.find(x => x.id === b.dataset.id); const c = b.querySelector(".cite");
    if (it && (it.alt || []).length && c && !c.querySelector(".pill.warn")) c.insertAdjacentHTML("beforeend", ` <span class="pill warn" style="font-size:10px;padding:0 6px">2 versions</span>`);
    if (LIB.select) { b.style.display = "grid"; b.style.gridTemplateColumns = "22px minmax(0,1fr)"; b.style.columnGap = "6px"; b.insertAdjacentHTML("afterbegin", `<input type="checkbox" data-pick aria-label="Select" ${LIB.picked.has(b.dataset.id) ? "checked" : ""} style="grid-row:span 3;margin-top:3px">`); }
  }
  renderBulkBar();
}; }
function renderBulkBar() {
  let bar = $("#bulkBar"); const list = $("#list"); if (!list) return;
  if (!LIB.select) { if (bar) bar.remove(); return; }
  if (!bar) { bar = document.createElement("div"); bar.id = "bulkBar"; bar.className = "row"; bar.style.cssText = "padding:8px 12px;border-bottom:1px solid var(--line);background:var(--accent-soft);gap:6px"; list.before(bar); }
  for (const id of [...LIB.picked]) if (!items.some(x => x.id === id)) LIB.picked.delete(id);
  const n = LIB.picked.size;
  bar.innerHTML = `<b style="font-weight:500">${n} selected</b><button class="copy" data-b="all">Select all shown</button>${n ? `<button class="copy" data-b="none">Clear</button><button class="btn" data-b="tag">Tag…</button><button class="btn" data-b="untag">Remove tag…</button><button class="btn danger" data-b="del">Delete</button>` : ""}<button class="copy" data-b="done" style="margin-left:auto">Done</button>`;
}
async function bulk(action) {
  const picked = items.filter(x => LIB.picked.has(x.id));
  if (action === "all") { for (const it of sorted().filter(matches)) LIB.picked.add(it.id); renderList(); return; }
  if (action === "none") { LIB.picked.clear(); renderList(); return; }
  if (action === "done") { LIB.select = false; LIB.picked.clear(); renderList(); updateSelectBtn(); return; }
  if (!picked.length) return;
  if (action === "tag" || action === "untag") {
    const tag = ((await ckPrompt(action === "tag" ? `Add a tag to the ${picked.length} selected references. Use / for folders, like Dissertation/Chapter 2.` : `Remove which tag from the ${picked.length} selected references?`, "")) || "").trim().replace(/\s*\/\s*/g, "/");
    if (!tag) return; let n = 0;
    for (const it of picked) { const tags = new Set(it.tags || []); if (action === "tag" ? !tags.has(tag) : tags.has(tag)) { action === "tag" ? tags.add(tag) : tags.delete(tag); await saveItem(Object.assign({}, it, { tags: [...tags] })); n++; } }
    renderAll(); toast(`${action === "tag" ? "Tagged" : "Untagged"} ${n} reference${n === 1 ? "" : "s"}`); return;
  }
  if (action === "del") {
    if (!(await ckConfirm(`Move ${picked.length} reference${picked.length === 1 ? "" : "s"} to the Trash? You can restore them for ${TRASH_DAYS} days.`, { ok: "Move to Trash", danger: true }))) return;
    for (const it of picked) await deleteItem(it.id);
    LIB.picked.clear(); if (picked.some(x => x.id === selectedId)) selectedId = null;
    renderAll(); toastUndoDelete(picked); updateTrashLink();
  }
}
function updateSelectBtn() { const b = $("#selBtn"); if (b) b.textContent = LIB.select ? "Selecting…" : "Select"; }

// ---------- first run ----------
{ const rd = renderDetail; renderDetail = function () {
  rd();
  if (items.length || editing || (typeof loaded !== "undefined" && !loaded)) return;
  const d = $("#detail"); if (!d) return;
  d.innerHTML = `<div class="detail"><h2 style="margin:0">Start here</h2><p class="note" style="margin:0 0 6px">Three steps, then Citekeep is ready. Each one can be changed later in Settings.</p>
    <div style="display:grid;gap:10px">
      <div class="card"><h3 style="margin:0">1. Open a paper</h3><p class="note" style="margin:0">A Word file with a reference list. Its references go into your library, and its citations are checked.</p><div class="row"><button class="btn primary" data-start="open">Open a Word document</button></div></div>
      <div class="card"><h3 style="margin:0">2. Your citation style</h3><select data-start="style" style="max-width:320px">${Object.keys(STYLES).map(k => `<option value="${k}" ${k === CITE.style ? "selected" : ""}>${esc(STYLES[k].name)}</option>`).join("")}</select></div>
      <div class="card"><h3 style="margin:0">3. Your PDFs (optional)</h3><p class="note" style="margin:0">Point Citekeep to the folder that holds your articles. File names don't matter.</p><div class="row"><button class="btn" data-start="pdfs">Choose PDF folder</button></div></div>
    </div>
    <p class="note">Or add a reference by hand with <b>New</b>, or paste a DOI into <b>Look up</b>. The <b>Help</b> tab explains everything in short cards.</p></div>`;
  d.querySelector('[data-start="open"]').onclick = pickAndOpen;
  d.querySelector('[data-start="style"]').onchange = async e => { const s = $("#citeStyleSel"); CITE.style = e.target.value; if (s) s.value = CITE.style; await uxSet("citeStyle", CITE.style); if (typeof showStyleInTitle === "function") showStyleInTitle(); toast("Citation style: " + STYLES[CITE.style].name); };
  d.querySelector('[data-start="pdfs"]').onclick = () => { const b = $("#pdfConnect"); if (b) b.click(); else showTab("settings"); };
}; }

// ---------- folding Settings cards ----------
var FOLD = new Set();
function applyFolds() {
  for (const c of document.querySelectorAll("#settingsCols > .card")) {
    c.classList.toggle("folded", FOLD.has(c.id));
    const h = c.querySelector(":scope > h3"); if (h) { h.setAttribute("role", "button"); h.tabIndex = 0; h.setAttribute("aria-expanded", String(!FOLD.has(c.id))); h.title = FOLD.has(c.id) ? "Show" : "Fold away"; }
  }
}

// ---------- the shared-library status ----------
var SYNCST = { checked: 0, merged: 0, mergedN: 0 };
function syncStatusText() {
  if (!(DATA.info && DATA.info.elsewhere)) return null;
  const ago = t => { const m = Math.round((Date.now() - t) / 60000); return m < 1 ? "just now" : m === 1 ? "1 min ago" : m < 60 ? m + " min ago" : new Date(t).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }); };
  let s = "Shared library · synced " + (SYNCST.checked ? ago(SYNCST.checked) : "at start");
  if (SYNCST.merged && Date.now() - SYNCST.merged < 6 * 3600e3) s += ` · ${SYNCST.mergedN} change${SYNCST.mergedN === 1 ? "" : "s"} from your other computer ${ago(SYNCST.merged)}`;
  return s;
}
function showSyncStatus() { const t = syncStatusText(); if (t) { setStatus(true, t); const el = $("#storeText"); if (el) el.title = "Your library is in " + (DATA.info.dir || "a shared folder") + ". Citekeep checks it for changes from your other computer every 15 seconds."; } }
{ const sr = syncRun; syncRun = async function (why) {
  const before = items.length ? syncStable(items.map(syncClean)) : "";
  await sr(why);
  SYNCST.checked = Date.now();
  if (why !== "save" && why !== "close" && items.length && syncStable(items.map(syncClean)) !== before) { SYNCST.merged = Date.now(); SYNCST.mergedN = Math.max(1, (SYNCST._n || 1)); }
  showSyncStatus();
}; }
{ const tst = toast; toast = function (msg) { const m = String(msg).match(/^(?:From your other computer|Merged): (.*)\.$/); if (m) { SYNCST._n = m[1].split(",").reduce((n, p) => n + (parseInt(p, 10) || 0), 0); } return tst(msg); }; }
setInterval(showSyncStatus, 60000);

// ---------- keyboard shortcuts ----------
const TAB_ORDER = ["write", "library", "check", "bib", "matrix", "io", "settings", "help"];
document.addEventListener("keydown", e => {
  const typing = /^(INPUT|TEXTAREA|SELECT)$/.test((document.activeElement || {}).tagName || "") || (document.activeElement && document.activeElement.isContentEditable);
  const modal = document.querySelector(".modal-back");
  if (e.key === "Escape" && modal && modal.dataset.esc) { const x = modal.querySelector("[data-x], [data-ckno]"); if (x) x.click(); else modal.remove(); e.preventDefault(); return; }
  if (modal) return;
  const ctrl = e.ctrlKey || e.metaKey;
  if (ctrl && !e.shiftKey && !e.altKey) {
    const k = e.key.toLowerCase();
    if (k === "f") { e.preventDefault(); showTab("library"); const q = $("#q"); q.focus(); q.select(); return; }
    if (k === "o") { e.preventDefault(); pickAndOpen(); return; }
    if (k === "n") { e.preventDefault(); showTab("library"); $("#newBtn").click(); return; }
    if (/^[1-8]$/.test(k)) { e.preventDefault(); showTab(TAB_ORDER[+k - 1]); return; }
  }
  if (!typing && !ctrl && (e.key === "ArrowDown" || e.key === "ArrowUp") && !$("#tab-library").hidden && !editing) {
    const shown = [...document.querySelectorAll("#list .item[data-id]")]; if (!shown.length) return;
    e.preventDefault();
    let i = shown.findIndex(b => b.dataset.id === selectedId);
    i = i < 0 ? 0 : Math.max(0, Math.min(shown.length - 1, i + (e.key === "ArrowDown" ? 1 : -1)));
    selectedId = shown[i].dataset.id; renderList(); renderDetail();
    const nb = document.querySelector(`#list .item[data-id="${selectedId}"]`); if (nb) nb.scrollIntoView({ block: "nearest" });
  }
});

// ---------- drop a Word file anywhere ----------
const hasFiles = e => e.dataTransfer && [...(e.dataTransfer.types || [])].includes("Files");
document.addEventListener("dragover", e => { if (hasFiles(e) && !(e.target.closest && e.target.closest("#drop"))) { e.preventDefault(); e.dataTransfer.dropEffect = "copy"; } });
document.addEventListener("drop", e => {
  if (!hasFiles(e) || (e.target.closest && (e.target.closest("#drop") || e.target.closest("#chatRoot")))) return;
  e.preventDefault();
  const fs = [...e.dataTransfer.files];
  const docs = fs.filter(f => /\.docx$/i.test(f.name)), pdfs = fs.filter(f => /\.pdf$/i.test(f.name));
  if (docs.length) { showTab("check"); openDocs(docs); }
  else if (pdfs.length && typeof addFromPdfFiles === "function") { showTab("library"); addFromPdfFiles(pdfs); }
  else toast("Drop a Word document (.docx) to check it, or PDFs to add them to your library.");
});

// ---------- wiring ----------
(function () {
  const go = async () => {
    // Library: sort, select and Trash
    const hdr = $("#tab-library .pane-h");
    if (hdr && !$("#libSort")) {
      const fRow = $("#fType") && $("#fType").parentElement;
      LIB.sort = SORTS[await uxGet("libSort")] ? await uxGet("libSort") : "author";
      fRow.insertAdjacentHTML("beforeend", `<select id="libSort" aria-label="Sort by">${Object.keys(SORTS).map(k => `<option value="${k}" ${k === LIB.sort ? "selected" : ""}>${esc(SORTS[k])}</option>`).join("")}</select>`);
      $("#libSort").onchange = e => { LIB.sort = e.target.value; uxSet("libSort", LIB.sort); renderList(); };
      const tools = $("#dupBtn") && $("#dupBtn").parentElement;
      if (tools) tools.insertAdjacentHTML("beforeend", `<button class="copy" id="selBtn">Select</button><button class="copy" id="trashBtn">Trash</button>`);
      $("#selBtn").onclick = () => { LIB.select = !LIB.select; if (!LIB.select) LIB.picked.clear(); updateSelectBtn(); renderList(); };
      $("#trashBtn").onclick = openTrash;
      $("#list").addEventListener("click", e => { const cb = e.target.closest("[data-pick]"); if (!cb) return; e.stopPropagation(); const id = cb.closest(".item").dataset.id; cb.checked ? LIB.picked.add(id) : LIB.picked.delete(id); renderBulkBar(); }, true);
      hdr.parentElement.addEventListener("click", e => { const b = e.target.closest("#bulkBar [data-b]"); if (b) bulk(b.dataset.b); });
      updateTrashLink();
    }
    // opening documents through Citekeep, so they can be listed as recent
    const drop = $("#drop");
    if (drop && app().pickDocs) {
      drop.addEventListener("click", e => { if (e.target.closest("#recentDocs")) return; e.preventDefault(); pickAndOpen(); });
      const ob = $("#openDocBtn"); if (ob) { const nb = ob.cloneNode(true); ob.replaceWith(nb); nb.onclick = () => { showTab("check"); pickAndOpen(); }; }
      renderRecent();
    }
    setupDocAdd();
    // Settings cards fold
    try { FOLD = new Set(JSON.parse((await uxGet("settingsFolded")) || "[]")); } catch (e) {}
    const cols = $("#settingsCols");
    if (cols) {
      cols.addEventListener("click", e => {
        const h = e.target.closest(".card > h3"); if (!h || h.parentElement.parentElement !== cols) return;
        const c = h.parentElement; FOLD.has(c.id) ? FOLD.delete(c.id) : FOLD.add(c.id); applyFolds(); uxSet("settingsFolded", JSON.stringify([...FOLD]));
      });
      cols.addEventListener("keydown", e => { if ((e.key === "Enter" || e.key === " ") && e.target.matches("#settingsCols > .card > h3")) { e.preventDefault(); e.target.click(); } });
      new MutationObserver(ms => { if (ms.some(m => m.target !== cols)) applyFolds(); }).observe(cols, { childList: true, subtree: true });
      new MutationObserver(applyFolds).observe(cols, { childList: true });
      applyFolds();
    }
    // titles for the shortcuts
    const tip = (sel, t) => { const el = $(sel); if (el && !el.title) el.title = t; };
    tip("#q", "Search (Ctrl+F)"); tip("#newBtn", "New reference (Ctrl+N)"); tip("#openDocBtn", "Open a Word document (Ctrl+O)");
    $$("nav.tabs button").forEach((b, i) => { if (!b.title) b.title = `${b.textContent} (Ctrl+${i + 1})`; });
    setTimeout(showSyncStatus, 4000);
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", go); else setTimeout(go, 0);
})();

// ---------- what's new: the changelog inside Citekeep ----------
function mdInline(s) { return esc(s).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/\[([^\]]+)\]\((https?:[^)]+)\)/g, "$1"); }
function changelogHtml(md, onlyFirst) {
  const parts = String(md || "").split(/\n(?=## )/).filter(p => p.startsWith("## "));
  const one = p => {
    const lines = p.split("\n"); let h = `<h4 style="margin:10px 0 4px;font-family:var(--serif)">${mdInline(lines[0].slice(3))}</h4><ul class="stylist" style="margin:0">`; let inSub = false;
    for (const l of lines.slice(1)) {
      if (/^  - /.test(l)) { if (!inSub) { h = h.replace(/<\/li>$/, "") + `<ul class="stylist" style="margin:2px 0">`; inSub = true; } h += `<li>${mdInline(l.slice(4))}</li>`; }
      else if (/^- /.test(l)) { if (inSub) { h += "</ul></li>"; inSub = false; } h += `<li>${mdInline(l.slice(2))}</li>`; }
    }
    return h + (inSub ? "</ul></li>" : "") + "</ul>";
  };
  return onlyFirst ? one(parts[0] || "") : parts.map(one).join("");
}
function renderWhatsNew() {
  const g = $("#tab-help .guide"); if (!g || typeof CHANGELOG_MD === "undefined" || $("#whatsNew")) return;
  const c = document.createElement("div"); c.className = "card"; c.id = "whatsNew";
  const parts = CHANGELOG_MD.split(/\n(?=## )/).filter(p => p.startsWith("## "));
  c.innerHTML = `<h3>What's new</h3>${changelogHtml(parts[0])}<details style="margin-top:8px"><summary class="note" style="cursor:pointer">Earlier versions</summary>${changelogHtml(parts.slice(1).join("\n"))}</details>`;
  g.insertBefore(c, g.firstChild);
}
async function whatsNewAfterUpdate() {
  let cur = 0; try { cur = parseInt(await app().appVersion(), 10) || 0; } catch (e) {}
  if (!cur) return;
  const seen = parseInt(await uxGet("seenVersion"), 10) || 0;
  await uxSet("seenVersion", String(cur));
  if (!seen || seen >= cur) return;   // a fresh install, or nothing new
  toastAction(`Updated to V${cur}`, "See what's new", async () => { showTab("help"); const w = $("#whatsNew"); if (w) { w.scrollIntoView({ behavior: "smooth", block: "start" }); w.style.outline = "2px solid var(--accent)"; setTimeout(() => (w.style.outline = ""), 2500); } }, 15000);
}
(function () { const go = () => { renderWhatsNew(); setTimeout(whatsNewAfterUpdate, 2500); }; if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", go); else setTimeout(go, 0); })();
