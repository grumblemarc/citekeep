// ===== Source kinds: what kind of work each reference is, the same for everyone.
// Citekeep suggests a kind only from evidence: Crossref's record for the DOI first, then the reference itself. You confirm it.
// Separately, your own categories: none built in, never suggested, set only by you.
const SRC_KINDS = [
  { id: "journal", name: "Scholarly journal article", short: "Journal" },
  { id: "book", name: "Book or book chapter", short: "Book" },
  { id: "thesis", name: "Dissertation or thesis", short: "Thesis" },
  { id: "conf", name: "Conference paper", short: "Conference" },
  { id: "report", name: "Research report or working paper", short: "Report" },
  { id: "gov", name: "Government or school-system document", short: "Government" },
  { id: "law", name: "Law or policy", short: "Law" },
  { id: "web", name: "Web page or news", short: "Web" },
];
function kindName(id) { const k = id && SRC_KINDS.find(x => x.id === id); return k ? k.name : ""; }
function kindShort(id) { const k = id && SRC_KINDS.find(x => x.id === id); return k ? k.short : ""; }
function kindOrder(id) { const i = SRC_KINDS.findIndex(x => x.id === id); return i < 0 ? 999 : i; }
function byKindOrder(list) { return list.slice().sort((a, b) => kindOrder(a.srcKind) - kindOrder(b.srcKind)); }
function kindOptions(cur, blank) { return (blank ? `<option value="">${esc(blank)}</option>` : "") + SRC_KINDS.map(k => `<option value="${k.id}" ${k.id === cur ? "selected" : ""}>${esc(k.name)}</option>`).join(""); }

// ---- Crossref's record of each DOI: the publisher's own statement of what the work is
const CR_KIND = { "journal-article": "journal", "book": "book", "monograph": "book", "edited-book": "book", "reference-book": "book", "book-chapter": "book", "book-section": "book", "book-part": "book", "book-set": "book", "dissertation": "thesis", "proceedings-article": "conf", "report": "report", "report-component": "report", "report-series": "report", "posted-content": "report" };
const CR_WORDS = { "journal-article": "a journal article", "book": "a book", "monograph": "a book", "edited-book": "an edited book", "reference-book": "a reference book", "book-chapter": "a book chapter", "book-section": "a book section", "book-part": "part of a book", "book-set": "a book set", "dissertation": "a dissertation", "proceedings-article": "a conference paper", "report": "a report", "report-component": "part of a report", "report-series": "a report series", "posted-content": "a working paper or preprint" };
var CRTYPE = null, CR_TRIED = new Set(); // doi -> { t: type, j: journal title }
async function crLoad() { if (CRTYPE) return CRTYPE; try { CRTYPE = JSON.parse((await window.citekeepApp.readText("crossref-types.json")) || "{}"); } catch (e) { CRTYPE = {}; } return CRTYPE; }
async function crSave() { try { await window.citekeepApp.writeText("crossref-types.json", JSON.stringify(CRTYPE)); } catch (e) {} }
// look up the DOIs not yet known, 40 at a time; returns how many Crossref couldn't be reached for
async function crCheck(list, onProgress) {
  await crLoad();
  const dois = [...new Set(list.map(i => normDoiK(i.doi)).filter(d => d && !CRTYPE[d]))];
  let failed = 0, done = 0;
  for (let i = 0; i < dois.length; i += 40) {
    const part = dois.slice(i, i + 40);
    try {
      const r = await fetch("https://api.crossref.org/works?rows=40&select=DOI,type,container-title&filter=" + encodeURIComponent(part.map(d => "doi:" + d).join(",")));
      if (!r.ok) throw new Error(r.status);
      const j = await r.json();
      const got = new Set();
      for (const w of (j.message && j.message.items) || []) { const d = normDoiK(w.DOI); got.add(d); CRTYPE[d] = { t: w.type || "", j: (w["container-title"] || [])[0] || "" }; }
      for (const d of part) if (!got.has(d)) CRTYPE[d] = { t: "", none: true }; // Crossref has no record (DataCite, mEDRA, or a typo)
    } catch (e) { failed += part.length; }
    done += part.length; if (onProgress) onProgress(done, dois.length);
  }
  if (dois.length) await crSave();
  return failed;
}
function normDoiK(d) { return String(d || "").trim().replace(/^https?:\/\/(dx\.)?doi\.org\//i, "").replace(/^doi:\s*/i, "").replace(/[.,;\]]+$/, "").toLowerCase(); }

// ---- the evidence, in order; each suggestion says what it rests on
const GOV_HOST = /(^|\.)(gov|mil)$|\.gov\.[a-z]{2}$|(^|\.)k12\.[a-z]{2}\.us$|(^|\.)state\.[a-z]{2}\.us$|(^|\.)knoxschools\.org$|(^|\.)tnreportcard\.org$/i;
const REPO_HOST = /(^|\.)(eric|ies)\.ed\.gov$/i; // libraries of reports from many publishers: the address says nothing about the source
const GOV_ORG = /\b(public schools|county schools|city schools|school district|school system|board of education|department of education|state board|general assembly|legislature|governor|comptroller|house of representatives|senate|congress|committee on|national center for education statistics)\b|^(knox county|tennessee|state of|u\.? ?s\.? department|city of)\b/i;
const NEWS_NAME = /\b(times|post|tribune|herald|gazette|chronicle|news|newsweek|education week|chalkbeat|the atlantic|magazine|npr|associated press)\b/i;
function urlHost(u) { try { return new URL(u).hostname.replace(/^www\./, "").toLowerCase(); } catch (e) { return ""; } }
function refText(it) { return htmlToText(it.refHtml || "").replace(/\s+/g, " ").trim(); }
function suggestKind(it) {
  if (!it || it.srcKind) return null;
  const d = normDoiK(it.doi), cr = d && CRTYPE && CRTYPE[d];
  if (cr && CR_KIND[cr.t]) return { id: CR_KIND[cr.t], why: `Crossref lists its DOI as ${CR_WORDS[cr.t]}${cr.j && cr.t === "journal-article" ? ` in ${cr.j}` : ""}` };
  const txt = refText(it), host = urlHost(it.url), org = ((it.authors || [])[0] || {}).org || "";
  if (it.type === "legal") return { id: "law", why: "it is entered as a law or regulation" };
  const th = txt.match(/\b(doctoral dissertation|dissertation for the degree|master'?s thesis|honou?rs thesis|ph\.? ?d\.? dissertation|ed\.? ?d\.? dissertation)\b/i);
  if (th) return { id: "thesis", why: `the reference says “${th[1]}”` };
  if (host && GOV_HOST.test(host) && !REPO_HOST.test(host)) return { id: "gov", why: `it comes from ${host}` };
  if (org && GOV_ORG.test(org)) return { id: "gov", why: `it is published by ${org}` };
  const f = typeof withApaFields === "function" ? withApaFields(it) : it;
  const viaText = !(it.type === "article" && it.container) && f !== it;
  if (f.type === "article" && f.container && NEWS_NAME.test(f.container) && !f.volume) return { id: "web", why: `it appeared in ${f.container}` };
  if (f.type === "article" && f.container && f.volume) return { id: "journal", why: `the reference names a journal and volume: ${f.container}, ${f.volume}` };
  if (it.type === "chapter" || (f.type === "chapter" && f.editors)) return { id: "book", why: "it is a chapter in an edited book" };
  if (it.type === "book" && !viaText) return { id: "book", why: "it is entered as a book" };
  if (it.isbn) return { id: "book", why: "it has an ISBN" };
  const ed = String(it.url || "").match(/\b(ED\d{5,})\b/i);
  if (ed) return { id: "report", why: `it is ERIC document ${ed[1].toUpperCase()}` };
  if (it.type === "report") return { id: "report", why: "it is entered as a report" };
  const rw = txt.match(/\b(working paper|technical report|final report|research report|policy brief|evaluation brief|research brief|report)\b/i);
  if (rw) return { id: "report", why: `the reference has the words “${rw[1]}”` };
  if (it.type === "webpage") return { id: "web", why: "it is entered as a web page" };
  return null;
}
async function setKind(it, id) { const o = Object.assign({}, it); o.srcKind = id || ""; await saveItem(o); }

// ---- your own categories (none built in)
var ROLES = [];
function roleName(id) { const r = id && ROLES.find(x => x.id === id); return r ? r.name : ""; }
function roleOptions(cur, blank) { return (blank ? `<option value="">${esc(blank)}</option>` : "") + ROLES.map(r => `<option value="${esc(r.id)}" ${r.id === cur ? "selected" : ""}>${esc(r.name)}</option>`).join(""); }
const OLD_BUILTIN = ["research", "contextual", "general"]; // V43's built-in categories, withdrawn in V44
async function loadRoles() {
  try {
    const s = await window.citekeepApp.getSettings();
    const got = (Array.isArray(s.roleList) ? s.roleList : []).filter(r => r && r.id && r.name && !OLD_BUILTIN.includes(r.id));
    ROLES = got;
    if (Array.isArray(s.roleList) && got.length !== s.roleList.length) await saveRoles();
  } catch (e) {}
}
async function saveRoles() { try { await window.citekeepApp.setSetting("roleList", ROLES); } catch (e) {} }
async function setRole(it, id) { const o = Object.assign({}, it); o.role = id || ""; await saveItem(o); }
async function newRole() {
  const name = ((await ckPrompt("Name the new category.", "")) || "").trim().slice(0, 60);
  if (!name) return "";
  const have = ROLES.find(r => r.name.toLowerCase() === name.toLowerCase()); if (have) return have.id;
  let id = "c-" + name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 30); if (id === "c-") id = "c-x"; while (ROLES.some(r => r.id === id)) id += "x";
  ROLES.push({ id, name }); await saveRoles(); renderRolesCard(); return id;
}

// ---- Library: filters, badges, and the kind of file linked
var KINDF = "", ROLEF = "";
{ const m0 = matches; matches = function (it) {
  if (KINDF === "_none" ? it.srcKind : KINDF === "_sug" ? !suggestKind(it) : KINDF && it.srcKind !== KINDF) return false;
  if (ROLEF === "_none" ? it.role : ROLEF && it.role !== ROLEF) return false;
  return m0(it);
}; }
const chipHtml = (t, attr) => ` <span class="chip" ${attr} style="font-size:10px;padding:0 6px">${esc(t)}</span>`;
{ const rl = renderList; renderList = function () {
  rl();
  const list = $("#list"); if (!list) return;
  for (const b of list.querySelectorAll(".item[data-id]")) {
    const it = items.find(x => x.id === b.dataset.id); if (!it) continue;
    const c = b.querySelector(".cite"); if (!c) continue;
    const chip = [...c.querySelectorAll(".chip")].find(x => x.textContent === "PDF");
    if (chip && it.fileKind) chip.textContent = it.fileKind;
    if (kindShort(it.srcKind) && !c.querySelector("[data-kindchip]")) c.insertAdjacentHTML("beforeend", chipHtml(kindShort(it.srcKind), "data-kindchip"));
    if (roleName(it.role) && !c.querySelector("[data-rolechip]")) c.insertAdjacentHTML("beforeend", chipHtml(roleName(it.role), 'data-rolechip').replace('style="', 'style="background:var(--accent-soft);'));
  }
}; }
function renderFilters() {
  const k = $("#fKind");
  if (k) {
    const nSug = items.filter(i => suggestKind(i)).length;
    k.innerHTML = `<option value="">All source kinds</option>${SRC_KINDS.map(x => `<option value="${x.id}">${esc(x.name)} (${items.filter(i => i.srcKind === x.id).length})</option>`).join("")}<option value="_none">Source kind not set (${items.filter(i => !i.srcKind).length})</option>${nSug ? `<option value="_sug">Suggestions to confirm (${nSug})</option>` : ""}`;
    k.value = [...k.options].some(o => o.value === KINDF) ? KINDF : ""; KINDF = k.value;
  }
  const r = $("#fRole");
  if (r) {
    r.hidden = !ROLES.length; if (!ROLES.length) ROLEF = "";
    r.innerHTML = `<option value="">All my categories</option>${ROLES.map(x => `<option value="${esc(x.id)}">${esc(x.name)} (${items.filter(i => i.role === x.id).length})</option>`).join("")}<option value="_none">No category (${items.filter(i => !i.role).length})</option>`;
    r.value = [...r.options].some(o => o.value === ROLEF) ? ROLEF : ""; ROLEF = r.value;
  }
}
{ const ra = renderAll; renderAll = function () { ra(); renderFilters(); }; }

// ---- the reference's own page
{ const rd = renderDetail; renderDetail = function () {
  rd();
  if (editing) return;
  const it = items.find(x => x.id === selectedId); const d = $("#detail .detail"); if (!it || !d) return;
  const sug = suggestKind(it);
  const row = document.createElement("div"); row.id = "kindRow"; row.style.cssText = "display:grid;gap:6px";
  row.innerHTML = `<div class="row"><label class="note" for="kindSel" style="text-transform:none">Source kind</label><select id="kindSel" style="max-width:300px">${kindOptions(it.srcKind, "Not set")}</select>${sug ? `<button class="btn" id="kindOk">Use the suggestion</button>` : ""}</div>
    ${sug ? `<span class="note">Suggested: <b style="font-weight:500">${esc(kindName(sug.id))}</b>, because ${esc(sug.why)}.</span>` : ""}
    <div class="row"><label class="note" for="roleSel" style="text-transform:none">My category</label><select id="roleSel" style="max-width:300px">${roleOptions(it.role, "None")}<option value="_new">New category…</option></select></div>`;
  d.firstElementChild.after(row);
  $("#kindSel").onchange = async e => { await setKind(it, e.target.value); renderAll(); toast(e.target.value ? `Source kind: ${kindName(e.target.value)}` : "Source kind cleared"); };
  const ok = $("#kindOk"); if (ok) ok.onclick = async () => { await setKind(it, sug.id); renderAll(); toast(`Source kind: ${kindName(sug.id)}`); };
  $("#roleSel").onchange = async e => {
    let v = e.target.value;
    if (v === "_new") { v = await newRole(); if (!v) { e.target.value = it.role || ""; return; } }
    await setRole(it, v); renderAll(); toast(v ? `Category: ${roleName(v)}` : "Category cleared");
  };
  // no Crossref record yet for this DOI: look it up, then show the suggestion
  if (!it.srcKind && it.doi && CRTYPE && !CRTYPE[normDoiK(it.doi)] && !CR_TRIED.has(it.id)) { CR_TRIED.add(it.id); crCheck([it]).then(() => { if (selectedId === it.id && !editing) renderDetail(); }); }
}; }

// ---- review every reference without a source kind: Crossref checked first, suggestions filled in, nothing saved until Save
async function openKindReview() {
  const box = document.createElement("div"); box.className = "modal-back"; box.dataset.esc = "1"; box.id = "kindReview";
  box.innerHTML = `<div class="modal" role="dialog" aria-modal="true" style="max-width:860px;max-height:86vh;overflow:auto"><div class="row" style="justify-content:space-between"><h2 style="margin:0">Source kinds</h2><button class="copy" data-x>Close</button></div><p class="note" id="krProg">Checking DOIs with Crossref…</p></div>`;
  document.body.appendChild(box);
  box.addEventListener("click", e => { if (e.target === box || e.target.closest("[data-x]")) box.remove(); });
  const failed = await crCheck(items.filter(i => !i.srcKind), (d, t) => { const p = document.getElementById("krProg"); if (p) p.textContent = `Checking DOIs with Crossref: ${d} of ${t}…`; });
  if (!box.isConnected) return;
  const todo = items.filter(i => !i.srcKind).map(i => ({ it: i, sug: suggestKind(i) }));
  todo.sort((a, b) => (a.sug ? kindOrder(a.sug.id) : 999) - (b.sug ? kindOrder(b.sug.id) : 999) || sortKey(a.it).localeCompare(sortKey(b.it)));
  const nSug = todo.filter(x => x.sug).length;
  const m = box.querySelector(".modal");
  m.innerHTML = `<div class="row" style="justify-content:space-between"><h2 style="margin:0">Source kinds</h2><button class="copy" data-x>Close</button></div>
    <p class="note">${todo.length ? `${todo.length} reference${todo.length === 1 ? " has" : "s have"} no source kind. Citekeep suggested ${nSug} from evidence, shown under each: Crossref's record of the DOI first, otherwise the reference itself. ${todo.length - nSug ? `${todo.length - nSug} had no clear evidence; choose those yourself or leave them for later. ` : ""}Change anything that's wrong and click <b>Save</b>.${failed ? ` Crossref couldn't be reached for ${failed} DOI${failed === 1 ? "" : "s"}; open this again later to check them.` : ""}` : "Every reference has a source kind."}</p>
    ${todo.length - nSug && typeof aiReady === "function" && AI.settings && aiReady() ? `<div class="row" style="margin:0 0 8px"><button class="btn" data-askai>Ask ${esc(aiLabel())} about the ${todo.length - nSug} without evidence</button><span class="note" id="krAi">Do this before making your own choices; the list refreshes afterward. The AI must quote the words that show the kind, or its answer is set aside.</span></div>` : ""}
    ${todo.length ? `<div>${todo.slice(0, 800).map((x, i) => `<div style="display:grid;grid-template-columns:minmax(0,1fr) 250px;gap:10px;align-items:center;border-top:1px solid var(--line);padding:7px 0">
        <div style="min-width:0"><div>${esc(citeForms(x.it).parenthetical)}</div><div class="note" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(x.it.title || refText(x.it))}</div><div class="note">${x.sug ? `${x.sug.ai ? "AI suggestion: " : "Because "}${esc(x.sug.why)}` : "No clear evidence"}</div></div>
        <select data-kr="${i}">${kindOptions(x.sug ? x.sug.id : "", "Decide later")}</select></div>`).join("")}</div>
      <div class="row" style="justify-content:flex-end;margin-top:10px;position:sticky;bottom:-22px;background:var(--surface);padding:8px 0"><button class="copy" data-clear>Clear all choices</button><button class="btn primary" data-save>Save</button></div>` : ""}`;
  m.addEventListener("click", async e => {
    const ask = e.target.closest("[data-askai]");
    if (ask) {
      if (AI.busy) { toast("The AI is busy with another job."); return; }
      const list = todo.filter(x => !x.sug).map(x => x.it);
      AI.busy = "kinds"; AI.ctrl = new AbortController();
      ask.outerHTML = `<button class="btn" data-aistop>Stop</button>`;
      const note = document.getElementById("krAi");
      const r = await aiKinds(list, (d, t) => { if (note) note.textContent = `Asking ${aiLabel()}: ${d} of ${t}…`; }, AI.ctrl.signal);
      AI.busy = null; AI.ctrl = null;
      box.remove(); await openKindReview();
      toast(r.error ? r.error : `The AI suggested ${r.got} of ${r.asked}${r.rejected ? `; ${r.rejected} set aside because the quoted words weren't in the text` : ""}.`);
      return;
    }
    if (e.target.closest("[data-aistop]")) { if (AI.ctrl) AI.ctrl.abort(); return; }
    if (e.target.closest("[data-clear]")) { m.querySelectorAll("[data-kr]").forEach(s => s.value = ""); return; }
    if (e.target.closest("[data-save]")) {
      let n = 0;
      for (const s of m.querySelectorAll("[data-kr]")) { const x = todo[+s.dataset.kr]; if (s.value) { await setKind(x.it, s.value); n++; } }
      box.remove(); renderAll(); toast(n ? `Set the source kind of ${n} reference${n === 1 ? "" : "s"}` : "Nothing changed");
    }
  });
}

// ---- several at once (Library → Select)
{ const rb = renderBulkBar; renderBulkBar = function () {
  rb(); const bar = $("#bulkBar"); if (!bar || !LIB.picked.size || bar.querySelector("[data-b-kind]")) return;
  const del = bar.querySelector("[data-b=del]");
  const h = `<select data-b-kind aria-label="Set source kind" style="max-width:190px"><option value="">Source kind…</option>${kindOptions("", "")}<option value="_clear">Clear the source kind</option></select><select data-b-role aria-label="Set my category" style="max-width:170px"><option value="">My category…</option>${roleOptions("", "")}<option value="_new">New category…</option><option value="_clear">Clear the category</option></select>`;
  if (del) del.insertAdjacentHTML("beforebegin", h);
  const picked = () => items.filter(x => LIB.picked.has(x.id));
  const sk = bar.querySelector("[data-b-kind]"); if (sk) sk.onchange = async () => { const v = sk.value; if (!v) return; const p = picked(); for (const it of p) await setKind(it, v === "_clear" ? "" : v); renderAll(); toast(v === "_clear" ? `Cleared the source kind of ${p.length}` : `${p.length} set to ${kindName(v)}`); };
  const sr = bar.querySelector("[data-b-role]"); if (sr) sr.onchange = async () => { let v = sr.value; if (!v) return; if (v === "_new") { v = await newRole(); if (!v) { sr.value = ""; return; } } const p = picked(); for (const it of p) await setRole(it, v === "_clear" ? "" : v); renderAll(); toast(v === "_clear" ? `Cleared the category of ${p.length}` : `${p.length} set to ${roleName(v)}`); };
}; }

// ---- Settings: your own categories
function renderRolesCard() {
  const cols = document.getElementById("settingsCols"); if (!cols) return;
  let c = document.getElementById("rolesCard");
  if (!c) { c = document.createElement("div"); c.className = "card"; c.id = "rolesCard"; const after = document.getElementById("lookCard") || document.getElementById("styleCard"); cols.insertBefore(c, after ? after.nextSibling : cols.firstChild); }
  c.innerHTML = `<h3 style="margin:0">Sources: kinds and my categories</h3>
    <p class="note" style="margin:0"><b style="font-weight:500">Source kinds</b> are the same for everyone (journal article, book, report, government document…). Citekeep suggests them from evidence and you confirm: <b>Source kinds</b> in the Library.</p>
    <button class="btn" id="kindReviewBtn2" style="justify-self:start">Review source kinds…</button>
    <p class="note" style="margin:6px 0 0"><b style="font-weight:500">My categories</b> are yours, for whatever you need to group by. Citekeep never suggests them. Shared with your other computer.</p>
    ${ROLES.length ? ROLES.map((r, i) => `<div class="row" style="flex-wrap:nowrap"><input type="text" data-rname="${i}" value="${esc(r.name)}" aria-label="Category name"><span class="note" style="white-space:nowrap">${items.filter(x => x.role === r.id).length}</span><button class="copy" data-rdel="${i}">Remove</button></div>`).join("") : `<span class="note">None yet.</span>`}
    <div class="row"><button class="btn" id="roleAdd">Add a category</button></div>`;
  c.querySelectorAll("[data-rname]").forEach(inp => inp.onchange = async () => { const v = inp.value.trim().slice(0, 60); const r = ROLES[+inp.dataset.rname]; if (!v || !r) { inp.value = r ? r.name : ""; return; } r.name = v; await saveRoles(); renderAll(); toast("Renamed"); });
  c.querySelectorAll("[data-rdel]").forEach(b => b.onclick = async () => {
    const r = ROLES[+b.dataset.rdel]; if (!r) return; const used = items.filter(x => x.role === r.id);
    if (!(await ckConfirm(`Remove the category “${r.name}”?${used.length ? ` ${used.length} reference${used.length === 1 ? "" : "s"} in it will have no category.` : ""}`, { ok: "Remove", danger: true }))) return;
    for (const it of used) await setRole(it, "");
    ROLES = ROLES.filter(x => x !== r); await saveRoles(); renderRolesCard(); renderAll();
  });
  c.querySelector("#roleAdd").onclick = async () => { const id = await newRole(); if (id) { toast(`Added “${roleName(id)}”`); renderAll(); } };
  c.querySelector("#kindReviewBtn2").onclick = openKindReview;
}

(function () {
  const go = async () => {
    await loadRoles(); await crLoad();
    const ft = $("#fType");
    if (ft && !$("#fKind")) {
      ft.insertAdjacentHTML("afterend", `<select id="fKind" aria-label="Filter by source kind"></select><select id="fRole" aria-label="Filter by my category" hidden></select>`);
      $("#fKind").onchange = e => { KINDF = e.target.value; renderList(); };
      $("#fRole").onchange = e => { ROLEF = e.target.value; renderList(); };
    }
    const tools = $("#dupBtn") && $("#dupBtn").parentElement;
    if (tools && !$("#kindReviewBtn")) { tools.insertAdjacentHTML("beforeend", `<button class="copy" id="kindReviewBtn">Source kinds</button>`); $("#kindReviewBtn").onclick = openKindReview; }
    renderFilters(); renderRolesCard(); renderList();
    if (selectedId && !editing) renderDetail();
    // V43's built-in categories are withdrawn: clear them from references, once the library is open
    const clearOld = async () => {
      if (!loaded && !(typeof memMode !== "undefined" && memMode)) { setTimeout(clearOld, 1000); return; }
      const old = items.filter(i => OLD_BUILTIN.includes(i.role));
      for (const it of old) await setRole(it, "");
      if (old.length) renderAll();
    };
    clearOld();
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", go); else setTimeout(go, 50);
})();

// ---- the AI's suggestion for references with no clear evidence; kept only if the words it quotes are really in the text
var AISUG = new Map();
{ const sk0 = suggestKind; suggestKind = function (it) { const r = sk0(it); if (r || !it || it.srcKind) return r; return AISUG.get(it.id) || null; }; }
const AIK_SCHEMA = { type: "object", properties: { kind: { type: "string", enum: SRC_KINDS.map(k => k.id).concat([""]) }, evidence: { type: "string" } }, required: ["kind", "evidence"] };
const AIK_SYSTEM = `You classify one academic source into exactly one kind, using only the text you are given.
Kinds:
- journal: an article in a scholarly journal
- book: a book, or a chapter in an edited book
- thesis: a doctoral dissertation or master's thesis
- conf: a paper in conference proceedings
- report: a research report, working paper, evaluation, or brief from a research organization, university, or foundation
- gov: a document published by a government agency, school district, legislature, or state department
- law: a statute, act, regulation, or court case
- web: a web page, blog post, news article, or press release
Reply with only JSON: {"kind": "<one of the kinds>", "evidence": "<words copied exactly from the text that show the kind>"}.
If the text doesn't show the kind, reply {"kind": "", "evidence": ""}. Don't guess from the topic.`;
const normQ = t => String(t || "").toLowerCase().replace(/[\u2018\u2019\u201c\u201d]/g, "'").replace(/[^a-z0-9]+/g, " ").trim();
async function aiKinds(list, onProgress, signal) {
  await aiLoad();
  let got = 0, rejected = 0, asked = 0;
  for (const it of list) {
    if (signal && signal.aborted) break;
    asked++; if (onProgress) onProgress(asked, list.length);
    let txt = "Reference: " + (refText(it) || htmlToText(formatReference(it, "apa")));
    if (it.url) txt += "\nWeb address: " + it.url;
    if (itemPdfLocal(it) && typeof readPdfFull === "function") { try { txt += "\n\nStart of the linked file:\n" + (await readPdfFull(it.file)).replace(/=== PDF page \d+ ===\n?/g, "").slice(0, 3500); } catch (e) {} }
    let out = null;
    try { out = await aiComplete(AIK_SYSTEM, txt, signal, AIK_SCHEMA, "source_kind"); }
    catch (e) { if (e.name === "AbortError") break; return { error: e.message, got, rejected, asked }; }
    let j = null; try { const t = String(out || "").replace(/<think>[\s\S]*?<\/think>/gi, ""); j = JSON.parse(t.slice(t.indexOf("{"), t.lastIndexOf("}") + 1)); } catch (e) {}
    if (!j || !SRC_KINDS.some(k => k.id === j.kind)) continue;
    const q = normQ(j.evidence);
    if (q.length < 6 || !normQ(txt).includes(q)) { rejected++; continue; }
    AISUG.set(it.id, { id: j.kind, why: `${aiLabel()} read \u201c${String(j.evidence).trim().slice(0, 90)}\u201d`, ai: true });
    got++;
  }
  return { got, rejected, asked };
}
