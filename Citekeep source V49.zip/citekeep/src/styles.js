// ===== Citation styles: APA 7 (Citekeep's original), MLA 9, Chicago 18 author-date, Chicago 18 notes and bibliography.
// The library stores one set of fields per reference; each style formats them its own way. =====
var CITE = { style: "apa" };
const STYLES = {
  apa: { name: "APA 7", list: "References", short: "APA" },
  mla: { name: "MLA 9", list: "Works Cited", short: "MLA" },
  cad: { name: "Chicago 18, author-date", list: "References", short: "Chicago author-date" },
  cnb: { name: "Chicago 18, notes and bibliography", list: "Bibliography", short: "Chicago notes" },
};
const styleOk = s => (STYLES[s] ? s : CITE.style);

// ---------- title case (MLA and Chicago both capitalize titles headline style) ----------
const TC_MINOR = new Set(("a an the and but or nor for so yet as at by from in into like of off on onto out over per than to up upon via vs v with " +
  "about above across after against along amid among around before behind below beneath beside between beyond despite down during except inside near outside past since through throughout toward towards under underneath until within without").split(" "));
function titleCase(s) {
  if (!s) return "";
  const words = s.split(/(\s+)/);
  const idx = words.map((w, i) => (/\S/.test(w) ? i : -1)).filter(i => i >= 0);
  const firstI = idx[0], lastI = idx[idx.length - 1];
  let afterBreak = true;
  return words.map((w, i) => {
    if (!/\S/.test(w)) return w;
    const forceCap = afterBreak || i === firstI || i === lastI;
    afterBreak = /[:?!—]$|^[—–]$/.test(w);
    return w.split("-").map((part, k) => {
      const m = part.match(/^([^A-Za-z0-9]*)([A-Za-z][A-Za-z'’.]*)(.*)$/s);
      if (!m) return part;
      const [, pre, core, post] = m;
      if (/[A-Z]/.test(core.slice(1)) || /\d/.test(core) || /^[A-Z]{2,}$/.test(core)) return part;   // acronyms, iPad, Grade3: as typed
      const lower = core.toLowerCase();
      if (!(forceCap && k === 0) && TC_MINOR.has(lower) && !(k > 0 && !TC_MINOR.has(lower))) return pre + lower + post;
      return pre + core.charAt(0).toUpperCase() + core.slice(1) + post;
    }).join("-");
  }).join("");
}
// the main title, before any subtitle, without a leading article, at most four words (Chicago short titles, MLA in-text titles)
function shortTitle(t) {
  const main = String(t || "").split(/[:?!]/)[0].trim().replace(/^(the|a|an)\s+/i, "");
  const w = main.split(/\s+/);
  if (w.length <= 5) return main.replace(/[,.;]$/, "");
  let cut = w.slice(0, 4); while (cut.length > 1 && TC_MINOR.has(cut[cut.length - 1].toLowerCase())) cut.pop();
  return cut.join(" ").replace(/[,.;]$/, "");
}

// ---------- page ranges ----------
function pageParts(p) { const m = String(p || "").match(/^\s*([A-Za-z]?\d+)\s*[-–—]\s*([A-Za-z]?\d+)\s*$/); return m ? [m[1], m[2]] : null; }
function mlaPages(p) {   // MLA 9: second number in full through 99, otherwise last two digits unless more are needed
  const r = pageParts(p); if (!r) return String(p || "");
  const [a, b] = r; if (!/^\d+$/.test(a) || !/^\d+$/.test(b) || +a < 100 || b.length !== a.length) return a + "-" + b;
  const keep = b.slice(-2); return a.slice(0, -2) === b.slice(0, -2) ? a + "-" + keep : a + "-" + b;
}
function chicagoPages(p) {   // CMOS 9.64
  const r = pageParts(p); if (!r) return String(p || "");
  const [a, b] = r; if (!/^\d+$/.test(a) || !/^\d+$/.test(b) || b.length !== a.length) return a + "–" + b;
  const n = +a;
  if (n < 100 || n % 100 === 0) return a + "–" + b;
  const tail = n % 100;
  if (tail < 10) { let i = 0; while (i < a.length && a[i] === b[i]) i++; return a + "–" + b.slice(i); }   // 101–8, 1103–4
  let i = 0; while (i < a.length - 2 && a[i] === b[i]) i++; return a + "–" + b.slice(i);                  // 321–28, 498–532
}

// ---------- names ----------
const gname = a => (a.given ? a.given + " " : "") + a.family + (a.suffix ? ", " + a.suffix : "");
const iname = a => a.family + (a.given ? ", " + a.given : "") + (a.suffix ? ", " + a.suffix : "");
function listNames(it, style) {
  const a = it.authors || []; if (!a.length) return "";
  if (a[0].org) return a[0].org;
  if (style === "mla") {
    if (a.length === 1 && !it.etal) return iname(a[0]);
    if (a.length === 2 && !it.etal) return iname(a[0]) + ", and " + gname(a[1]);
    return iname(a[0]) + ", et al.";
  }
  // Chicago 18 bibliography and reference list: up to six; more than six, the first three and et al.
  if (it.etal && a.length < 3) return iname(a[0]) + ", et al.";
  const shown = a.length > 6 ? a.slice(0, 3) : a;
  const names = [iname(shown[0])].concat(shown.slice(1).map(gname));
  if (a.length > 6) return names.join(", ") + ", et al.";
  if (names.length === 1) return names[0];
  if (names.length === 2) return names[0] + ", and " + names[1];
  return names.slice(0, -1).join(", ") + ", and " + names[names.length - 1];
}
function textNames(it) {   // in the text and in notes: one, two, or the first and et al.
  const a = it.authors || []; if (!a.length) return "";
  if (a[0].org) return a[0].org;
  if (it.etal || a.length > 2) return a[0].family + " et al.";
  return a.length === 2 ? a[0].family + " and " + a[1].family : a[0].family;
}
function noteNames(it) {
  const a = it.authors || []; if (!a.length) return "";
  if (a[0].org) return a[0].org;
  if (it.etal || a.length > 2) return gname(a[0]) + " et al.";
  return a.length === 2 ? gname(a[0]) + " and " + gname(a[1]) : gname(a[0]);
}
const editorsText = e => String(e || "").replace(/\s*&\s*/g, " and ").replace(/,\s*and\s+/g, " and ").trim();
const endDot = s => { s = String(s || "").trim(); return !s ? "" : /[.?!]$/.test(s) ? s : s + "."; };
const quoted = (t, punct) => { const x = titleCase(t); return /[?!]$/.test(x) ? `“${esc(x)}”` : `“${esc(x)}${punct}”`; };
const ital = t => `<i>${esc(titleCase(t))}</i>`;
function doiUrl(it, mla) {
  if (it.doi) return "https://doi.org/" + esc(String(it.doi).replace(/^https?:\/\/(dx\.)?doi\.org\//i, "").replace(/^doi:\s*/i, ""));
  if (it.url) return esc(mla ? String(it.url).replace(/^https?:\/\//i, "") : it.url);
  return "";
}
const MON = { january: "Jan.", february: "Feb.", march: "Mar.", april: "Apr.", may: "May", june: "June", july: "July", august: "Aug.", september: "Sept.", october: "Oct.", november: "Nov.", december: "Dec." };
function mlaDate(it) {
  const y = it.year || "", d = String(it.date || "").trim(); if (!d) return y;
  const m = d.match(/^([A-Za-z]+)\s+(\d{1,2})$/); if (m && MON[m[1].toLowerCase()]) return `${m[2]} ${MON[m[1].toLowerCase()]} ${y}`;
  const m2 = d.match(/^([A-Za-z]+)$/); if (m2) return `${MON[m2[1].toLowerCase()] || m2[1]} ${y}`;
  return y;
}

// ---------- fields for references that only have your APA wording ----------
// Many references came in from APA papers: the journal, volume and pages are in the wording, not in fields. Read them out.
function withApaFields(it) {
  if (!it.refHtml || (it.rawStyle && it.rawStyle !== "apa")) return it;
  if (it.container && (it.type !== "article" || it.volume)) return it;
  const html = it.refHtml, text = htmlToText(html).replace(/\s+/g, " ").trim();
  const out = Object.assign({}, it);
  const ix = [...html.matchAll(/<i>(.*?)<\/i>/gi)].map(m => htmlToText(m[1]).trim()).filter(Boolean);
  const afterYear = text.replace(/^.*?\((?:\d{4}[a-z]?|n\.d\.)(?:, [^)]*)?\)\.\s*/, "");
  const art = afterYear.match(/^(.+?[.?!])\s+(.+?),\s*(\d+)(?:\s*\(([^)]+)\))?(?:,\s*([A-Za-z]?\d+(?:\s*[-–]\s*[A-Za-z]?\d+)?|Article\s+\S+))?\./);
  const chap = afterYear.match(/^(.+?[.?!])\s+In\s+(.*?)\s*\((?:Eds?\.)\),\s*(.+?)(?:\s*\((?:[^)]*?)pp\.\s*([^)]+)\))?\.\s*(.*?)(?:\.\s*(?:https?:\S+)?)?$/);
  if (!out.type || out.type === "other") out.type = art ? "article" : chap ? "chapter" : "book";
  if (out.type === "article" && art) {
    out.title = out.title || art[1].replace(/\.$/, "");
    out.container = out.container || art[2]; out.volume = out.volume || art[3]; out.issue = out.issue || art[4] || ""; out.pages = out.pages || art[5] || "";
  } else if (out.type === "chapter" && chap) {
    out.title = out.title || chap[1].replace(/\.$/, "");
    out.editors = out.editors || chap[2]; out.container = out.container || chap[3]; out.pages = out.pages || (chap[4] || "").trim(); out.publisher = out.publisher || (chap[5] || "").replace(/\.$/, "");
  } else {
    const tm = afterYear.match(/^(.+?)(?:\s*\(([^)]*)\))?\.\s+(.+?)\.(?:\s|$)/);
    if (tm && !out.publisher && !/^https?:/.test(tm[3])) out.publisher = tm[3];
    if (tm && tm[2] && !out.edition && /ed\.$/.test(tm[2])) out.edition = tm[2];
    if (tm && tm[2] && !out.reportNo && !/ed\.$/.test(tm[2])) out.reportNo = tm[2];
  }
  if (!out.title && ix[0]) out.title = ix[0];
  return out;
}

// ---------- formatting ----------
function mlaReference(it0) {
  const it = withApaFields(it0), t = it.type || "article";
  const org = it.authors && it.authors.length === 1 && it.authors[0].org;
  const orgIsPub = org && (!it.publisher || norm(it.publisher) === norm(org)) && t !== "article" && t !== "chapter";
  const A = it.authors && it.authors.length && !orgIsPub ? esc(endDot(listNames(it, "mla"))) + " " : "";
  const link = doiUrl(it, true), date = mlaDate(it);
  let out;
  if (t === "article") {
    const bits = [it.container ? ital(it.container).replace(/<\/i>$/, "</i>") : "", it.volume ? "vol. " + esc(it.volume) : "", it.issue ? "no. " + esc(it.issue) : "", date, it.pages ? "pp. " + esc(mlaPages(it.pages)) : ""].filter(Boolean);
    out = `${A}${quoted(it.title || "Untitled", ".")} ${bits.join(", ")}`;
  } else if (t === "chapter") {
    const bits = [it.container ? ital(it.container) : "", it.editors ? "edited by " + esc(editorsText(it.editors)) : "", it.publisher ? esc(it.publisher) : "", date, it.pages ? "pp. " + esc(mlaPages(it.pages)) : ""].filter(Boolean);
    out = `${A}${quoted(it.title || "Untitled", ".")} ${bits.join(", ")}`;
  } else if (t === "webpage") {
    const bits = [it.container ? ital(it.container) : "", date].filter(Boolean);
    out = `${A}${quoted(it.title || "Untitled", ".")}${bits.length ? " " + bits.join(", ") : ""}`;
  } else if (t === "legal") {
    out = `${ital(it.title || "Untitled")}${it.legal ? ", " + esc(it.legal) : ""}${date ? ", " + date : ""}`;
  } else {
    const bits = [it.edition ? esc(it.edition.replace(/\s*ed\.?$/i, "") + " ed.") : "", it.reportNo ? esc(it.reportNo) : "", it.publisher || org ? esc(it.publisher || org) : "", date].filter(Boolean);
    out = `${A}${ital(it.title || "Untitled")}.${bits.length ? " " + bits.join(", ") : ""}`;
  }
  out = endDot(out.replace(/\s+/g, " ").trim());
  return link ? `${out} ${link}.` : out;
}
function cadReference(it0) {   // Chicago 18 author-date reference list
  const it = withApaFields(it0), t = it.type || "article";
  const Y = esc((it.year || "n.d.") + (it.year ? it._suffix || "" : ""));
  const names = listNames(it, "cad");
  const lead = names ? `${esc(endDot(names))} ${Y}. ` : "";
  const link = doiUrl(it, false);
  const date = it.date ? esc(it.date) : "";
  let body;
  if (t === "article") {
    const vol = [it.container ? ital(it.container) : "", it.volume ? esc(it.volume) + (it.issue ? ` (${esc(it.issue)})` : "") : ""].filter(Boolean).join(" ");
    body = `${quoted(it.title || "Untitled", ".")} ${vol}${it.pages ? ": " + esc(chicagoPages(it.pages)) : ""}`;
  } else if (t === "chapter") {
    body = `${quoted(it.title || "Untitled", ".")} In ${it.container ? ital(it.container) : ""}${it.editors ? ", edited by " + esc(editorsText(it.editors)) : ""}${it.pages ? ", " + esc(chicagoPages(it.pages)) : ""}. ${it.publisher ? esc(it.publisher) : ""}`;
  } else if (t === "webpage") {
    body = `${quoted(it.title || "Untitled", ".")} ${it.container ? esc(it.container) : ""}${date ? ", " + date : ""}`;
  } else if (t === "legal") {
    body = `${ital(it.title || "Untitled")}${it.legal ? ", " + esc(it.legal) : ""}`;
  } else {
    body = `${ital(it.title || "Untitled")}.${it.edition ? " " + esc(it.edition.replace(/\s*ed\.?$/i, "") + " ed.") : ""}${it.reportNo ? " " + endDot(esc(it.reportNo)) : ""} ${it.publisher ? esc(it.publisher) : ""}`;
  }
  let out = names ? lead + body : `${body.replace(/^(“[^”]*”|<i>.*?<\/i>\.?)/, m => endDot(m.replace(/[.,]”$/, "”")) + " " + Y + ".")}`;
  out = endDot(out.replace(/\.\s*\./g, ".").replace(/\s+/g, " ").trim());
  return link ? `${out} ${link}.` : out;
}
function cnbReference(it0) {   // Chicago 18 bibliography
  const it = withApaFields(it0), t = it.type || "article";
  const names = listNames(it, "cnb");
  const A = names ? esc(endDot(names)) + " " : "";
  const link = doiUrl(it, false), y = esc(it.year || "n.d.");
  let out;
  if (t === "article") {
    out = `${A}${quoted(it.title || "Untitled", ".")} ${it.container ? ital(it.container) : ""}${it.volume ? " " + esc(it.volume) : ""}${it.issue ? ", no. " + esc(it.issue) : ""} (${y})${it.pages ? ": " + esc(chicagoPages(it.pages)) : ""}`;
  } else if (t === "chapter") {
    out = `${A}${quoted(it.title || "Untitled", ".")} In ${it.container ? ital(it.container) : ""}${it.editors ? ", edited by " + esc(editorsText(it.editors)) : ""}${it.pages ? ", " + esc(chicagoPages(it.pages)) : ""}. ${it.publisher ? esc(it.publisher) + ", " : ""}${y}`;
  } else if (t === "webpage") {
    out = `${A}${quoted(it.title || "Untitled", ".")} ${it.container ? endDot(esc(it.container)) + " " : ""}${it.date ? esc(it.date) + ", " : ""}${y}`;
  } else if (t === "legal") {
    out = `${ital(it.title || "Untitled")}${it.legal ? ", " + esc(it.legal) : ""}, ${y}`;
  } else {
    out = `${A}${ital(it.title || "Untitled")}.${it.edition ? " " + esc(it.edition.replace(/\s*ed\.?$/i, "") + " ed.") : ""}${it.reportNo ? " " + endDot(esc(it.reportNo)) : ""} ${it.publisher ? esc(it.publisher) + ", " : ""}${y}`;
  }
  out = endDot(out.replace(/\s+/g, " ").trim());
  return link ? `${out} ${link}.` : out;
}
// Chicago notes: the first full note and the short note after it (page left for you to add)
function cnbNote(it0) {
  const it = withApaFields(it0), t = it.type || "article", N = esc(noteNames(it)), y = esc(it.year || "n.d.");
  const lead = N ? N + ", " : "";
  if (t === "article") return `${lead}${quoted(it.title || "Untitled", ",")} ${it.container ? ital(it.container) : ""}${it.volume ? " " + esc(it.volume) : ""}${it.issue ? ", no. " + esc(it.issue) : ""} (${y})${doiUrl(it) ? ", " + doiUrl(it) : ""}.`;
  if (t === "chapter") return `${lead}${quoted(it.title || "Untitled", ",")} in ${it.container ? ital(it.container) : ""}${it.editors ? ", ed. " + esc(editorsText(it.editors)) : ""} (${it.publisher ? esc(it.publisher) + ", " : ""}${y}).`;
  if (t === "webpage") return `${lead}${quoted(it.title || "Untitled", ",")} ${it.container ? esc(it.container) + ", " : ""}${y}${doiUrl(it) ? ", " + doiUrl(it) : ""}.`;
  return `${lead}${ital(it.title || "Untitled")}${it.edition ? ", " + esc(it.edition.replace(/\s*ed\.?$/i, "") + " ed.") : ""} (${it.publisher ? esc(it.publisher) + ", " : ""}${y}).`;
}
function cnbShort(it0) {
  const it = withApaFields(it0), t = it.type || "article", st = titleCase(shortTitle(it.title || "Untitled"));
  const who = textNames(it);
  const T = ["book", "report", "other", "legal"].includes(t) ? `<i>${esc(st)}</i>,` : `“${esc(st)},”`;
  return who ? `${esc(who)}, ${T}` : T;
}

// ---------- routing: formatReference, citeForms, sortKey ----------
formatReference = function (it, style) {
  const s = styleOk(style);
  if (s === "apa") {
    if (it.rawStyle && it.rawStyle !== "apa" && it.useRaw !== false) return apaFormatReference(Object.assign({}, it, { useRaw: false }));
    return apaFormatReference(it);
  }
  if (it.refHtml && it.useRaw !== false && it.rawStyle === s) return it.refHtml;   // your own wording, already in this style
  return s === "mla" ? mlaReference(it) : s === "cad" ? cadReference(it) : cnbReference(it);
};
citeForms = function (it, style) {
  const s = styleOk(style);
  if (s === "apa") return apaCiteForms(it);
  const who = textNames(it) || (it.title ? (s === "mla" ? `“${titleCase(shortTitle(it.title))}”` : titleCase(shortTitle(it.title))) : "Untitled");
  if (s === "mla") return { parenthetical: `(${who})`, narrative: who, labels: ["Parenthetical (add the page)", "In a sentence"] };
  if (s === "cad") { const y = (it.year || "n.d.") + (it.year ? it._suffix || "" : ""); return { parenthetical: `(${who} ${y})`, narrative: `${who} (${y})` }; }
  return { parenthetical: htmlToText(cnbShort(it)), narrative: htmlToText(cnbNote(it)), labels: ["Short note (add the page)", "First note"], parentheticalHtml: cnbShort(it), narrativeHtml: cnbNote(it) };
};
sortKey = function (it, style) {
  const s = styleOk(style);
  if (s === "apa" || s === "cad") return apaSortKey(it);
  const a = it.authors || [];
  const t = norm(it.title || "").toLowerCase().replace(/^(the|a|an)\s+/, "").replace(/[^a-z0-9 ]/g, "");
  const lead = it.type === "legal" || !a.length ? t : a.map(x => x.org || (x.family + " " + (x.given || ""))).join(" ");
  return norm(lead).toLowerCase().replace(/[^a-z0-9 ]/g, "") + " " + t;
};
// a whole list, in order, as HTML entries (MLA repeats an author with three hyphens)
function styleListHtml(list, style) {
  const s = styleOk(style); let prev = "";
  return list.map(it => {
    let h = formatReference(it, s);
    if (s === "mla" && !(it.refHtml && it.useRaw !== false && it.rawStyle === "mla")) {
      const who = (it.authors || []).length ? esc(endDot(listNames(it, "mla"))) : "";
      if (who && who === prev && h.startsWith(who)) h = "---." + h.slice(who.length);
      prev = who;
    }
    return h;
  });
}

// ---------- reading a document's own list in MLA or Chicago ----------
function parseNamesMC(s) {
  s = String(s || "").trim().replace(/\.$/, "");
  let etal = false;
  if (/,?\s*et al\.?$/i.test(s)) { etal = true; s = s.replace(/,?\s*et al\.?$/i, "").trim(); }
  if (!s.includes(",") && !etal) return { authors: [{ org: s }], etal: false };
  const parts = s.split(/,\s*(?:and\s+)?|\s+and\s+/).map(x => x.trim()).filter(Boolean);
  const out = [];
  const sfx = /^(Jr\.?|Sr\.?|II|III|IV)$/;
  if (parts.length) {
    const first = { family: parts[0], given: parts[1] || "" };
    let i = 2; if (parts[i] && sfx.test(parts[i])) { first.suffix = parts[i]; i++; }
    out.push(first);
    for (; i < parts.length; i++) {
      if (sfx.test(parts[i]) && out.length) { out[out.length - 1].suffix = parts[i]; continue; }
      const w = parts[i].split(/\s+/); const fam = w.pop(); out.push({ family: fam, given: w.join(" ") });
    }
  }
  return { authors: out, etal };
}
function afterTitleFields(after, out) {
  const vol = after.match(/\bvol\.\s*([\w-]+)/i), no = after.match(/\bno\.\s*([\w-]+)/i), pp = after.match(/\bpp?\.\s*([A-Za-z]?\d+(?:\s*[-–]\s*[A-Za-z]?\d+)?)/);
  if (vol) out.volume = vol[1]; if (no) out.issue = no[1]; if (pp) out.pages = pp[1];
  const ed = after.match(/\b(\d+(?:st|nd|rd|th)|[Rr]ev\.|[Rr]evised|[Ee]xpanded)\s+ed\./); if (ed) out.edition = ed[1];
  const cv = after.match(/^(.+?)\s+(\d+)(?:,\s*no\.\s*(\w+))?\s*(?:\((\w+)\))?\s*(?:\(\s*(?:[A-Za-z.]+\s+)?((?:1[5-9]|20)\d\d)\))?\s*:\s*([A-Za-z]?\d+(?:\s*[-–]\s*[A-Za-z]?\d+)?)/);
  if (cv) { out.container = out.container || cv[1].replace(/[.,]$/, ""); out.volume = out.volume || cv[2]; out.issue = out.issue || cv[3] || cv[4] || ""; out.pages = out.pages || cv[6]; }
  if (!out.container) { const c = after.match(/^([^,.]+?)(?:,|\.)/); if (c && /vol\.|no\.|pp\./.test(after)) out.container = c[1].trim(); }
  const eb = after.match(/edited by ([^,.]+(?:,? and [^,.]+)?)/i); if (eb) out.editors = eb[1];
  if (out.pages) out.pages = fullPages(out.pages);
  const doi = after.match(/(?:doi\.org\/|doi:\s*)(10\.\d{4,9}\/\S+?)\.?(?:\s|$)/i);
  if (doi) out.doi = doi[1]; else { const u = after.match(/(?:https?:\/\/|www\.)\S+?(?=\.?(?:\s|$))/); if (u) out.url = u[0]; }
}
// "321-28" written out in full, with an en dash: "321–328"
function fullPages(p) {
  const r = pageParts(p); if (!r) return p;
  let [a, b] = r; if (/^\d+$/.test(a) && /^\d+$/.test(b) && b.length < a.length) b = a.slice(0, a.length - b.length) + b;
  return a + "–" + b;
}
function splitAuthors(text) {
  // the author part ends at the first period after a lower-case letter, or before an opening quote
  const m = text.match(/^(.+?(?:[a-z\)\]]\.|\.(?=\s+["“])))\s+(.*)$/);
  return m ? [m[1], m[2]] : null;
}
function takeTitle(rest) {
  if (/^["“]/.test(rest)) { const q = rest.match(/^["“](.+?)[,.]?["”][.,]?\s*(.*)$/); if (q) return [q[1], q[2], true]; }
  const t = rest.match(/^(.+?[.?!])\s+(.*)$/);
  return t ? [t[1].replace(/\.$/, ""), t[2], false] : [rest, "", false];
}
function parseRefStyled(text, style, prev) {
  text = norm(text);
  const out = { raw: text, authors: [], year: "", suffix: "", date: "", title: "", type: "other" };
  let rest = text;
  if (/^(?:-{2,3}|—+|_{3,})\.?\s*/.test(rest)) {   // ---. the same author(s) as the entry above
    rest = rest.replace(/^(?:-{2,3}|—+|_{3,})\.?\s*/, "");
    if (prev) { out.authors = prev.authors.map(a => Object.assign({}, a)); out.etal = prev.etal; }
  } else if (!/^["“]/.test(rest)) {
    const sp = splitAuthors(rest);
    if (sp) { const n = parseNamesMC(sp[0]); out.authors = n.authors; if (n.etal) out.etal = true; rest = sp[1]; }
  }
  if (style === "cad") {
    const y = rest.match(/^((?:1[5-9]|20)\d\d)([a-z]?)\.\s+(.*)$/) || rest.match(/^(n\.d\.)()\s*(.*)$/);
    if (y) { out.year = y[1] === "n.d." ? "" : y[1]; out.suffix = y[2] || ""; rest = y[3]; }
  }
  const [title, after, isQuoted] = takeTitle(rest);
  out.title = title;
  if (style !== "cad") { const y = after.match(/\b((?:1[5-9]|20)\d\d)\b/); if (y) out.year = y[1]; }
  afterTitleFields(after, out);
  if (!out.authors.length && out.title) out.authors = [];
  out.type = out.volume || /\bvol\.|\(\w+\):\s*\d|\d+,\s*no\./.test(after) ? "article" : /edited by|^In\s/i.test(after) ? "chapter" : isQuoted ? "webpage" : "book";
  if (out.type === "book") { const pub = after.match(/^(?:[^.]*?ed\.,?\s*)?([^,.]+?),\s*(?:1[5-9]|20)\d\d/) || after.match(/^(?:[^.]*?ed\.\s*)?([^.]+?)\.\s*$/); if (pub && !/^(?:1[5-9]|20)\d\d$|^n\.d$/.test(pub[1].trim())) out.publisher = pub[1].trim(); }
  return out;
}
function styledEntries(refParas, style) {
  let prev = null;
  return refParas.map((p, i) => {
    const ref = parseRefStyled(paraText(p), style, prev); prev = ref;
    const forms = (ref.authors.length ? itemForms(ref) : [norm(titleCase(shortTitle(ref.title)))]);
    return { id: "r" + i, p, ref, year: style === "cad" ? (ref.year ? ref.year + ref.suffix : "n.d.") : "", forms, shortT: compactKey(shortTitle(ref.title)).toLowerCase() };
  });
}

// ---------- finding typed citations ----------
const LOC_CAD = "(?:" + LOC + "|,\\s*(?!(?:19|20)\\d\\d\\b)[A-Za-z]?\\d{1,4}(?:\\s*[-–]\\s*[A-Za-z]?\\d{1,4})?(?:,\\s*[A-Za-z]?\\d{1,4}(?:\\s*[-–]\\s*[A-Za-z]?\\d{1,4})?)*)";
const MLA_LOC = /^(?:,?\s*)(?:(?:pp?\.\s*)?[A-Za-z]?\d+(?:\s*[-–]\s*[A-Za-z]?\d+)?(?:,\s*\d+(?:\s*[-–]\s*\d+)?)*|(?:par|pars|ch|sec|line|lines|vol)\.?\s*\d+(?:\s*[-–]\s*\d+)?|\d+:\d+(?::\d+)?(?:\s*[-–]\s*\d+:\d+(?::\d+)?)?|[ivxlc]+(?:\s*[-–]\s*[ivxlc]+)?)?$/i;
const NOT_NAMES = /^(?:Table|Figure|Fig|Grade|Grades|Chapter|Section|Page|Appendix|Title|Step|Level|Year|Phase|Part|Line|Volume|Book|Act|Article|Unit|Room|Session|Week|Day|Module|Lesson|Question|Item|Exhibit|Note|Model|Study|Wave|Cohort|Group|Region|District|School|Version|Rule|No|Number|Pages)$/;
function mlaIndex(entries) {
  const byName = new Map();
  for (const e of entries) for (const f of e.forms) { const k = norm(f); if (!byName.has(k)) byName.set(k, []); if (!byName.get(k).includes(e)) byName.get(k).push(e); }
  return { byName, names: [...byName.keys()].sort((a, b) => b.length - a.length), entries };
}
function findCitationsMLA(text, X) {
  const spans = [], misses = [];
  const T = fold(text.replace(/[‘’]/g, "'")).replace(/[  -​ \t]/g, " ");
  const pick = (list, titlePart) => {
    if (!list || !list.length) return null;
    if (list.length === 1 && !titlePart) return list[0];
    if (titlePart) { const k = compactKey(titlePart.replace(/^["“]|["”]$/g, "")).toLowerCase(); return list.find(e => e.shortT.startsWith(k) || k.startsWith(e.shortT.slice(0, Math.max(6, k.length)))) || null; }
    return null;   // two works by one author need a short title
  };
  const re = /\(([^()]{1,200})\)/g; let m;
  while ((m = re.exec(T))) {
    const inner = m[1], base = m.index + 1; let off = 0;
    for (const raw of inner.split(/;\s*/)) {
      const segStart = base + inner.indexOf(raw, off); off = segStart - base + raw.length;
      let seg = raw, s0 = segStart;
      const pf = seg.match(/^(?:qtd\.\s+in|see also|see|cf\.|e\.g\.,?|also)\s+/i); if (pf) { s0 += pf[0].length; seg = seg.slice(pf[0].length); }
      // only a page: the author is named in the sentence before
      if (MLA_LOC.test(seg) && /\d|[ivxlc]/.test(seg)) {
        const before = T.slice(Math.max(0, m.index - 300), m.index);
        let best = null; for (const nm of X.names) { const k = before.lastIndexOf(nm); if (k >= 0 && (!best || k > best.k) && /^(?:\W|$)/.test(before.slice(k + nm.length, k + nm.length + 1))) best = { nm, k }; }
        if (best) { const e = pick(X.byName.get(best.nm)); const ns = m.index - before.length + best.k; if (e) spans.push([ns, ns + best.nm.length, e.id, best.nm, "", { narr: true, first: true, ns, ne: ns + best.nm.length, name: text.slice(ns, ns + best.nm.length), group: m.index }]); }
        continue;
      }
      let hit = null; for (const nm of X.names) if (seg.startsWith(nm) && /^(?:$|[\s,])/.test(seg.slice(nm.length))) { hit = nm; break; }
      if (hit) {
        let rest = seg.slice(hit.length), titlePart = "";
        const tp = rest.match(/^,\s*((?:["“][^"”]+["”])|(?:[A-Z][^,\d]*?))(?=\s+[A-Za-z]?\d|\s*$|,)/); if (tp) { titlePart = tp[1]; rest = rest.slice(tp[0].length); }
        if (!MLA_LOC.test(rest)) continue;   // "(Smith Elementary School)" and the like
        const e = pick(X.byName.get(hit), titlePart);
        if (e) spans.push([s0, s0 + hit.length, e.id, hit, "", { narr: false, first: true, ns: s0, ne: s0 + hit.length, name: text.slice(s0, s0 + hit.length), group: m.index }]);
        else { const ws = (X.byName.get(hit) || []); misses.push({ name: hit + (titlePart ? ", " + titlePart : ""), years: "", context: text.slice(Math.max(0, m.index - 50), m.index + m[0].length), narrative: false, ns: s0, ne: s0 + hit.length, why: titlePart ? "" : "two works by this author: add a short title", manual: !titlePart, works: ws.map(e => e.ref.title) }); }
        continue;
      }
      const tq = seg.match(/^["“]([^"”]+)["”]/);
      if (tq) { const k = compactKey(tq[1]).toLowerCase(); const e = X.entries.find(x => x.shortT && (x.shortT.startsWith(k) || k.startsWith(x.shortT))); if (e) spans.push([s0, s0 + tq[0].length, e.id, tq[0], "", { narr: false, first: true, ns: s0, ne: s0 + tq[0].length, name: tq[0], group: m.index }]); continue; }
      const looks = seg.match(/^([A-Z][A-Za-z'\-]+(?:\s+(?:and|&)\s+[A-Z][A-Za-z'\-]+|\s+et al\.)?)(?=\s+[A-Za-z]?\d)/);
      if (looks && !NOT_NAMES.test(looks[1].split(/\s/)[0]) && MLA_LOC.test(seg.slice(looks[1].length)))
        misses.push({ name: looks[1], years: "", context: text.slice(Math.max(0, m.index - 50), m.index + m[0].length), narrative: false, ns: s0, ne: s0 + looks[1].length });
    }
  }
  return { spans, misses };
}

// ---------- Chicago notes: footnotes matched to the bibliography ----------
function readNotes(fdom) {
  if (!fdom) return [];
  return wEls(fdom, "footnote").filter(f => !/separator|continuation/i.test(f.getAttributeNS(WNS, "type") || f.getAttribute("w:type") || ""))
    .map(f => ({ id: f.getAttributeNS(WNS, "id") || f.getAttribute("w:id"), paras: wEls(f, "p") }));
}
function noteRefsIn(p) { const out = []; for (const r of textRuns(p)) { const fr = wEls(r.r, "footnoteReference")[0]; if (fr) out.push({ id: fr.getAttributeNS(WNS, "id") || fr.getAttribute("w:id"), pos: r.start }); } return out; }
function notesCheck(bodyParas, fdom, entries) {
  const notes = readNotes(fdom), byId = new Map(notes.map(n => [n.id, n]));
  const keyed = entries.map(e => { const a = e.ref.authors[0]; return { e, fam: a ? norm(a.family || a.org || "").toLowerCase() : "", words: compactWords(e.ref.title) }; });
  const perPara = [], misses = [], cited = new Map(), refs = new Map();
  let prevIds = [];
  bodyParas.forEach((p, pIndex) => { for (const r of noteRefsIn(p)) {
    const n = byId.get(r.id); if (!n) continue;
    const ids = [];
    for (const np of n.paras) {
      const t = paraText(np), T = norm(t).toLowerCase(); if (!t.trim()) continue;
      const spans = []; let off = 0;
      for (const seg of t.split(/;\s+/)) {
        const s0 = t.indexOf(seg, off); off = s0 + seg.length;
        const sg = norm(seg).toLowerCase();
        if (/^\s*ibid\b/.test(sg)) { for (const id of prevIds) { ids.push(id); cited.set(id, (cited.get(id) || 0) + 1); } if (prevIds[0]) spans.push([s0, s0 + seg.replace(/[.,]?\s*$/, "").length, prevIds[0], "Ibid.", "", { narr: false, first: true }]); continue; }
        let best = null;
        for (const k of keyed) {
          if (k.fam && !new RegExp("\\b" + k.fam.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "\\b").test(sg)) continue;
          const tw = k.words.filter(w => sg.includes(w)).length;
          const score = (k.fam ? 2 : 0) + tw * 3 + (k.e.ref.year && sg.includes(k.e.ref.year) ? 1 : 0);
          if (!k.fam && tw < 2) continue;
          if (!best || score > best.score) best = { score, k, tw };
        }
        const sameFam = best ? keyed.filter(k => k.fam === best.k.fam).length : 0;
        if (best && (best.tw > 0 || sameFam === 1)) {
          const id = best.k.e.id; ids.push(id); cited.set(id, (cited.get(id) || 0) + 1);
          spans.push([s0, s0 + seg.replace(/[.,]?\s*$/, "").length, id, best.k.fam, "", { narr: false, first: true }]);
        } else if (/^\s*(?:see(?: also)?\s+|cf\.\s+)?[A-Z][\w'’.\- ]{1,60},\s/.test(seg) && /\d|“|"/.test(seg)) {
          misses.push({ name: seg.split(",")[0].replace(/^(?:See(?: also)?|Cf\.)\s+/, "").trim(), years: "", context: "Note " + (notes.indexOf(n) + 1) + ": " + t.slice(0, 160), narrative: false, p: np, ns: s0, ne: s0 + seg.length, note: true });
        }
      }
      if (spans.length) perPara.push({ p: np, spans });
    }
    if (ids.length) prevIds = [...new Set(ids)];
    refs.set(pIndex, (refs.get(pIndex) || []).concat([{ pos: r.pos, ids: [...new Set(ids)] }]));
  } });
  return { perPara, misses, cited, noteRefs: refs, noteCount: notes.length };
}
function compactWords(t) { return norm(shortTitle(t)).toLowerCase().split(/\s+/).filter(w => w.length > 3 && !TC_MINOR.has(w)).slice(0, 3); }

// ---------- checking a document in any style ----------
function detectStyle(dom, fdom) {
  const { bodyParas, refParas } = readDocument(dom);
  const head = wEls(dom, "p").map(p => paraText(p).trim().replace(/:$/, "").toLowerCase()).find(t => /^(references|reference list|works cited|bibliography|literature cited)$/.test(t)) || "";
  const body = bodyParas.map(paraText).join("\n");
  const notes = readNotes(fdom).length;
  if (head === "works cited") return "mla";
  if (notes >= 3 && (head === "bibliography" || notes > 10)) return "cnb";
  const apa = (body.match(/\([A-Z][^()]{0,80}?, (?:19|20)\d\d[a-z]?(?:[,;)]|\s*p)/g) || []).length;
  const cad = (body.match(/\([A-Z][A-Za-z'’\-]+(?: (?:and|&) [A-Z][A-Za-z'’\-]+| et al\.)? (?:19|20)\d\d[a-z]?(?:, \d|[;)])/g) || []).length;
  const mla = (body.match(/\([A-Z][A-Za-z'’\-]+(?: and [A-Z][A-Za-z'’\-]+| et al\.)? \d{1,3}(?:[-–]\d+)?\)/g) || []).length;
  const ref = refParas.slice(0, 8).map(paraText).join("\n");
  if (cad > apa && cad >= mla) return "cad";
  if (mla > apa && mla > cad) return "mla";
  if (!apa && /\. (?:19|20)\d\d[a-z]?\. /.test(ref)) return "cad";
  return "apa";
}
function libMatchByTitle(entries, libraryItems) {
  const key = x => { const a = (x.authors || [])[0]; return (a ? norm(a.family || a.org || "").toLowerCase() : "") + "|" + compactKey(shortTitle(x.title || "")).toLowerCase().slice(0, 24); };
  const lib = new Map(); for (const it of libraryItems) { const w = withApaFields(it); lib.set(key(w), it.id); }
  const inLib = [], notInLib = [];
  for (const e of entries) { const id = lib.get(key(e.ref)); (id ? inLib : notInLib).push({ entry: e, itemId: id }); }
  return { inLib, notInLib };
}
checkDocument = function (dom, libraryItems, style, fdom) {
  if (!style || style === "apa") { const r = apaCheckDocument(dom, libraryItems); r.style = "apa"; return r; }
  const { bodyParas, refParas, hasRefHeading } = readDocument(dom);
  const entries = styledEntries(refParas, style);
  let perPara = [], misses = [], cited = new Map(), extra = {};
  if (style === "cnb") {
    const N = notesCheck(bodyParas, fdom, entries);
    perPara = N.perPara; misses = N.misses; cited = N.cited; extra = { noteRefs: N.noteRefs, noteCount: N.noteCount };
  } else {
    const F = style === "mla" ? mlaIndex(entries) : buildFormIndex(entries);
    for (const p of bodyParas) {
      const t = paraText(p); if (!t.trim()) continue;
      const r = style === "mla" ? findCitationsMLA(t, F) : findCitations(t, F, LOC_CAD);
      if (r.spans.length) perPara.push({ p, spans: r.spans });
      for (const s of r.spans) cited.set(s[2], (cited.get(s[2]) || 0) + 1);
      for (const x of r.misses) { x.p = p; x.hints = []; misses.push(x); }
    }
  }
  const uncited = entries.filter(e => !cited.has(e.id));
  const citedIds = new Set(cited.keys());
  for (const x of misses) x.candidates = candidatesFor(x, entries, citedIds);
  const lib = libraryItems && libraryItems.length ? libMatchByTitle(entries, libraryItems) : null;
  const total = perPara.reduce((n, x) => n + x.spans.length, 0);
  return Object.assign({ style, hasRefHeading, entries, perPara, misses, uncited, cited, total, lib, dup: [] }, extra);
};
// the citations in one paragraph, in the document's style (used by the claim check)
function styleSpans(t, r) {
  if (!r.style || r.style === "apa") return findCitations(t, buildFormIndex(r.entries)).spans;
  if (r.style === "mla") return findCitationsMLA(t, mlaIndex(r.entries)).spans;
  if (r.style === "cad") return findCitations(t, buildFormIndex(r.entries), LOC_CAD).spans;
  return [];
}

// ---------- choosing a style ----------
function bibStyle() { const s = document.getElementById("bibStyle"); return s && STYLES[s.value] ? s.value : CITE.style; }
function styleOptions(sel, withAuto) {
  return (withAuto ? `<option value="auto">Detect automatically</option>` : "") + Object.keys(STYLES).map(k => `<option value="${k}" ${k === sel ? "selected" : ""}>${esc(STYLES[k].name)}</option>`).join("");
}
function showStyleInTitle() { const sm = document.querySelector(".brand small"); if (sm) sm.textContent = sm.textContent.replace(/(·\s*)?[^·]*$/, (m, dot) => (dot || (sm.textContent.includes("·") ? "· " : "")) + STYLES[CITE.style].short.replace(/^APA$/, "APA 7")); }
function renderStyleCard() {
  const cols = document.getElementById("settingsCols"); if (!cols) return;
  let c = document.getElementById("styleCard");
  if (!c) { c = document.createElement("div"); c.className = "card"; c.id = "styleCard"; cols.insertBefore(c, cols.firstChild); }
  c.innerHTML = `<h3 style="margin:0">Citation style</h3>
    <p class="note" style="margin:0">The style your library shows references and in-text citations in, and the starting choice for reference lists. Each document is checked in its own style, detected when you open it.</p>
    <label class="f"><span>Your usual style</span><select id="citeStyleSel">${styleOptions(CITE.style)}</select></label>
    <p class="note" style="margin:0">References you pulled in from a paper keep your exact wording in that paper's style. In another style, Citekeep builds each reference from its fields (authors, title, journal, volume, pages), so check a few the first time.</p>`;
  c.querySelector("#citeStyleSel").onchange = async e => {
    CITE.style = e.target.value;
    try { await window.citekeepApp.setSetting("citeStyle", CITE.style); } catch (x) {}
    const b = document.getElementById("bibStyle"); if (b) b.value = CITE.style;
    showStyleInTitle(); renderAll(); toast("Showing references in " + STYLES[CITE.style].name);
  };
}
(function () {
  const go = async () => {
    try { const st = await window.citekeepApp.getSettings(); if (STYLES[st.citeStyle]) CITE.style = st.citeStyle; } catch (e) {}
    const b = document.getElementById("bibStyle"); if (b) { b.innerHTML = styleOptions(CITE.style); b.addEventListener("change", () => renderBib()); }
    const d = document.getElementById("docStyle"); if (d) d.innerHTML = styleOptions("auto", true);
    renderStyleCard(); showStyleInTitle();
    if (typeof loaded !== "undefined" && loaded && CITE.style !== "apa") renderAll();
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", go); else setTimeout(go, 0);
})();
