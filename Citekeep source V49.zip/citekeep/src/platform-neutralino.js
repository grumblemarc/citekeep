// ===== Citekeep portable (Neutralino): the same app bridge the installed version uses =====
(function () {
  // GitHub repository whose releases Citekeep checks for updates. A fork should change this to its own "owner/repo".
  const UPDATE_REPO = "grumblemarc/citekeep";
  // Always get this launch's access token straight from the engine, never from a cached copy
  async function freshGlobals() {
    try {
      const r = await fetch("/__neutralino_globals.js?_=" + Date.now(), { cache: "no-store" });
      let t = r.ok ? await r.text() : "";
      if (!/NL_TOKEN\s*=/.test(t)) { const r2 = await fetch("/__neutralino_globals.js", { cache: "no-store" }); t = r2.ok ? await r2.text() : ""; }
      if (/NL_TOKEN\s*=\s*['"][^'"]+['"]/.test(t)) (0, eval)(t);
    } catch (e) {}
    try { if (window.NL_TOKEN) sessionStorage.setItem("NL_TOKEN", window.NL_TOKEN); else sessionStorage.removeItem("NL_TOKEN"); } catch (e) {}
  }
  function warnUser(msg) {
    const show = () => { const b = document.getElementById("memBanner"); if (b) { b.textContent = msg; b.hidden = false; } };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", show); else show();
  }
  const fromTemp = () => /[\\/](Temp|tmp)[\\/]/i.test(String(window.NL_PATH || "") + String(window.NL_CWD || ""));
  let engineReady = false;
  const ready = new Promise(res => {
    freshGlobals().then(() => {
      if (fromTemp()) warnUser("Citekeep is running from inside the zip file, so it can't work properly. Close it, right-click the zip, choose Extract All, and run Citekeep.exe from the extracted folder.");
      try { Neutralino.init(); Neutralino.events.on("ready", () => { engineReady = true; res(); }); } catch (e) { res(); }
      setTimeout(() => {
        if (!engineReady) warnUser("Citekeep couldn't connect to its engine. If you opened it from inside the zip file, close it, extract the zip (right-click, Extract All), and run Citekeep.exe from the extracted folder. Otherwise, close every Citekeep window and open it again.");
        res();
      }, 8000);
    });
  });
  const isWin = () => (window.NL_OS || "").toLowerCase().startsWith("win");
  const SEP = () => (isWin() ? "\\" : "/");
  const join = (...p) => p.filter(Boolean).join(SEP()).replace(/[\\/]+/g, SEP());
  let compName = null;
  async function computerName() { if (compName === null) { try { compName = await Neutralino.os.getEnv(isWin() ? "COMPUTERNAME" : "HOSTNAME"); } catch { compName = ""; } compName = compName || "this computer"; } return compName; }
  const q = s => '"' + String(s).replace(/"/g, '\\"') + '"';
  const psq = s => "'" + String(s).replace(/'/g, "''") + "'";
  // Documents\Citekeep is the anchor. It holds the data, or a location.json pointing to a Citekeep folder elsewhere
  // (for example inside Google Drive or OneDrive, so several computers share one library).
  let docsDir = null, anchorDir = null, homeDir = null, dataMoved = "";
  async function home() {
    if (homeDir === null) { try { homeDir = await Neutralino.os.getEnv(isWin() ? "USERPROFILE" : "HOME"); } catch { homeDir = ""; } if (!homeDir) { try { homeDir = (await Neutralino.os.getPath("documents")).replace(/[\\/][^\\/]+[\\/]?$/, ""); } catch { homeDir = ""; } } }
    return homeDir;
  }
  // paths inside the user's own folder are stored as ~\…, so they work for any user name on any computer
  async function toPortable(p) { const h = await home(); if (!p || !h) return p || ""; const a = p.replace(/[\\/]+$/, ""), hh = h.replace(/[\\/]+$/, ""); return a.toLowerCase().startsWith(hh.toLowerCase() + SEP()) || a.toLowerCase().startsWith(hh.toLowerCase() + "/") ? "~" + a.slice(hh.length) : a; }
  async function fromPortable(p) { if (!p) return ""; if (p[0] !== "~") return p; return join(await home(), p.slice(1)); }
  async function exists(p) { try { await Neutralino.filesystem.getStats(p); return true; } catch { return false; } }
  async function anchor() {
    if (!anchorDir) { anchorDir = join(await Neutralino.os.getPath("documents"), "Citekeep"); try { await Neutralino.filesystem.createDirectory(anchorDir); } catch {} }
    return anchorDir;
  }
  async function dir() {
    await ready;
    if (!docsDir) {
      const a = await anchor();
      docsDir = a;
      try {
        const loc = JSON.parse(await Neutralino.filesystem.readFile(join(a, "location.json")));
        const where = await fromPortable(loc.dataDir || "");
        if (where && await exists(where)) docsDir = where; else if (where) dataMoved = where;
      } catch {}
    }
    return docsDir;
  }
  // settings live in Documents\Citekeep\settings.json beside the library, so every version and install finds them;
  // older versions kept them in the app's own storage folder, so bring those over the first time
  // settings tied to one machine (where its PDF folder and AI program are) stay in that computer's own
  // Documents\Citekeep\this-computer.json, so computers sharing a library can keep them in different places
  const LOCAL_KEYS = ["pdfFolder", "aiUrls", "aiUrl", "libraryChoice", "lastUpdateCheck", "lookTheme", "lookAccent", "lookSize", "recentDocs", "winState", "libSort", "settingsFolded", "seenVersion", "docAddRefs", "startTab"];
  let lCache = null;
  async function getL() {
    if (lCache) return lCache;
    const a = await anchor(), f = join(a, "this-computer.json");
    try { lCache = JSON.parse(await Neutralino.filesystem.readFile(f)) || {}; }
    catch {
      // first run of this version: take them from this computer's own settings file
      let src = {}; try { src = JSON.parse(await Neutralino.filesystem.readFile(join(a, "settings.json"))) || {}; } catch {}
      lCache = {}; for (const k of LOCAL_KEYS.concat(["claudeKey", "gRefresh", "aiLocalKey"])) if (src[k] !== undefined && src[k] !== "") lCache[k] = src[k];
      try { await Neutralino.filesystem.writeFile(f, JSON.stringify(lCache, null, 1)); } catch {}
    }
    return lCache;
  }
  let sCache = null;
  async function getS() {
    await migrateSecrets();
    const shared = await getShared(), local = await getL();
    const s = Object.assign({}, shared); delete s.vault;
    for (const k of LOCAL_KEYS) { if (k in local) s[k] = local[k]; }
    for (const k of SECRETS) delete s[k];
    if (shared.vault) { if (VAULT.dek) { await vaultRefresh(); Object.assign(s, VAULT.secrets || {}); } }
    else for (const k of SECRETS) if (local[k]) s[k] = local[k];
    return s;
  }
  // ---- keys: the Claude API key, the Google sign-in and a local AI key. With a Citekeep password they're kept encrypted
  // (AES-256-GCM) in the shared settings, so every computer sharing the library can unlock them; without one they stay
  // in this computer's own this-computer.json and never sync. ----
  const SECRETS = ["claudeKey", "gRefresh", "aiLocalKey"];
  const VAULT = { secrets: null, dek: null, raw: null };
  const PBKDF2_ITER = 600000;
  const te = new TextEncoder(), td = new TextDecoder();
  const b64 = u8 => { let s = ""; for (const c of u8) s += String.fromCharCode(c); return btoa(s); };
  const unb64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
  const CODE_ABC = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
  const normCode = s => String(s || "").toUpperCase().replace(/[^A-Z0-9]/g, "").replace(/^KEEP/, "").replace(/O/g, "0").replace(/[IL]/g, "1");
  async function kek(secret, salt, iter) {
    const base = await crypto.subtle.importKey("raw", te.encode(secret), "PBKDF2", false, ["deriveKey"]);
    return crypto.subtle.deriveKey({ name: "PBKDF2", salt, iterations: iter, hash: "SHA-256" }, base, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
  }
  async function seal(key, bytes) { const iv = crypto.getRandomValues(new Uint8Array(12)); return { iv: b64(iv), ct: b64(new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, bytes))) }; }
  async function unseal(key, box) { return new Uint8Array(await crypto.subtle.decrypt({ name: "AES-GCM", iv: unb64(box.iv) }, key, unb64(box.ct))); }
  async function wrapWith(secret, raw) { const salt = crypto.getRandomValues(new Uint8Array(16)); return { salt: b64(salt), box: await seal(await kek(secret, salt, PBKDF2_ITER), raw) }; }
  function newCode() { const r = crypto.getRandomValues(new Uint8Array(20)); let c = ""; for (const x of r) c += CODE_ABC[x % CODE_ABC.length]; return "KEEP-" + c.match(/.{4}/g).join("-"); }
  async function freshShared() { sCache = null; return getShared(); }
  async function writeShared(sh) { sCache = Object.assign({}, sh); await Neutralino.filesystem.writeFile(join(await dir(), "settings.json"), JSON.stringify(sh, null, 1)); }
  async function writeLocal(l) { lCache = l; await Neutralino.filesystem.writeFile(join(await anchor(), "this-computer.json"), JSON.stringify(l, null, 1)); }
  async function sealSecrets(sh) { sh.vault = Object.assign({}, sh.vault, { data: await seal(VAULT.dek, te.encode(JSON.stringify(VAULT.secrets || {}))) }); vaultSeen = sh.vault.data.ct; }
  async function loadVault(raw, v) {
    const dek = await crypto.subtle.importKey("raw", raw, "AES-GCM", false, ["encrypt", "decrypt"]);
    const secrets = v.data ? JSON.parse(td.decode(await unseal(dek, v.data))) : {};
    vaultSeen = v.data ? v.data.ct : ""; vaultAt = Date.now();
    Object.assign(VAULT, { dek, raw, secrets });
    try { sessionStorage.setItem("ck-unlock", b64(raw)); } catch {}
    // keys this computer had in plain text (from before the password) go into the vault
    const l = Object.assign({}, await getL()); let moved = false;
    for (const k of SECRETS) if (l[k]) { if (!VAULT.secrets[k]) VAULT.secrets[k] = l[k]; delete l[k]; moved = true; }
    if (moved) { const sh = await freshShared(); await sealSecrets(sh); await writeShared(sh); await writeLocal(l); }
  }
  // before V35, keys sat in plain text in settings.json, which syncs when the library is shared: move them to this computer
  let migrating = null;
  function migrateSecrets() { if (!migrating) migrating = migrateOnce(); return migrating; }   // everyone waits for the same first run
  async function migrateOnce() {
    const sh = await getShared(), plain = SECRETS.filter(k => sh[k]);
    if (plain.length) {
      const l = Object.assign({}, await getL());
      for (const k of plain) { if (!l[k]) l[k] = sh[k]; delete sh[k]; }
      await writeLocal(l); await writeShared(sh);
    }
    // stay unlocked after Citekeep reloads itself (only until it's closed)
    if (sh.vault && !VAULT.dek) { try { const s = sessionStorage.getItem("ck-unlock"); if (s) await loadVault(unb64(s), sh.vault); } catch { try { sessionStorage.removeItem("ck-unlock"); } catch {} } }
  }
  // another computer may have changed a key since we unlocked: read the shared vault again (at most every 10 s)
  let vaultSeen = "", vaultAt = 0;
  async function vaultRefresh(force) {
    if (!VAULT.dek || (!force && Date.now() - vaultAt < 10000)) return;
    vaultAt = Date.now();
    const v = (await freshShared()).vault; if (!v || !v.data || v.data.ct === vaultSeen) return;
    try { VAULT.secrets = JSON.parse(td.decode(await unseal(VAULT.dek, v.data))); vaultSeen = v.data.ct; } catch {}
  }
  // ---- the window opens where it was, at the size it was, but only somewhere it can be seen ----
  const sane = w => w && Number.isFinite(w.x) && Number.isFinite(w.y) && w.x > -2000 && w.y > -2000 && w.x < 20000 && w.y < 20000;
  async function displays() { try { const d = await Neutralino.computer.getDisplays(); return Array.isArray(d) && d.length ? d : null; } catch { return null; } }
  function onSomeScreen(ds, x, y, wd) {
    return ds.some(d => { const r = d.resolution || {}, o = d.position || { x: 0, y: 0 }; const W = r.width || 0, H = r.height || 0; return W > 0 && H > 0 && x + Math.min(wd || 200, 200) > o.x + 40 && x < o.x + W - 80 && y >= o.y - 10 && y < o.y + H - 80; });
  }
  async function makeVisible() {
    try { if (Neutralino.window.isMinimized && await Neutralino.window.isMinimized()) await Neutralino.window.unminimize(); } catch {}
    try { if (Neutralino.window.show) await Neutralino.window.show(); } catch {}
    try { await Neutralino.window.focus(); } catch {}
  }
  async function restoreWindow() {
    try {
      const l = await getL(), w = l.winState;
      if (w && !(w.max || sane(w))) { const c = Object.assign({}, l); delete c.winState; await writeLocal(c); }   // a bad saved place (from a minimized window): forget it
      if (w && (w.max || sane(w))) {
        if (w.width >= 420 && w.height >= 300 && w.width < 20000 && w.height < 20000) await Neutralino.window.setSize({ width: Math.round(w.width), height: Math.round(w.height) });
        const ds = await displays();
        if (sane(w) && ds && onSomeScreen(ds, w.x, w.y, w.width)) await Neutralino.window.move(Math.round(w.x), Math.round(w.y));
        if (w.max) await Neutralino.window.maximize();
      }
      // whatever happened above, end up on a screen
      try {
        const p = await Neutralino.window.getPosition(), ds = await displays();
        if (!sane(p) || (ds && !(await Neutralino.window.isMaximized()) && !onSomeScreen(ds, p.x, p.y, 400))) { if (Neutralino.window.center) await Neutralino.window.center(); else await Neutralino.window.move(80, 80); }
      } catch {}
    } catch {}
    await makeVisible();
  }
  async function saveWindow() {
    const l = Object.assign({}, await getL()), prev = l.winState || {};
    try { if (Neutralino.window.isMinimized && await Neutralino.window.isMinimized()) return; } catch {}   // minimized: keep the last good place
    const max = await Neutralino.window.isMaximized();
    if (max) l.winState = Object.assign({}, sane(prev) ? prev : {}, { max: true });
    else {
      const s = await Neutralino.window.getSize(), p = await Neutralino.window.getPosition();
      if (!sane(p) || !(s.width >= 420 && s.height >= 300)) return;   // not a real place on a screen
      l.winState = { max: false, width: s.width, height: s.height, x: p.x, y: p.y };
    }
    await writeLocal(l);
  }
  async function tryUnlock(kind, secret) {
    const v = (await freshShared()).vault; if (!v || !v[kind]) return false;
    let raw; try { raw = await unseal(await kek(kind === "rc" ? normCode(secret) : String(secret), unb64(v[kind].salt), v.iter || PBKDF2_ITER), v[kind].box); } catch { return false; }
    await loadVault(raw, v); return true;
  }
  async function getShared() {
    if (sCache) return Object.assign({}, sCache);
    const d = await dir(), f = join(d, "settings.json");
    try { sCache = JSON.parse(await Neutralino.filesystem.readFile(f)) || {}; }
    catch {
      sCache = {};
      try { sCache = JSON.parse(await Neutralino.storage.getData("settings")) || {}; } catch {}
      try { await Neutralino.filesystem.writeFile(f, JSON.stringify(sCache, null, 1)); } catch {}
    }
    return Object.assign({}, sCache);
  }
  async function putS(s) {
    await migrateSecrets();
    const old = await freshShared(), oldLocal = await getL(), local = {}, shared = {}, keys = {};
    for (const [k, v] of Object.entries(s)) { if (k === "vault") continue; if (SECRETS.includes(k)) keys[k] = v; else if (LOCAL_KEYS.includes(k)) local[k] = v; else shared[k] = v; }
    for (const k of LOCAL_KEYS) if (k in old) shared[k] = old[k];   // left for older versions on other computers
    if (old.vault) {
      shared.vault = old.vault;
      if (VAULT.dek) {
        // apply only the keys changed here to what's in the file now, so another computer's change isn't undone
        const mine = VAULT.secrets || {}; let file = {};
        try { file = old.vault.data ? JSON.parse(td.decode(await unseal(VAULT.dek, old.vault.data))) : {}; } catch { file = Object.assign({}, mine); }
        const next = Object.assign({}, file);
        for (const k of SECRETS) if ((keys[k] || "") !== (mine[k] || "")) { if (keys[k]) next[k] = keys[k]; else delete next[k]; }
        VAULT.secrets = next;
        if (JSON.stringify(next) !== JSON.stringify(file)) await sealSecrets(shared); else vaultSeen = old.vault.data ? old.vault.data.ct : "";
      }
      for (const k of SECRETS) if (oldLocal[k]) local[k] = oldLocal[k];   // waiting to go into the vault at the next unlock
    } else for (const k of SECRETS) if (keys[k]) local[k] = keys[k];
    await writeLocal(local); await writeShared(shared);
  }
  async function setOne(k, v) { const s = await getS(); if (v === null || v === undefined || v === "") delete s[k]; else s[k] = v; await putS(s); }
  const b64url = bytes => btoa(String.fromCharCode(...bytes)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  const REDIRECT = () => "http://127.0.0.1:" + (window.NL_PORT || location.port) + "/oauth.html";
  async function tokenRequest(body) {
    const r = await fetch("https://oauth2.googleapis.com/token", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams(body) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) { const e = new Error(j.error_description || j.error || ("Google answered " + r.status)); e.code = j.error || ""; throw e; }
    return j;
  }
  let pendingSignIn = null;
  let token = null; // {token, exp}
  async function refreshToken() {
    const s = await getS();
    if (!s.gRefresh || !s.gClientId) throw new Error("NOT_SIGNED_IN");
    const body = { client_id: s.gClientId, refresh_token: s.gRefresh, grant_type: "refresh_token" };
    if (s.gClientSecret) body.client_secret = s.gClientSecret;
    let j;
    try { j = await tokenRequest(body); }
    catch (e) { if (e.code === "invalid_grant" || e.code === "unauthorized_client") await setOne("gRefresh", null); throw new Error("NOT_SIGNED_IN"); }   // offline isn't signed out
    token = { token: j.access_token, exp: Date.now() + (j.expires_in - 60) * 1000 };
    return token.token;
  }
  async function accessToken() { if (token && Date.now() < token.exp) return token.token; return refreshToken(); }

  window.citekeepApp = {
    loadLibrary: async () => { const d = await dir(); try { return await Neutralino.filesystem.readFile(join(d, "library.json")); } catch { return null; } },
    saveLibrary: async json => {
      const d = await dir(), f = join(d, "library.json");
      try { await Neutralino.filesystem.copy(f, join(d, "library-previous.json"), { overwrite: true }); } catch {}
      await Neutralino.filesystem.writeFile(f, json);
      return true;
    },
    saveLibrarySync: () => true,
    // ---- sharing one library between computers (the merge itself is in sync.js) ----
    libraryStat: async () => { const d = await dir(); try { const s = await Neutralino.filesystem.getStats(join(d, "library.json")); return { mtime: s.modifiedAt || 0, size: s.size || 0 }; } catch { return { mtime: 0, size: 0 }; } },
    // copies of library.json that Google Drive, OneDrive or Dropbox made when two computers saved at once
    conflictCopies: async () => {
      const d = await dir(); let ents = []; try { ents = await Neutralino.filesystem.readDirectory(d); } catch { return []; }
      return ents.filter(e => e.type === "FILE" && /^library.*\.json$/i.test(e.entry) && e.entry.toLowerCase() !== "library.json" && !/^library-(previous|deleted|backup)/i.test(e.entry)
        && (/\(\d+\)|conflict|conflicted|-[^.]+$/i.test(e.entry.replace(/\.json$/i, "")))).map(e => e.entry);
    },
    // move a merged conflict copy into backups, so it's kept but out of the way
    setAsideCopy: async name => {
      const d = await dir(), b = join(d, "backups"); if (/[\\/]/.test(name)) return false;
      try { await Neutralino.filesystem.createDirectory(b); } catch {}
      try { await Neutralino.filesystem.move(join(d, name), join(b, "merged-" + new Date().toISOString().slice(0, 10) + "-" + Date.now().toString(36) + "-" + name)); return true; } catch { return false; }
    },
    // keep the current library as a dated backup and start an empty one
    archiveLibrary: async () => {
      const d = await dir(), f = join(d, "library.json");
      const stamp = new Date().toISOString().slice(0, 10);
      let name = "library-backup-" + stamp + ".json", n = 2;
      while (true) { try { await Neutralino.filesystem.getStats(join(d, name)); name = "library-backup-" + stamp + " (" + n++ + ").json"; } catch { break; } }
      try { await Neutralino.filesystem.move(f, join(d, name)); } catch { return null; }
      return name;
    },
    // ---- where the data lives, backups, moving computers ----
    dataInfo: async () => { const d = await dir(); return { dir: d, anchor: await anchor(), elsewhere: d !== await anchor(), missing: dataMoved, computer: await computerName() }; },
    // use (or create) a Citekeep folder somewhere else; copy this computer's data there unless that folder already has a library
    setDataDir: async (parent, mode) => {
      const target = /[\\/]Citekeep$/i.test(parent.replace(/[\\/]+$/, "")) ? parent.replace(/[\\/]+$/, "") : join(parent, "Citekeep");
      try { await Neutralino.filesystem.createDirectory(target); } catch {}
      const has = await exists(join(target, "library.json"));
      if (mode === "check") return { target, has };
      const cur = await dir();
      if (mode === "copy" && cur !== target) {
        for (const f of ["library.json", "library-previous.json", "settings.json", "pdf-index.json"]) { if (await exists(join(cur, f))) await Neutralino.filesystem.copy(join(cur, f), join(target, f), { overwrite: true }); }
      }
      const a = await anchor();
      if (target === a) { try { await Neutralino.filesystem.remove(join(a, "location.json")); } catch {} }
      else await Neutralino.filesystem.writeFile(join(a, "location.json"), JSON.stringify({ dataDir: await toPortable(target) }, null, 1));
      docsDir = null; sCache = null;
      return { target, has };
    },
    pickAnyFolder: async title => { await ready; const f = await Neutralino.os.showFolderDialog(title || "Choose a folder"); return f ? (isWin() ? f.replace(/\//g, "\\") : f) : null; },
    // a dated copy of the library once a day; the newest 10 are kept
    dailyBackup: async () => {
      const d = await dir(), bdir = join(d, "backups"), src = join(d, "library.json");
      if (!(await exists(src))) return [];
      try { await Neutralino.filesystem.createDirectory(bdir); } catch {}
      const today = join(bdir, "library-" + new Date().toISOString().slice(0, 10) + ".json");
      if (!(await exists(today))) await Neutralino.filesystem.copy(src, today);
      let ents = []; try { ents = (await Neutralino.filesystem.readDirectory(bdir)).filter(e => e.type === "FILE" && /^library-\d{4}-\d\d-\d\d\.json$/.test(e.entry)).map(e => e.entry).sort(); } catch {}
      while (ents.length > 10) { try { await Neutralino.filesystem.remove(join(bdir, ents.shift())); } catch { break; } }
      return ents.reverse();
    },
    restoreBackup: async name => {
      const d = await dir(), src = join(d, "backups", name);
      if (!/^library-\d{4}-\d\d-\d\d\.json$/.test(name) || !(await exists(src))) return false;
      try { await Neutralino.filesystem.copy(join(d, "library.json"), join(d, "library-previous.json"), { overwrite: true }); } catch {}
      await Neutralino.filesystem.copy(src, join(d, "library.json"), { overwrite: true });
      return true;
    },
    writeBinaryAt: async (folder, rel, data) => {
      const parts = rel.split(/[\\/]/).filter(s => s && s !== ".." && s !== "."); const file = parts.pop(); let d = folder;
      for (const s of parts) { d = join(d, s); try { await Neutralino.filesystem.createDirectory(d); } catch {} }
      const u8 = data instanceof Uint8Array ? data : new Uint8Array(data);
      await Neutralino.filesystem.writeBinaryFile(join(d, file), u8.buffer.slice(u8.byteOffset, u8.byteOffset + u8.byteLength));
      return true;
    },
    makeDir: async p => { try { await Neutralino.filesystem.createDirectory(p); } catch {} return p; },
    documentsDir: async () => { await ready; return await Neutralino.os.getPath("documents"); },
    readText: async name => { const d = await dir(); try { return await Neutralino.filesystem.readFile(join(d, name)); } catch { return null; } },
    writeText: async (name, text) => { const d = await dir(); await Neutralino.filesystem.writeFile(join(d, name), text); return true; },
    readSettingsRaw: async () => getS(),
    writeSettingsRaw: async s => { await putS(s); return true; },
    // look for a folder with this name in the usual places on this computer
    findFolder: async (saved) => {
      const name = String(saved || "").replace(/[\\/]+$/, "").split(/[\\/]/).pop(); if (!name) return null;
      const h = await home(); const bases = [];
      for (const k of ["documents", "desktop", "downloads"]) { try { bases.push(await Neutralino.os.getPath(k)); } catch {} }
      bases.push(h, join(h, "Google Drive"), join(h, "My Drive"), join(h, "OneDrive"), join(h, "OneDrive", "Documents"), join(h, "Dropbox"));
      if (isWin()) for (const L of "GHDEF") bases.push(L + ":\\My Drive", L + ":\\");
      const seen = new Set();
      for (const base of bases) {
        if (!base || seen.has(base.toLowerCase())) continue; seen.add(base.toLowerCase());
        if (await exists(join(base, name))) return join(base, name);
        let ents = []; try { ents = await Neutralino.filesystem.readDirectory(base); } catch { continue; }
        for (const e of ents.filter(e => e.type === "DIRECTORY" && !/^[.$]/.test(e.entry)).slice(0, 60)) if (await exists(join(base, e.entry, name))) return join(base, e.entry, name);
      }
      return null;
    },
    // one computer at a time on a shared library
    heartbeat: async (leaving) => {
      const d = await dir(), f = join(d, "in-use.json"), me = await computerName();
      let other = null;
      try { const j = JSON.parse(await Neutralino.filesystem.readFile(f)); if (j.computer !== me && Date.now() - j.at < 3 * 60 * 1000) other = j.computer; } catch {}
      if (leaving) { if (!other) { try { await Neutralino.filesystem.remove(f); } catch {} } return other; }
      if (!other) { try { await Neutralino.filesystem.writeFile(f, JSON.stringify({ computer: me, at: Date.now() })); } catch {} }
      return other;
    },
    // ---- updates from the GitHub releases page, fetched with Windows' own curl (no browser download warnings) ----
    appVersion: async () => { await ready; return String(window.NL_APPVERSION || ""); },
    updateCheck: async () => {
      await ready;
      const r = await Neutralino.os.execCommand(`curl.exe -sL --max-time 20 -H "User-Agent: Citekeep" -H "Accept: application/vnd.github+json" "https://api.github.com/repos/${UPDATE_REPO}/releases/latest"`);
      let j; try { j = JSON.parse(r.stdOut || ""); } catch { return { ok: false, error: "Couldn't reach GitHub. Check your internet connection." }; }
      if (!j.tag_name) return { ok: false, error: j.message || "No release found." };
      const asset = (j.assets || []).find(a => /setup.*\.exe$/i.test(a.name));
      return { ok: true, tag: j.tag_name, version: parseInt(String(j.tag_name).replace(/\D+/g, ""), 10) || 0, notes: j.body || "", page: j.html_url || "", asset: asset ? { name: asset.name, url: asset.browser_download_url, size: asset.size } : null };
    },
    updateDownload: async (url, name) => {
      await ready;
      if (!url.startsWith("https://github.com/" + UPDATE_REPO + "/releases/download/")) return { ok: false, error: "Unexpected download address." };
      const safe = String(name).replace(/[^\w .()-]+/g, "_");
      let dl; try { dl = await Neutralino.os.getPath("downloads"); } catch { dl = await dir(); }
      const dest = join(dl, safe);
      const r = await Neutralino.os.execCommand(`curl.exe -sL --fail --max-time 900 -o "${dest}" "${url}"`);
      try { const s = await Neutralino.filesystem.getStats(dest); if ((s.size || 0) < 200000) throw 0; } catch { return { ok: false, error: "The download didn't finish. Try again." + (r.stdErr ? " (" + String(r.stdErr).slice(0, 120) + ")" : "") }; }
      return { ok: true, path: dest };
    },
    updateRun: async path => {
      await ready;
      if (!/Citekeep[^\\/]*Setup[^\\/]*\.exe$/i.test(path)) return false;
      try { if (typeof window.citekeepFlush === "function") await window.citekeepFlush(); } catch {}
      await Neutralino.os.execCommand(`start "" "${path}"`, { background: true });
      return true;
    },
    downloadsDir: async () => { await ready; try { return await Neutralino.os.getPath("downloads"); } catch { return ""; } },
    listPdfs: async folder => {
      await ready;
      let ents = []; try { ents = await Neutralino.filesystem.readDirectory(folder); } catch { return []; }
      const out = [];
      for (const e of ents) if (e.type === "FILE" && /\.pdf$/i.test(e.entry)) { try { const s = await Neutralino.filesystem.getStats(join(folder, e.entry)); out.push({ name: e.entry, size: s.size || 0, mtime: s.modifiedAt || 0 }); } catch {} }
      return out;
    },
    // put a PDF into the PDF folder under a free name; returns the name used
    placePdf: async (folder, name, src, data) => {
      await ready;
      const base = name.replace(/\.pdf$/i, ""); let pick = base + ".pdf", n = 2;
      while (true) { try { await Neutralino.filesystem.getStats(join(folder, pick)); pick = base + " (" + n++ + ").pdf"; } catch { break; } }
      if (src) await Neutralino.filesystem.move(src.folder ? join(src.folder, src.name) : src, join(folder, pick));
      else { const u8 = data instanceof Uint8Array ? data : new Uint8Array(data); await Neutralino.filesystem.writeBinaryFile(join(folder, pick), u8.buffer.slice(u8.byteOffset, u8.byteOffset + u8.byteLength)); }
      return pick;
    },
    libraryPath: async () => join(await dir(), "library.json"),
    showLibrary: async () => window.citekeepApp.showFile(join(await dir(), "library.json")),
    getSettings: async () => { const s = await getS(); return { pdfFolder: await fromPortable(s.pdfFolder || ""), pdfFolderSaved: s.pdfFolder || "", gClientId: s.gClientId || "", gClientSecret: s.gClientSecret ? "saved" : "", gSignedIn: !!s.gRefresh, aiProvider: s.aiProvider || "", aiUrl: s.aiUrl || "", aiModel: s.aiModel || "", aiUrls: s.aiUrls || "", aiModels: s.aiModels || "", aiLocalKey: s.aiLocalKey ? "saved" : "", aiCtx: s.aiCtx || "", claudeModel: s.claudeModel || "", claudeKey: s.claudeKey ? "saved" : "", matrixTitle: s.matrixTitle || "", libraryChoice: s.libraryChoice || "", unpaywallEmail: s.unpaywallEmail || "", citeStyle: s.citeStyle || "", lookTheme: s.lookTheme || "", lookAccent: s.lookAccent || "", lookSize: s.lookSize || "", recentDocs: s.recentDocs || "", libSort: s.libSort || "", settingsFolded: s.settingsFolded || "", seenVersion: s.seenVersion || "", docAddRefs: s.docAddRefs || "", watchDownloads: s.watchDownloads || "", addFromDownloads: s.addFromDownloads || "", aiRules: s.aiRules || "", gPdfFolders: Array.isArray(s.gPdfFolders) ? s.gPdfFolders : [], roleList: Array.isArray(s.roleList) ? s.roleList : [], startTab: s.startTab || "" }; },
    claudeKey: async () => (await getS()).claudeKey || "",
    // ---- the Citekeep password ----
    lockStatus: async () => { await ready; await migrateSecrets(); const v = (await getShared()).vault; return { enabled: !!v, unlocked: !!VAULT.dek }; },
    unlock: async pw => { await ready; return tryUnlock("pw", pw); },
    unlockWithCode: async code => { await ready; return tryUnlock("rc", code); },
    checkPassword: async pw => { const v = (await freshShared()).vault; if (!v) return false; try { await unseal(await kek(String(pw), unb64(v.pw.salt), v.iter || PBKDF2_ITER), v.pw.box); return true; } catch { return false; } },
    // turn the password on (returns the recovery code), or change it while unlocked (returns null)
    setPassword: async pw => {
      await ready; await migrateSecrets();
      const sh = await freshShared();
      if (sh.vault) { if (!VAULT.dek) return false; sh.vault = Object.assign({}, sh.vault, { pw: await wrapWith(String(pw), VAULT.raw) }); await writeShared(sh); return null; }
      const raw = crypto.getRandomValues(new Uint8Array(32)), code = newCode(), l = Object.assign({}, await getL()), secrets = {};
      for (const k of SECRETS) if (l[k]) { secrets[k] = l[k]; delete l[k]; }
      sh.vault = { v: 1, iter: PBKDF2_ITER, pw: await wrapWith(String(pw), raw), rc: await wrapWith(normCode(code), raw) };
      Object.assign(VAULT, { raw, secrets, dek: await crypto.subtle.importKey("raw", raw, "AES-GCM", false, ["encrypt", "decrypt"]) });
      await sealSecrets(sh); await writeShared(sh); await writeLocal(l);
      try { sessionStorage.setItem("ck-unlock", b64(raw)); } catch {}
      return code;
    },
    newRecoveryCode: async () => { if (!VAULT.dek) return null; const sh = await freshShared(); if (!sh.vault) return null; const code = newCode(); sh.vault = Object.assign({}, sh.vault, { rc: await wrapWith(normCode(code), VAULT.raw) }); await writeShared(sh); return code; },
    // turn the password off: the keys go back to this computer only
    removePassword: async () => {
      if (!VAULT.dek) return false;
      const sh = await freshShared(), l = Object.assign({}, await getL());
      for (const k of SECRETS) if (VAULT.secrets && VAULT.secrets[k]) l[k] = VAULT.secrets[k];
      delete sh.vault; await writeShared(sh); await writeLocal(l);
      Object.assign(VAULT, { dek: null, raw: null, secrets: null }); try { sessionStorage.removeItem("ck-unlock"); } catch {}
      return true;
    },
    // forgot the password and the recovery code: the keys are cleared, everything else stays
    resetKeys: async () => {
      const sh = await freshShared(), l = Object.assign({}, await getL());
      delete sh.vault; for (const k of SECRETS) delete l[k];
      await writeShared(sh); await writeLocal(l);
      Object.assign(VAULT, { dek: null, raw: null, secrets: null }); token = null; try { sessionStorage.removeItem("ck-unlock"); } catch {}
      return true;
    },
    lockNow: async () => { Object.assign(VAULT, { dek: null, raw: null, secrets: null }); token = null; try { sessionStorage.removeItem("ck-unlock"); } catch {} return true; },
    aiLocalKey: async () => (await getS()).aiLocalKey || "",
    // ---- documents opened through Citekeep, so they can be listed as recent ----
    pickDocs: async () => {
      await ready;
      try { const r = await Neutralino.os.showOpenDialog("Open a Word document", { filters: [{ name: "Word documents", extensions: ["docx"] }], multiSelections: true }); return (r || []).map(p => (isWin() ? p.replace(/\//g, "\\") : p)); }
      catch { return null; }
    },
    readDoc: async p => { await ready; const b = await Neutralino.filesystem.readBinaryFile(p); let mtime = 0; try { mtime = (await Neutralino.filesystem.getStats(p)).modifiedAt || 0; } catch {} return { data: new Uint8Array(b), mtime }; },
    // the newest file in the same folder whose name differs only in its numbers (Chapter_2_V.42 after V.41)
    newerSibling: async p => {
      const m = String(p).match(/^(.*[\\/])([^\\/]+)$/); if (!m) return null;
      const folder = m[1].replace(/[\\/]$/, ""), name = m[2];
      const stem = s => s.replace(/\.docx$/i, "").replace(/\s*\((?:corrected and )?linked\)\s*$/i, "").replace(/\d+/g, "#").toLowerCase();
      let ents = []; try { ents = await Neutralino.filesystem.readDirectory(folder); } catch { return null; }
      let mine = 0; try { mine = (await Neutralino.filesystem.getStats(p)).modifiedAt || 0; } catch {}
      let best = null;
      for (const e of ents) {
        if (e.type !== "FILE" || !/\.docx$/i.test(e.entry) || /^~\$/.test(e.entry) || e.entry === name || /\((?:corrected and )?linked\)/i.test(e.entry) || stem(e.entry) !== stem(name)) continue;
        const full = join(folder, e.entry); if (full.replace(/[\\/]+/g, "/") .split("/").length !== String(p).replace(/[\\/]+/g, "/").split("/").length) continue;
        let mt = 0; try { mt = (await Neutralino.filesystem.getStats(full)).modifiedAt || 0; } catch {}
        if (mt > mine && (!best || mt > best.mtime)) best = { path: full, name: e.entry, mtime: mt };
      }
      return best;
    },
    // a request to an AI program on this computer, sent with the system's curl (for programs that don't accept requests from apps)
    localHttp: async (url, body, key, timeoutSec) => {
      await ready;
      if (!/^http:\/\/(localhost|127\.0\.0\.1|10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+|172\.(1[6-9]|2\d|3[01])\.\d+\.\d+|[a-z0-9-]+\.local|[a-z0-9-]+)(:\d+)?\//i.test(url)) return { ok: false, status: 0, text: "" };
      let tmp; try { tmp = await Neutralino.os.getPath("temp"); } catch { tmp = await anchor(); }
      const tag = Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
      const inF = join(tmp, "citekeep-ai-" + tag + "-in.json"), outF = join(tmp, "citekeep-ai-" + tag + "-out.json");
      let cmd = (isWin() ? "curl.exe" : "curl") + ` -s --max-time ${Math.max(2, Math.min(3600, +timeoutSec || 900))} -o ${q(outF)} -w "%{http_code}"`;
      const k = String(key || "").replace(/[^\w.~+\/=-]/g, "");
      if (k) cmd += ` -H "Authorization: Bearer ${k}"`;
      if (body != null) { await Neutralino.filesystem.writeFile(inF, body); cmd += ` -H "Content-Type: application/json" --data-binary @${q(inF)}`; }
      cmd += " " + q(url);
      let status = 0, text = "";
      try { const r = await Neutralino.os.execCommand(cmd); status = parseInt(String(r.stdOut || "").trim(), 10) || 0; } catch {}
      try { text = await Neutralino.filesystem.readFile(outF); } catch {}
      for (const f of [inF, outF]) { try { await Neutralino.filesystem.remove(f); } catch {} }
      return { ok: status >= 200 && status < 300, status, text };
    },
    setSetting: async (k, v) => {
      if (!["pdfFolder", "gClientId", "gClientSecret", "aiProvider", "aiUrl", "aiModel", "aiUrls", "aiModels", "aiLocalKey", "aiCtx", "claudeModel", "claudeKey", "matrixTitle", "libraryChoice", "unpaywallEmail", "citeStyle", "lookTheme", "lookAccent", "lookSize", "recentDocs", "libSort", "settingsFolded", "seenVersion", "docAddRefs", "watchDownloads", "addFromDownloads", "aiRules", "lastUpdateCheck", "gPdfFolders", "roleList", "startTab"].includes(k)) return false;
      await setOne(k, k === "pdfFolder" ? await toPortable(v) : v);
      if (k === "gClientId" || k === "gClientSecret") { await setOne("gRefresh", null); token = null; }
      return true;
    },
    pickFolder: async () => { await ready; const f = await Neutralino.os.showFolderDialog("Choose your PDF folder"); if (!f) return null; const p = isWin() ? f.replace(/\//g, "\\") : f; await setOne("pdfFolder", await toPortable(p)); return p; },
    scanFolder: async folder => {
      await ready;
      const ents = await Neutralino.filesystem.readDirectory(folder, { recursive: true });
      const root = folder.replace(/[\\/]+$/, "").replace(/\\/g, "/");
      return ents.filter(e => e.type === "FILE" && /\.(pdf|docx?|xlsx?|pptx?)$/i.test(e.entry) && !/^~\$/.test(e.entry) && !/(^|[\\/])\./.test(e.path))
        .map(e => { const pth = e.path.replace(/\\/g, "/"); return { path: pth.startsWith(root + "/") ? pth.slice(root.length + 1) : e.entry, name: e.entry }; });
    },
    openPdf: async (folder, rel, page) => {
      await ready;
      const full = join(folder, rel);
      try { await Neutralino.filesystem.getStats(full); } catch { return "missing"; }
      try { await Neutralino.os.open("file:///" + full.replace(/\\/g, "/").replace(/^\/+/, "").split("/").map(encodeURIComponent).join("/").replace(/^([A-Za-z])%3A/, "$1:") + (page && /\.pdf$/i.test(rel) ? "#page=" + page : "")); return ""; }
      catch (e) { return "error"; }
    },
    pdfStats: async (folder, rel) => { await ready; try { const s = await Neutralino.filesystem.getStats(join(folder, rel)); return { size: s.size || 0, mtime: s.modifiedAt || 0 }; } catch { return null; } },
    readPdf: async (folder, rel) => { await ready; return await Neutralino.filesystem.readBinaryFile(join(folder, rel)); },
    loadPdfIndex: async () => { const d = await dir(); try { return await Neutralino.filesystem.readFile(join(d, "pdf-index.json")); } catch { return null; } },
    savePdfIndex: async json => { const d = await dir(); await Neutralino.filesystem.writeFile(join(d, "pdf-index.json"), json); return true; },
    saveFile: async (name, data) => {
      await ready;
      let def = name; try { def = join(await Neutralino.os.getPath("downloads"), name); } catch {}
      const p = await Neutralino.os.showSaveDialog("Save", { defaultPath: def, forceOverwrite: false });
      if (!p) return null;
      if (typeof data === "string") await Neutralino.filesystem.writeFile(p, data);
      else { const u8 = data instanceof Uint8Array ? data : new Uint8Array(data); await Neutralino.filesystem.writeBinaryFile(p, u8.buffer.slice(u8.byteOffset, u8.byteOffset + u8.byteLength)); }
      return p;
    },
    showFile: async p => { try { toast("Saved to " + p); } catch {} },
    openLink: async u => { await ready; if (/^https?:\/\//i.test(u)) await Neutralino.os.open(u); },

    googleSignIn: async () => {
      await ready;
      const s = await getS();
      if (!s.gClientId) return { ok: false, error: "Enter your Google Client ID first." };
      const verifier = b64url(crypto.getRandomValues(new Uint8Array(32)));
      const challenge = b64url(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier))));
      const state = b64url(crypto.getRandomValues(new Uint8Array(9)));
      pendingSignIn = { verifier, state, redirect: REDIRECT() };
      const url = "https://accounts.google.com/o/oauth2/v2/auth?" + new URLSearchParams({ client_id: s.gClientId, redirect_uri: pendingSignIn.redirect, response_type: "code", scope: "https://www.googleapis.com/auth/drive.metadata.readonly", code_challenge: challenge, code_challenge_method: "S256", access_type: "offline", prompt: "consent", state });
      await Neutralino.os.open(url);
      return { ok: false, pending: true };
    },
    googleFinish: async pasted => {
      const s = await getS();
      if (!pendingSignIn) return { ok: false, error: "Click Sign in to Google Drive first." };
      const m = String(pasted || "").trim().match(/^CK1:([^:]+):(.+)$/);
      if (!m) return { ok: false, error: "That doesn't look like the code from the Citekeep page. Copy it with the Copy button there." };
      if (m[1] !== pendingSignIn.state) return { ok: false, error: "That code is from an earlier sign-in. Click Sign in again." };
      const body = { code: m[2], client_id: s.gClientId, redirect_uri: pendingSignIn.redirect, grant_type: "authorization_code", code_verifier: pendingSignIn.verifier };
      if (s.gClientSecret) body.client_secret = s.gClientSecret;
      try {
        const j = await tokenRequest(body);
        if (j.refresh_token) await setOne("gRefresh", j.refresh_token);
        token = { token: j.access_token, exp: Date.now() + (j.expires_in - 60) * 1000 };
        pendingSignIn = null;
        return { ok: true };
      } catch (e) { return { ok: false, error: "Google refused the sign-in: " + e.message }; }
    },
    googleSignOut: async () => { await setOne("gRefresh", null); token = null; return true; },
    // read-only Drive lookups (file names, folders, dates, links; never contents)
    googleDrive: async (path, params) => {
      try {
        const tok = await accessToken();
        const r = await fetch("https://www.googleapis.com/drive/v3/" + path + (params ? "?" + new URLSearchParams(params) : ""), { headers: { Authorization: "Bearer " + tok } });
        const j = await r.json();
        if (r.status === 401) { token = null; return { ok: false, error: "NOT_SIGNED_IN" }; }
        if (!r.ok) return { ok: false, error: (j.error && j.error.message) || ("Google Drive answered " + r.status) };
        return { ok: true, data: j };
      } catch (e) { return { ok: false, error: e.message === "NOT_SIGNED_IN" ? "NOT_SIGNED_IN" : "Couldn't reach Google Drive." }; }
    },
    // PDFs in the Drive folders the person chose, and their subfolders; never the rest of the Drive
    googleListPdfs: async folderIds => {
      try {
        const tok = await accessToken();
        const ids = (folderIds || []).filter(Boolean);
        const FOLDER = "application/vnd.google-apps.folder";
        // PDFs, Word, Excel, PowerPoint, and Google Docs, Sheets and Slides
        const DRIVE_KINDS = ["application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/msword", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.presentationml.presentation", "application/vnd.ms-powerpoint", "application/vnd.google-apps.document", "application/vnd.google-apps.spreadsheet", "application/vnd.google-apps.presentation"];
        const files = [], gotFile = new Set(), seen = new Set(), queue = ids.slice(), missing = [];
        while (queue.length && seen.size < 5000) {
          const id = String(queue.shift()).replace(/[^A-Za-z0-9_-]/g, ""); if (!id || seen.has(id)) continue; seen.add(id);
          let pageToken = "";
          for (let i = 0; i < 50; i++) {
            const qs = new URLSearchParams({ q: `'${id}' in parents and trashed=false and (${DRIVE_KINDS.concat([FOLDER]).map(m => `mimeType='${m}'`).join(" or ")})`, fields: "nextPageToken, files(id, name, mimeType, webViewLink)", pageSize: "1000", includeItemsFromAllDrives: "true", supportsAllDrives: "true" });
            if (pageToken) qs.set("pageToken", pageToken);
            const r = await fetch("https://www.googleapis.com/drive/v3/files?" + qs, { headers: { Authorization: "Bearer " + tok } });
            const j = await r.json();
            if (r.status === 401) { token = null; throw new Error("NOT_SIGNED_IN"); }
            if (r.status === 404 && ids.includes(id)) { missing.push(id); break; }
            if (!r.ok) throw new Error("Google Drive didn't answer: " + ((j.error && j.error.message) || r.status));
            for (const f of j.files || []) {
              if (f.mimeType === FOLDER) queue.push(f.id);
              else if (DRIVE_KINDS.includes(f.mimeType) && !gotFile.has(f.id)) { gotFile.add(f.id); files.push({ id: f.id, name: f.name, webViewLink: f.webViewLink, mimeType: f.mimeType }); }
            }
            if (!j.nextPageToken) break; pageToken = j.nextPageToken;
          }
        }
        return { ok: true, files, missing };
      } catch (e) { return { ok: false, error: e.message }; }
    },
  };
  // Save before the window closes
  ready.then(() => {
    try {
      restoreWindow();
      Neutralino.events.on("windowClose", async () => {
        try { await saveWindow(); } catch {}
        try { if (typeof window.citekeepFlush === "function") await window.citekeepFlush(); } catch {}
        try { await window.citekeepApp.heartbeat(true); } catch {}
        Neutralino.app.exit();
      });
    } catch {}
  });
})();
