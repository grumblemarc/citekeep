// ===== One library on several computers: Google Drive (or OneDrive, Dropbox) carries library.json between them,
// and Citekeep merges what each computer changed, reference by reference. Nothing is overwritten: if both computers
// changed the same reference, the newer change is shown and the other is kept beside it to choose from.
// The same work added on both computers is kept once. =====
var SYNC = { base: null, mtime: 0, busy: false, timer: null, deleted: {} };
const SYNC_TOMB_DAYS = 180;

function syncStamp(it) { return +(it && (it.updated || it.created)) || 0; }
function syncStable(v) {
  if (Array.isArray(v)) return "[" + v.map(syncStable).join(",") + "]";
  if (v && typeof v === "object") return "{" + Object.keys(v).sort().filter(k => v[k] !== undefined).map(k => JSON.stringify(k) + ":" + syncStable(v[k])).join(",") + "}";
  return JSON.stringify(v === undefined ? null : v);
}
// the content of a reference, leaving out when it was saved and any other version kept beside it
function syncBody(it) { const { updated, alt, _suffix, ...r } = it || {}; return syncStable(r); }
function syncClean(it) { const { _suffix, ...r } = it; return r; }
function syncKeys(it) {
  const out = [], d = normDoi(it.doi); if (d) out.push("doi:" + d);
  const a = (it.authors || [])[0], who = a ? fold(a.family || a.org || "").toLowerCase() : "";
  const t = titleKey(it.title || htmlToText(it.refHtml || "")); if (t.length >= 15) out.push("t:" + t + "|" + (it.year || "") + "|" + who);
  return out;
}
// two different versions of one reference: show the newer, keep the other beside it
function syncBoth(a, b) {
  const [newer, older] = syncStamp(a) > syncStamp(b) || (syncStamp(a) === syncStamp(b) && syncBody(a) >= syncBody(b)) ? [a, b] : [b, a];
  const main = syncClean(newer), mainBody = syncBody(main), seen = new Set([mainBody]), alts = [];
  for (const v of [older].concat(newer.alt || [], older.alt || [])) { const c = syncClean(v); delete c.alt; const k = syncBody(c); if (!seen.has(k)) { seen.add(k); alts.push(c); } }
  if (alts.length) main.alt = alts; else delete main.alt;
  main.updated = Math.max(syncStamp(a), syncStamp(b));
  return main;
}

// L: this computer's references; D: the ones in the file; base: when each reference was last the same in both
// mode "file": the shared library.json; mode "copy": a conflict copy left by the sync app
function syncMerge(L, D, base, tomb, mode) {
  const byL = new Map(L.map(x => [x.id, x])), byD = new Map(D.map(x => [x.id, x]));
  const out = [], fresh = [], n = { added: 0, updated: 0, removed: 0, dups: 0, versions: 0 };
  for (const l of L) {
    const d = byD.get(l.id), b = base[l.id], tl = syncStamp(l);
    if (d) {
      const td = syncStamp(d);
      if (syncBody(l) === syncBody(d) && syncStable(l.alt || []) === syncStable(d.alt || [])) { out.push(td > tl ? d : l); continue; }
      if (mode === "copy" && b !== undefined && td <= b) { out.push(l); continue; }                 // an old copy of something since synced
      if (mode === "file" && b !== undefined && tl === b && td !== b) { out.push(d); n.updated++; continue; }   // changed only on the other computer
      if (mode === "file" && b !== undefined && td === b) { out.push(l); continue; }                // changed only here
      const m = syncBoth(l, d); if ((m.alt || []).length > (l.alt || []).length) n.versions++; out.push(m);
      continue;
    }
    if (tomb[l.id] && (b !== undefined ? tl <= b : tl <= tomb[l.id])) { n.removed++; continue; }  // deleted on the other computer
    if (tomb[l.id]) delete tomb[l.id];                                                          // changed here after it was deleted there: keep it
    out.push(l);
  }
  for (const d of D) {
    if (byL.has(d.id)) continue;
    const td = syncStamp(d);
    if (tomb[d.id] && td <= tomb[d.id]) continue;                                                // deleted here
    if (tomb[d.id]) delete tomb[d.id];
    if (base[d.id] !== undefined && mode === "file" && !tomb[d.id]) { out.push(d); continue; }
    fresh.push(d);
  }
  // added on the other computer: keep, unless the same work is already here
  const byKey = new Map(); out.forEach((x, i) => syncKeys(x).forEach(k => { if (!byKey.has(k)) byKey.set(k, i); }));
  for (const d of fresh) {
    const hit = syncKeys(d).map(k => byKey.get(k)).find(i => i !== undefined);
    if (hit === undefined) { out.push(d); syncKeys(d).forEach(k => byKey.set(k, out.length - 1)); n.added++; continue; }
    const x = out[hit];
    // keep the one entered first, filling its empty fields from the other; the other is set aside everywhere
    const firstX = (+x.created || Infinity) < (+d.created || Infinity) || ((+x.created || 0) === (+d.created || 0) && x.id < d.id);
    const [keep, drop] = firstX ? [x, d] : [d, x];
    const m = mergeInto(keep, drop); m.updated = Math.max(syncStamp(x), syncStamp(d));
    out[hit] = m; tomb[drop.id] = Date.now(); n.dups++;
  }
  return { items: out, n };
}

async function syncReadJson(name) { try { const t = await window.citekeepApp.readText(name); return t ? JSON.parse(t) : null; } catch (e) { return undefined; } }
function syncSummary(n) {
  const p = [];
  if (n.added) p.push(`${n.added} reference${n.added === 1 ? "" : "s"} added`);
  if (n.updated) p.push(`${n.updated} updated`);
  if (n.removed) p.push(`${n.removed} deleted`);
  if (n.dups) p.push(`${n.dups} duplicate${n.dups === 1 ? "" : "s"} skipped`);
  if (n.versions) p.push(`${n.versions} changed on both computers (both versions kept; look for "2 versions")`);
  return p.join(", ");
}

// read the shared file, merge, and write it back if anything differs; used for every save and when the file changes
async function syncRun(why) {
  if (!SYNC.base) { await window.citekeepApp.saveLibrary(libJson()); return; }
  while (SYNC.busy) await new Promise(r => setTimeout(r, 100));
  SYNC.busy = true;
  try {
    let D = await syncReadJson("library.json");
    if (D === undefined) { await new Promise(r => setTimeout(r, 1500)); D = await syncReadJson("library.json"); }   // caught mid-sync
    const fileTomb = (await syncReadJson("library-deleted.json")) || {};
    const tomb = Object.assign({}, fileTomb); for (const [k, v] of Object.entries(SYNC.deleted)) tomb[k] = Math.max(tomb[k] || 0, v);
    const before = syncStable(items.map(syncClean)), total = { added: 0, updated: 0, removed: 0, dups: 0, versions: 0 };
    let merged = items.map(syncClean);
    const add = n => { for (const k in total) total[k] += n[k]; };
    if (Array.isArray(D)) { const r = syncMerge(merged, D, SYNC.base, tomb, "file"); merged = r.items; add(r.n); }
    // conflict copies the sync app left beside library.json
    let copies = []; try { copies = await window.citekeepApp.conflictCopies(); } catch (e) {}
    for (const c of copies) {
      const C = await syncReadJson(c); if (!Array.isArray(C)) continue;
      const r = syncMerge(merged, C, SYNC.base, tomb, "copy"); merged = r.items; add(r.n);
      try { await window.citekeepApp.setAsideCopy(c); } catch (e) {}
    }
    const cut = Date.now() - SYNC_TOMB_DAYS * 864e5; for (const k in tomb) if (tomb[k] < cut) delete tomb[k];
    const changedHere = syncStable(merged) !== before;
    if (changedHere) { const keepSel = selectedId; items = merged; if (keepSel && !items.some(x => x.id === keepSel)) selectedId = null; }
    if (!Array.isArray(D) || syncStable(merged) !== syncStable(D)) await window.citekeepApp.saveLibrary(libJson());
    if (syncStable(tomb) !== syncStable(fileTomb)) { try { await window.citekeepApp.writeText("library-deleted.json", JSON.stringify(tomb)); } catch (e) {} }
    SYNC.deleted = {};
    SYNC.base = {}; for (const x of items) SYNC.base[x.id] = syncStamp(x);
    try { SYNC.mtime = (await window.citekeepApp.libraryStat()).mtime; } catch (e) {}
    if (changedHere && !editing) renderAll();
    const msg = syncSummary(total);
    if (msg) toast((DATA.info && DATA.info.elsewhere ? "From your other computer: " : "Merged: ") + msg + ".");
  } finally { SYNC.busy = false; }
}
function syncNoteDelete(id) { SYNC.deleted[id] = Date.now(); }

// start after the library is loaded: what's on disk now is what both sides agree on
async function syncStart() {
  if (!window.citekeepApp || !window.citekeepApp.libraryStat) return;
  SYNC.base = {}; for (const x of items) SYNC.base[x.id] = syncStamp(x);
  try { SYNC.mtime = (await window.citekeepApp.libraryStat()).mtime; } catch (e) {}
  const check = async () => {
    if (SYNC.busy || saveBusy || editing) return;
    let st = null; try { st = await window.citekeepApp.libraryStat(); } catch (e) { return; }
    let copies = []; try { copies = await window.citekeepApp.conflictCopies(); } catch (e) {}
    if (st.mtime !== SYNC.mtime || copies.length) { try { await syncRun("changed"); } catch (e) {} }
  };
  SYNC.timer = setInterval(check, 15000);
  window.addEventListener("focus", check);
  setTimeout(check, 3000);
}

// shared files of results (claim checks): keep what either computer saved
async function syncWriteJson(name, data) {
  const disk = await syncReadJson(name);
  if (disk && typeof disk === "object") for (const k of Object.keys(disk)) if (!(k in data)) data[k] = disk[k];
  await window.citekeepApp.writeText(name, JSON.stringify(data));
}

// ---------- choosing between two versions of a reference ----------
function syncAltHtml(it) {
  if (!it || !(it.alt || []).length) return "";
  const when = t => t ? new Date(t).toLocaleString([], { dateStyle: "medium", timeStyle: "short" }) : "an unknown time";
  return `<div class="banner" style="margin:0">This reference was changed on two computers before they synced. You're seeing the newer change (${esc(when(it.updated))}).
    <details style="margin-top:6px"><summary style="cursor:pointer">Compare the other version${it.alt.length > 1 ? "s" : ""}</summary>
      ${it.alt.map((a, i) => `<div style="margin:8px 0;padding:8px;background:var(--surface);border:1px solid var(--line);border-radius:var(--r)">
        <div class="note">Saved ${esc(when(a.updated))}</div>
        <div class="refcard" style="margin:4px 0">${formatReference(Object.assign({}, a, { id: it.id }))}</div>
        ${a.notes !== it.notes && (a.notes || it.notes) ? `<div class="note">Notes differ: ${esc((a.notes || "(none)").slice(0, 200))}</div>` : ""}
        ${syncStable(a.mx || {}) !== syncStable(it.mx || {}) ? `<div class="note">Its matrix row differs too.</div>` : ""}
        ${syncStable(a.tags || []) !== syncStable(it.tags || []) ? `<div class="note">Tags: ${esc((a.tags || []).join(", ") || "(none)")}</div>` : ""}
        <button class="btn" data-syncuse="${i}">Use this version</button></div>`).join("")}
    </details>
    <div class="row" style="margin-top:6px"><button class="btn" data-synckeep="1">Keep the version shown</button></div></div>`;
}
document.addEventListener("click", async e => {
  const keep = e.target.closest("[data-synckeep]"), use = e.target.closest("[data-syncuse]");
  if (!keep && !use) return;
  const it = items.find(x => x.id === selectedId); if (!it || !(it.alt || []).length) return;
  let next;
  if (keep) { next = clone(it); delete next.alt; }
  else { const a = it.alt[+use.dataset.syncuse]; if (!a) return; next = Object.assign(clone(a), { id: it.id }); delete next.alt; }
  delete next.updated;
  await saveItem(next);
  toast(keep ? "Kept the version shown" : "Switched to the other version");
});

// ---------- hooks into saving, deleting and showing references ----------
persist = async function () {
  saveDirty = true;
  if (saveBusy) return;
  saveBusy = true;
  try { while (saveDirty) { saveDirty = false; await syncRun("save"); } }
  catch (e) { toast("Couldn't save your library file."); setStatus(false, "Not saved"); }
  saveBusy = false;
};
window.citekeepFlush = async () => { try { await syncRun("close"); } catch (e) { await window.citekeepApp.saveLibrary(libJson()); } };
{ const del = deleteItem; deleteItem = async function (id) { syncNoteDelete(id); return del(id); }; }
{ const rl = renderList; renderList = function () { rl(); for (const b of document.querySelectorAll("#list .item[data-id]")) { const it = items.find(x => x.id === b.dataset.id); const c = b.querySelector(".cite"); if (it && (it.alt || []).length && c) c.insertAdjacentHTML("beforeend", ` <span class="pill warn" style="font-size:10px;padding:0 6px">2 versions</span>`); } }; }
{ const rd = renderDetail; renderDetail = function () { rd(); if (editing) return; const it = items.find(x => x.id === selectedId); const rc = document.querySelector("#detail .refcard"); if (it && rc && (it.alt || []).length) rc.insertAdjacentHTML("beforebegin", syncAltHtml(it)); }; }
(function wait() { if (typeof loaded !== "undefined" && loaded) syncStart(); else setTimeout(wait, 300); })();
