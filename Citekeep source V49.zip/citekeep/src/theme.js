// ===== Appearance: light or dark, an accent color, and text size. Kept per computer. =====
const ACCENTS = {
  green: { name: "Green", light: ["#2C6A4E", "#FFFFFF", "#E2EEE7"], dark: ["#6FBF98", "#0E1A14", "#1F3229"] },
  blue: { name: "Blue", light: ["#2B5C9E", "#FFFFFF", "#E1E9F5"], dark: ["#82AAE3", "#0D1522", "#1D2838"] },
  teal: { name: "Teal", light: ["#1F6E73", "#FFFFFF", "#DDEFF0"], dark: ["#6CC3C8", "#0B1A1B", "#1A3133"] },
  purple: { name: "Purple", light: ["#5E4A9C", "#FFFFFF", "#EAE5F5"], dark: ["#A99AE2", "#15111F", "#272238"] },
  burgundy: { name: "Burgundy", light: ["#8A2E45", "#FFFFFF", "#F4E2E7"], dark: ["#E38FA4", "#1F0E14", "#36202A"] },
  slate: { name: "Slate", light: ["#3E5363", "#FFFFFF", "#E3E8EC"], dark: ["#A2B6C5", "#0F161C", "#222B33"] },
};
const TEXT_SIZES = { standard: { name: "Standard", zoom: 1 }, larger: { name: "Larger", zoom: 1.12 }, largest: { name: "Largest", zoom: 1.25 } };
var LOOK = { theme: "system", accent: "green", textSize: "standard", home: "write" };

function applyLook() {
  const root = document.documentElement;
  if (LOOK.theme === "light" || LOOK.theme === "dark") root.setAttribute("data-theme", LOOK.theme); else root.removeAttribute("data-theme");
  const a = ACCENTS[LOOK.accent] || ACCENTS.green;
  const vars = v => `--accent:${v[0]};--accent-ink:${v[1]};--accent-soft:${v[2]};`;
  let st = document.getElementById("ckAccent");
  if (!st) { st = document.createElement("style"); st.id = "ckAccent"; document.head.appendChild(st); }
  st.textContent = LOOK.accent === "green" ? "" : `:root{${vars(a.light)}}@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){${vars(a.dark)}}}:root[data-theme="dark"]{${vars(a.dark)}}`;
  document.body.style.zoom = (TEXT_SIZES[LOOK.textSize] || TEXT_SIZES.standard).zoom;
  try { localStorage.setItem("ck-look", JSON.stringify(LOOK)); } catch (e) {}
}
// the last look used, at once (before the settings file is read), so the window doesn't flash
try { Object.assign(LOOK, JSON.parse(localStorage.getItem("ck-look") || "{}")); applyLook(); } catch (e) {}

function renderLookCard() {
  const cols = document.getElementById("settingsCols"); if (!cols) return;
  let c = document.getElementById("lookCard");
  if (!c) { c = document.createElement("div"); c.className = "card"; c.id = "lookCard"; const after = document.getElementById("styleCard"); cols.insertBefore(c, after ? after.nextSibling : cols.firstChild); }
  const opt = (obj, cur) => Object.keys(obj).map(k => `<option value="${k}" ${k === cur ? "selected" : ""}>${esc(obj[k].name)}</option>`).join("");
  c.innerHTML = `<h3 style="margin:0">Appearance</h3>
    <label class="f"><span>Light or dark</span><select id="lkTheme"><option value="system" ${LOOK.theme === "system" ? "selected" : ""}>Match Windows</option><option value="light" ${LOOK.theme === "light" ? "selected" : ""}>Light</option><option value="dark" ${LOOK.theme === "dark" ? "selected" : ""}>Dark</option></select></label>
    <div class="f"><span style="font-size:12px;color:var(--muted);font-weight:500;text-transform:uppercase;letter-spacing:.05em">Accent color</span><div class="row" role="radiogroup" aria-label="Accent color" style="gap:8px">${Object.keys(ACCENTS).map(k => {
      const v = ACCENTS[k]; const on = k === LOOK.accent;
      return `<button type="button" role="radio" aria-checked="${on}" data-accent="${k}" title="${esc(v.name)}" style="width:30px;height:30px;border-radius:50%;cursor:pointer;background:linear-gradient(135deg,${v.light[0]} 50%,${v.dark[0]} 50%);border:2px solid ${on ? "var(--ink)" : "var(--line)"};box-shadow:${on ? "0 0 0 2px var(--surface) inset" : "none"}"></button>`;
    }).join("")}</div></div>
    <label class="f"><span>Text size</span><select id="lkSize">${opt(TEXT_SIZES, LOOK.textSize)}</select></label>
    <label class="f"><span>Opening screen</span><select id="lkHome"><option value="write" ${LOOK.home !== "library" ? "selected" : ""}>Write</option><option value="library" ${LOOK.home === "library" ? "selected" : ""}>Library</option></select></label>
    <p class="note" style="margin:0">Kept on this computer only.</p>`;
  const save = async (k, v) => { LOOK[k] = v; applyLook(); try { await window.citekeepApp.setSetting(k === "theme" ? "lookTheme" : k === "accent" ? "lookAccent" : "lookSize", v); } catch (e) {} };
  c.querySelector("#lkTheme").onchange = e => save("theme", e.target.value);
  c.querySelector("#lkSize").onchange = e => save("textSize", e.target.value);
  c.querySelector("#lkHome").onchange = async e => { LOOK.home = e.target.value; try { localStorage.setItem("ck-home", LOOK.home); } catch (x) {} try { await window.citekeepApp.setSetting("startTab", LOOK.home); } catch (x) {} };
  c.querySelectorAll("[data-accent]").forEach(b => b.onclick = async () => { await save("accent", b.dataset.accent); renderLookCard(); });
}
(function () {
  const go = async () => {
    try {
      const s = await window.citekeepApp.getSettings();
      if (s.lookTheme) LOOK.theme = s.lookTheme; if (ACCENTS[s.lookAccent]) LOOK.accent = s.lookAccent; if (TEXT_SIZES[s.lookSize]) LOOK.textSize = s.lookSize; if (s.startTab) { LOOK.home = s.startTab; try { localStorage.setItem("ck-home", s.startTab); } catch (x) {} }
    } catch (e) {}
    applyLook(); renderLookCard();
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", go); else setTimeout(go, 0);
})();
