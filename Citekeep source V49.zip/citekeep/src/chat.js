// ===== Write: a chat with your AI program, drawing on the sources you choose =====
// Conversations are kept in chats.json in Citekeep's data folder. The AI program is the one set in Settings → AI drafting.
var CHAT = { list: [], cur: null, busy: false, ctrl: null, loaded: false, texts: new Map() };

// ---------- storage ----------
async function chatLoad() {
  if (CHAT.loaded) return;
  try { const j = JSON.parse((await window.citekeepApp.readText("chats.json")) || "[]"); CHAT.list = Array.isArray(j) ? j : []; } catch (e) { CHAT.list = []; }
  CHAT.loaded = true;
}
let chatSaveTimer = null;
function chatSave(now) {
  clearTimeout(chatSaveTimer);
  const go = async () => { try { await window.citekeepApp.writeText("chats.json", JSON.stringify(CHAT.list)); } catch (e) {} };
  if (now) return go(); chatSaveTimer = setTimeout(go, 600);
}
function chatCur() { return CHAT.list.find(c => c.id === CHAT.cur) || null; }
function chatNew() {
  const c = { id: "c" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), title: "New chat", created: Date.now(), updated: Date.now(), sources: { mode: "none", text: true }, messages: [] };
  CHAT.list.unshift(c); CHAT.cur = c.id; chatSave(); return c;
}

// ---------- sources ----------
const SRC_MODES = { none: "No sources", all: "Whole library", tag: "References with a tag", kind: "A source kind", role: "One of my categories", pick: "References I pick" };
function chatSourceItems(c) {
  const S = (c && c.sources) || { mode: "none" };
  if (S.mode === "all") return items.slice();
  if (S.mode === "tag" && S.tag) return items.filter(i => (i.tags || []).some(t => t === S.tag || t.startsWith(S.tag + "/")));
  if (S.mode === "kind" && S.kind) return items.filter(i => i.srcKind === S.kind);
  if (S.mode === "role" && S.role) return items.filter(i => i.role === S.role);
  if (S.mode === "pick") { const ids = new Set(S.ids || []); return items.filter(i => ids.has(i.id)); }
  return [];
}
function chatSourceLabel(c) {
  const S = c.sources || {}, n = chatSourceItems(c).length;
  if (S.mode === "none" || !S.mode) return "No sources";
  const what = S.mode === "all" ? "Whole library" : S.mode === "tag" ? `Tag: ${S.tag}` : S.mode === "kind" ? kindName(S.kind) : S.mode === "role" ? roleName(S.role) : "Picked";
  return `${what} · ${n} reference${n === 1 ? "" : "s"}${S.text !== false ? " · with text" : ""}`;
}
async function chatFileText(it) {
  if (!itemPdfLocal(it) || typeof readPdfFull !== "function") return "";
  if (CHAT.texts.has(it.file)) return CHAT.texts.get(it.file);
  let t = ""; try { t = await readPdfFull(it.file); } catch (e) { t = ""; }
  CHAT.texts.set(it.file, t); return t;
}
// the source block sent with each message: every source's reference and matrix row, then as much text as fits
async function chatContext(c, budget, onStatus) {
  const att = chatFilesBlock(c, Math.floor(budget * (chatSourceItems(c).length ? 0.7 : 1)));
  const rest = await chatSourcesBlock(c, budget - att.text.length, onStatus);
  return Object.assign(rest, { text: [att.text, rest.text].filter(Boolean).join("\n\n"), files: att.n, filesCut: att.cut });
}
function chatFilesBlock(c, budget) {
  const fs = c.files || []; if (!fs.length) return { text: "", n: 0, cut: 0 };
  const per = Math.floor((budget - 200) / fs.length); let cut = 0;
  const parts = fs.map((f, i) => { const fit = fitText(f.text, Math.max(1500, per)); if (fit.cut) cut++; return `[F${i + 1}] ${f.name}${f.pages ? ` (${f.pages} ${/PowerPoint/.test(f.kind) ? "slide" : /PDF/.test(f.kind) ? "page" : "part"}${f.pages === 1 ? "" : "s"})` : ""}:\n${fit.text}`; });
  return { text: "ATTACHED FILES\n\n" + parts.join("\n\n"), n: fs.length, cut };
}
async function chatSourcesBlock(c, budget, onStatus) {
  const list = chatSourceItems(c); if (!list.length) return { text: "", n: 0, withText: 0, cut: 0 };
  const st = CITE.style;
  const head = list.map((it, i) => {
    const f = citeForms(it); const m = it.mx || {};
    const row = ["sample", "method", "framework", "design", "findings"].filter(k => m[k]).map(k => `  ${k[0].toUpperCase() + k.slice(1)}: ${m[k]}`).join("\n");
    return `[S${i + 1}] ${htmlToText(formatReference(it, st))}\n  Cite as: ${f.parenthetical} or ${f.narrative}${it.srcKind ? `\n  Kind: ${kindName(it.srcKind)}` : ""}${row ? "\n" + row : ""}${it.abstract ? `\n  Abstract: ${String(it.abstract).slice(0, 1500)}` : ""}`;
  });
  let text = "SOURCES\n\n" + head.join("\n\n");
  let left = budget - text.length, withText = 0, cut = 0;
  if ((c.sources || {}).text !== false && left > 3000) {
    const files = list.filter(itemPdfLocal);
    const per = files.length ? Math.max(2500, Math.floor(left / files.length)) : 0;
    const parts = [];
    for (let i = 0; i < files.length && left > 2500; i++) {
      if (onStatus) onStatus(`Reading your sources: ${i + 1} of ${files.length}…`);
      const full = await chatFileText(files[i]); if (!full) continue;
      const fit = fitText(full, Math.min(per, left - 200));
      parts.push(`[S${list.indexOf(files[i]) + 1}] TEXT of ${citeForms(files[i]).parenthetical}:\n${fit.text}`);
      left -= fit.text.length + 80; withText++; if (fit.cut) cut++;
    }
    if (parts.length) text += "\n\nFULL TEXT OF SOURCES (pages marked)\n\n" + parts.join("\n\n");
  }
  return { text, n: list.length, withText, cut };
}
function chatSystem(c, ctx) {
  const st = STYLES[CITE.style] ? STYLES[CITE.style].name : "APA 7";
  return `You are a writing assistant inside Citekeep, a reference manager, helping the user write academic work: drafts, outlines, literature reviews, thesis statements, summaries, revisions, anything they ask for.
${ctx.n ? `The user has given you ${ctx.n} source${ctx.n === 1 ? "" : "s"}, listed below with their references, any matrix notes they made (sample, method, framework, design, findings), and${ctx.withText ? " the text of " + ctx.withText + " of them" : " no full text"}.
When you use a source, cite it in ${st} style exactly as its "Cite as" line shows, and add page numbers for quotations. Cite only the sources listed. If the sources don't cover something the user asks for, say so plainly rather than inventing sources or findings.` : `No sources are attached to this chat. If the user asks for citations, tell them to attach sources with the Sources button, and don't invent references.`}
${ctx.files ? `The user attached ${ctx.files} file${ctx.files === 1 ? "" : "s"}, shown under ATTACHED FILES; refer to them by file name. They are the user's own material (a draft, notes, a rubric, an article), not entries in the source list, unless they match one.\n` : ""}Write in clear academic prose. Use Markdown for structure: # headings, **bold**, *italics*, and "- " lists.${ctx.text ? "\n\n" + ctx.text : ""}`;
}

// ---------- files attached to a chat: their text, kept with the chat ----------
const ATTACH_OK = /\.(pdf|docx|xlsx|pptx|txt|md|markdown|csv|tsv|json|html?|rtf)$/i;
async function pdfBufferText(buf) {
  if (!pdfjsLib.GlobalWorkerOptions.workerSrc) pdfjsLib.GlobalWorkerOptions.workerSrc = "/js/pdf.worker.min.js";
  const doc = await pdfjsLib.getDocument({ data: new Uint8Array(buf), isEvalSupported: false, disableFontFace: true, stopAtErrors: false, verbosity: 0 }).promise;
  const out = [];
  for (let n = 1; n <= doc.numPages; n++) { const pg = await doc.getPage(n); const tc = await pg.getTextContent(); out.push(`=== page ${n} ===\n` + tc.items.map(x => (x.str || "") + (x.hasEOL ? "\n" : " ")).join("").replace(/[ \t]+/g, " ").trim()); pg.cleanup(); }
  const pages = doc.numPages; await doc.destroy(); return { text: out.join("\n\n"), pages };
}
async function readAttachment(file) {
  const name = file.name || "file";
  if (/\.(doc|xls|ppt)$/i.test(name)) throw new Error(`${name} is an older Office file. Save it as .docx, .xlsx or .pptx and attach that.`);
  if (!ATTACH_OK.test(name)) throw new Error(`Citekeep can't read ${name}. Attach a PDF, Word, Excel, PowerPoint or text file.`);
  const buf = await file.arrayBuffer();
  let text = "", pages = 0;
  if (/\.pdf$/i.test(name)) { const r = await pdfBufferText(buf); text = r.text; pages = r.pages; }
  else if (/\.(docx|xlsx|pptx)$/i.test(name)) { const r = await officeParts(buf, name); text = r.parts.map((p, i) => /\.pptx$/i.test(name) ? `=== slide ${i + 1} ===\n${p}` : p).join("\n\n"); pages = r.parts.length; }
  else { text = new TextDecoder().decode(buf); if (/\.html?$/i.test(name)) text = htmlToText(text); if (/\.rtf$/i.test(name)) text = text.replace(/\\par[d]?/g, "\n").replace(/\{\\\*[^{}]*\}|\\[a-z]+-?\d* ?|[{}]/gi, ""); }
  text = text.replace(/\u0000/g, "").trim();
  if (text.replace(/\s+/g, "").length < 20) throw new Error(`${name} has no readable text${/\.pdf$/i.test(name) ? " (it may be a scan)" : ""}.`);
  return { id: "f" + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), name, kind: fileKind(name) || name.split(".").pop().toUpperCase(), pages, chars: text.length, text: text.slice(0, 600000) };
}
async function chatAttach(list) {
  const files = [...list]; if (!files.length) return;
  const c = chatCur() || chatNew(); c.files = c.files || [];
  const bad = [];
  for (const f of files) {
    const st = document.getElementById("ckStatus"); if (st) st.textContent = `Reading ${f.name}…`;
    try { const a = await readAttachment(f); c.files = c.files.filter(x => x.name !== a.name); c.files.push(a); } catch (e) { bad.push(e.message); }
  }
  c.updated = Date.now(); chatSave(); await renderChat();
  if (bad.length) toast(bad.join(" "));
}

// ---------- talking to the AI program, word by word where it can ----------
function chatStrip(raw) { return String(raw || "").replace(/<think>[\s\S]*?(<\/think>|$)/gi, "").replace(/^[\s\S]*?<\/think>/i, "").replace(/^\s+/, ""); }
async function chatStream(system, msgs, signal, onText) {
  const s = AI.settings; let raw = "";
  const push = t => { raw += t; onText(raw); };
  const sse = async (r, pick) => {
    const rd = r.body.getReader(), dec = new TextDecoder(); let buf = "";
    for (;;) {
      const { value, done } = await rd.read(); if (done) break;
      buf += dec.decode(value, { stream: true });
      let i; while ((i = buf.indexOf("\n")) >= 0) {
        const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
        if (!line) continue;
        const data = line.startsWith("data:") ? line.slice(5).trim() : line;
        if (data === "[DONE]") continue;
        try { const t = pick(JSON.parse(data)); if (t) push(t); } catch (e) {}
      }
    }
  };
  if (s.provider === "claude") {
    const key = await window.citekeepApp.claudeKey();
    if (!key) throw new Error("Enter your Claude API key in Settings → AI drafting.");
    let r;
    try { r = await fetch("https://api.anthropic.com/v1/messages", { method: "POST", signal, headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" }, body: JSON.stringify({ model: s.claudeModel, max_tokens: 8000, stream: true, system, messages: msgs }) }); }
    catch (e) { if (e.name === "AbortError") throw e; throw new Error("Couldn't reach the Claude API. Check your internet connection."); }
    if (!r.ok) { const j = await r.json().catch(() => ({})); throw new Error(r.status === 401 ? "The Claude API key was refused. Check it in Settings → AI drafting." : "Claude API: " + ((j.error && j.error.message) || r.status)); }
    await sse(r, j => j.type === "content_block_delta" && j.delta && j.delta.text);
    return raw;
  }
  const P = aiProv(s), base = aiBase(s);
  if (!base) throw new Error("Set up an AI program in Settings → AI drafting.");
  const qwen = /qwen3/i.test(s.model || "");
  const messages = [{ role: "system", content: system }].concat(msgs.map((m, i) => i === msgs.length - 1 && qwen && m.role === "user" ? { role: "user", content: m.content + "\n\n/no_think" } : m));
  const key = s.hasLocalKey && window.citekeepApp.aiLocalKey ? await window.citekeepApp.aiLocalKey() : "";
  const headers = { "content-type": "application/json" }; if (key) headers.authorization = "Bearer " + key;
  let model = s.model;
  if (P.api === "ollama" && !model) { const ids = await aiListModels(s, 8000); if (!ids || !ids.length) throw new Error(`Couldn't find a model in Ollama. ${P.down}`); model = ids[0]; }
  const url = P.api === "ollama" ? base + "/api/chat" : base + aiPath(s, "/chat/completions");
  const body = P.api === "ollama" ? { model, messages, stream: true, options: { num_ctx: s.ctx, temperature: 0.6, num_predict: 4000 } } : Object.assign({ messages, temperature: 0.6, max_tokens: 4000, stream: true }, model ? { model } : {});
  let r = null;
  try { r = await fetch(url, { method: "POST", signal, headers, body: JSON.stringify(body) }); } catch (e) { if (e.name === "AbortError") throw e; r = null; }
  if (r && r.ok && r.body) {
    await sse(r, P.api === "ollama" ? (j => j.message && j.message.content) : (j => j.choices && j.choices[0] && j.choices[0].delta && j.choices[0].delta.content));
    return raw;
  }
  // the program blocks requests from apps, or doesn't stream: ask again without streaming (through the system's curl if needed)
  body.stream = false; CHAT.nostream = true;
  const res = await aiHttp(url, body, signal);
  if (!res.status) throw new Error(`Couldn't reach ${P.name} at ${base}. ${P.down}`);
  let j = {}; try { j = JSON.parse(res.text); } catch (e) {}
  if (!res.ok) {
    const m = String((j.error && (j.error.message || j.error)) || res.text || res.status).slice(0, 300);
    if (/context|token/i.test(m) && /length|exceed|overflow|too|limit|truncat/i.test(m)) throw new Error(`The sources and conversation are longer than the context length ${P.name} is using. Attach fewer sources, untick "include the text", or load the model with a larger context.`);
    throw new Error(res.status === 401 || res.status === 403 ? `${P.name} refused the request. If it uses an API key, enter it in Settings → AI drafting.` : P.name + ": " + m);
  }
  push(P.api === "ollama" ? ((j.message && j.message.content) || "") : (((j.choices || [])[0] || {}).message || {}).content || "");
  return raw;
}

// ---------- citations in a reply: which of your sources it cites, and any it cites that aren't in your library ----------
function chatCites(text, c) {
  const src = chatSourceItems(c), hit = [];
  for (const it of src.length ? src : items) {
    const f = citeForms(it);
    const keys = [f.parenthetical.replace(/^\(|\)$/g, ""), f.narrative].map(k => k.trim()).filter(k => k.length > 3);
    if (keys.some(k => text.includes(k))) hit.push(it);
  }
  return hit;
}
function chatUnknownCites(text) {
  const out = new Set();
  const known = items.map(it => { const f = citeForms(it); return (f.parenthetical + " " + f.narrative).toLowerCase(); }).join(" | ");
  for (const m of String(text).matchAll(/\(([^()]*?\b(?:19|20)\d\d[a-z]?[^()]*?)\)/g)) {
    for (const part of m[1].split(";")) {
      const pm = part.match(/([A-Z][A-Za-z'’\-]+)(?:[^,]*)?,\s*((?:19|20)\d\d[a-z]?)/); if (!pm) continue;
      const surname = pm[1].toLowerCase(), yr = pm[2];
      const re = new RegExp(surname.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "[^|]{0,60}" + yr);
      if (!re.test(known)) out.add(part.trim().replace(/^(e\.g\.,|see also|see)\s+/i, ""));
    }
  }
  return [...out];
}

// ---------- Markdown to the page, and to Word ----------
function mdBlocks(text) {
  const lines = String(text).replace(/\r/g, "").split("\n"), out = []; let para = [], list = null;
  const flush = () => { if (para.length) { out.push({ t: "p", s: para.join(" ") }); para = []; } if (list) { out.push(list); list = null; } };
  for (const l of lines) {
    const h = l.match(/^(#{1,4})\s+(.*)$/), li = l.match(/^\s*(?:[-*•]|\d+[.)])\s+(.*)$/);
    if (!l.trim()) { flush(); continue; }
    if (h) { flush(); out.push({ t: "h", lv: h[1].length, s: h[2] }); continue; }
    if (li) { if (para.length) { out.push({ t: "p", s: para.join(" ") }); para = []; } if (!list) list = { t: "ul", items: [], ordered: /^\s*\d/.test(l) }; list.items.push(li[1]); continue; }
    if (list) { out.push(list); list = null; }
    para.push(l.trim());
  }
  flush(); return out;
}
function mdInlineHtml(s, unknown) {
  let h = esc(s).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/(^|[^*])\*([^*\n]+?)\*(?!\*)/g, "$1<i>$2</i>").replace(/(^|[^_])_([^_\n]+?)_(?!_)/g, "$1<i>$2</i>");
  for (const u of unknown || []) { const e = esc(u); if (e.length > 4) h = h.split(e).join(`<span class="ck-unk" title="Not in your library">${e}</span>`); }
  return h;
}
function mdHtml(text, unknown) {
  return mdBlocks(text).map(b => b.t === "h" ? `<h${Math.min(6, b.lv + 2)} class="ck-mh">${mdInlineHtml(b.s, unknown)}</h${Math.min(6, b.lv + 2)}>` : b.t === "ul" ? `<${b.ordered ? "ol" : "ul"}>${b.items.map(x => `<li>${mdInlineHtml(x, unknown)}</li>`).join("")}</${b.ordered ? "ol" : "ul"}>` : `<p>${mdInlineHtml(b.s, unknown)}</p>`).join("");
}
function mdToItalHtml(s) { return esc(s).replace(/\*\*(.+?)\*\*/g, "$1").replace(/(^|[^*])\*([^*\n]+?)\*(?!\*)/g, "$1<i>$2</i>").replace(/(^|[^_])_([^_\n]+?)_(?!_)/g, "$1<i>$2</i>"); }
function wordRuns(s) {
  // bold and italics from Markdown, as Word runs
  const x = t => t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const toks = String(s).split(/(\*\*[^*]+\*\*|\*[^*\n]+\*)/g).filter(Boolean);
  return toks.map(t => { const b = /^\*\*.*\*\*$/.test(t), i = !b && /^\*.*\*$/.test(t); const v = b ? t.slice(2, -2) : i ? t.slice(1, -1) : t; return `<w:r>${b || i ? `<w:rPr>${b ? "<w:b/>" : ""}${i ? "<w:i/>" : ""}</w:rPr>` : ""}<w:t xml:space="preserve">${x(v)}</w:t></w:r>`; }).join("");
}
async function chatSaveWord(text, cited, title) {
  const sp = `<w:spacing w:line="480" w:lineRule="auto" w:after="0"/>`;
  let body = mdBlocks(text).map(b => {
    if (b.t === "h") return `<w:p><w:pPr>${sp}${b.lv <= 1 ? '<w:jc w:val="center"/>' : ""}</w:pPr>${wordRuns("**" + b.s.replace(/\*\*/g, "") + "**")}</w:p>`;
    if (b.t === "ul") return b.items.map((x, i) => `<w:p><w:pPr>${sp}<w:ind w:left="720" w:hanging="360"/></w:pPr><w:r><w:t xml:space="preserve">${b.ordered ? i + 1 + "." : "•"}\t</w:t></w:r>${wordRuns(x)}</w:p>`).join("");
    return `<w:p><w:pPr>${sp}<w:ind w:firstLine="720"/></w:pPr>${wordRuns(b.s)}</w:p>`;
  }).join("");
  if (cited.length) {
    const st = CITE.style, H = styleListHtml(STYLES[st] ? sortForStyle(cited, st) : cited, st);
    body += `<w:p><w:r><w:br w:type="page"/></w:r></w:p><w:p><w:pPr>${sp}<w:jc w:val="center"/></w:pPr><w:r>${st === "apa" ? "<w:rPr><w:b/></w:rPr>" : ""}<w:t>${STYLES[st].list}</w:t></w:r></w:p>` +
      H.map(x => `<w:p><w:pPr>${sp}<w:ind w:left="720" w:hanging="720"/></w:pPr>${runsXml(x)}</w:p>`).join("");
  }
  await saveDocxBody(body, (title || "Citekeep draft").replace(/[\\/:*?"<>|]+/g, " ").slice(0, 80) + ".docx");
}
function sortForStyle(list, st) { return list.slice().sort((a, b) => sortKey(a).localeCompare(sortKey(b))); }

// ---------- the page ----------
function chatCss() {
  if (document.getElementById("ckChatCss")) return;
  const st = document.createElement("style"); st.id = "ckChatCss";
  st.textContent = `#chatRoot{display:grid;grid-template-columns:230px minmax(0,1fr);gap:0;height:calc(100vh - 150px);min-height:420px;border:1px solid var(--line);border-radius:var(--r);background:var(--surface);overflow:hidden}
.ck-side{border-right:1px solid var(--line);display:flex;flex-direction:column;min-height:0;background:var(--sunk)}
.ck-side .ck-new{margin:10px}
.ck-convs{overflow:auto;flex:1;padding:0 6px 10px}
.ck-conv{display:block;width:100%;text-align:left;border:0;background:transparent;color:var(--ink);padding:8px 10px;border-radius:8px;cursor:pointer;font:inherit}
.ck-conv:hover{background:var(--accent-soft)} .ck-conv[aria-current=true]{background:var(--accent-soft);font-weight:500}
.ck-conv small{display:block;color:var(--muted);font-size:11px;font-weight:400}
.ck-main{display:flex;flex-direction:column;min-width:0;min-height:0}
.ck-head{display:flex;gap:8px;align-items:center;flex-wrap:wrap;padding:10px 14px;border-bottom:1px solid var(--line)}
.ck-head .ck-title{font-family:var(--serif);font-weight:600;font-size:17px;margin-right:auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ck-log{flex:1;overflow:auto;padding:18px max(16px,calc((100% - 760px)/2))}
.ck-msg{margin:0 0 18px} .ck-msg .ck-who{font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);margin-bottom:4px}
.ck-msg.user .ck-body{background:var(--accent-soft);border-radius:12px;padding:10px 14px;white-space:pre-wrap}
.ck-msg.ai .ck-body{font-family:var(--serif);font-size:16px;line-height:1.6} .ck-msg.ai .ck-body p{margin:0 0 .8em}
.ck-mh{font-family:var(--serif);margin:.6em 0 .3em}
.ck-tools{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px;align-items:center}
.ck-unk{text-decoration:underline wavy var(--warn);text-underline-offset:3px}
.ck-comp{border-top:1px solid var(--line);padding:10px 14px;display:grid;gap:6px}
.ck-comp textarea{width:100%;min-height:62px;max-height:40vh;resize:vertical;font:inherit;padding:10px 12px;border:1px solid var(--line);border-radius:10px;background:var(--paper);color:var(--ink)}
.ck-empty{max-width:640px;margin:8vh auto 0;text-align:center}
.ck-empty h2{font-family:var(--serif);font-size:26px;margin:0 0 6px}
.ck-sugg{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin-top:16px}
@media (max-width:760px){#chatRoot{grid-template-columns:1fr;height:auto}.ck-side{display:none}}`;
  document.head.appendChild(st);
}
const CHAT_SUGG = ["Draft a literature review section on ", "Outline a chapter from my sources about ", "Write a thesis statement for a study of ", "Summarize what my sources say about ", "Compare the findings of my sources on ", "Revise this paragraph for clarity:\n\n"];
async function renderChat() {
  const root = document.getElementById("chatRoot"); if (!root) return;
  const keepText = document.getElementById("ckIn") ? document.getElementById("ckIn").value : "";
  chatCss(); await chatLoad();
  if (typeof aiLoad === "function") await aiLoad();
  if (!CHAT.cur || !chatCur()) CHAT.cur = CHAT.list[0] ? CHAT.list[0].id : null;
  const c = chatCur();
  const when = t => { const d = new Date(t), now = new Date(); return d.toDateString() === now.toDateString() ? d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }) : d.toLocaleDateString([], { month: "short", day: "numeric" }); };
  const ready = typeof aiReady === "function" && AI.settings && (AI.settings.provider === "claude" ? AI.settings.hasKey : AI.settings.url);
  root.innerHTML = `<aside class="ck-side"><button class="btn primary ck-new" id="ckNew">New chat</button><div class="ck-convs">${CHAT.list.map(x => `<button class="ck-conv" data-conv="${x.id}" aria-current="${x.id === CHAT.cur}">${esc(x.title)}<small>${when(x.updated)}</small></button>`).join("") || `<p class="note" style="padding:0 10px">Your chats appear here.</p>`}</div></aside>
    <div class="ck-main">
      <div class="ck-head"><span class="ck-title">${esc(c ? c.title : "Write")}</span>
        <button class="btn" id="ckSrc" title="Choose the sources the AI draws on">Sources: ${esc(c ? chatSourceLabel(c) : "No sources")}</button>
        ${c ? `<button class="copy" id="ckRename">Rename</button><button class="copy" id="ckDel">Delete</button>` : ""}
        <span class="note">${ready ? esc(aiLabel()) : ""}</span></div>
      <div class="ck-log" id="ckLog">${!ready ? `<div class="banner" style="margin-bottom:12px">Choose an AI program first: <b>Settings → AI drafting</b>. <button class="btn" id="ckSetup">Open Settings</button></div>` : ""}${c && c.messages.length ? c.messages.map((m, i) => chatMsgHtml(c, m, i)).join("") : `<div class="ck-empty"><h2>What are you writing?</h2><p class="note">Ask for a draft, an outline, a summary or a revision. Click <b>Sources</b> to choose the references the AI draws on: your whole library, a tag, a source kind, or ones you pick.</p><div class="ck-sugg">${CHAT_SUGG.map((s, i) => `<button class="copy" data-sugg="${i}">${esc(s.trim().replace(/:$/, "…"))}${/\s$/.test(s) ? "…" : ""}</button>`).join("")}</div></div>`}</div>
      <div class="ck-comp">${c && (c.files || []).length ? `<div class="row" style="gap:6px">${c.files.map((f, i) => `<span class="chip" title="${esc(f.chars.toLocaleString())} characters">${esc(f.kind)} · ${esc(f.name)} <button class="copy" data-unattach="${i}" aria-label="Remove ${esc(f.name)}" style="padding:0 4px;border:0">✕</button></span>`).join("")}</div>` : ""}<textarea id="ckIn" placeholder="Write a message. Enter sends; Shift+Enter starts a new line." ${CHAT.busy ? "disabled" : ""}></textarea>
        <div class="row" style="justify-content:space-between"><span class="row" style="gap:8px"><button class="copy" id="ckAttach" title="PDF, Word, Excel, PowerPoint or text files; or drop them on the chat">Attach files</button><input type="file" id="ckFile" multiple hidden accept=".pdf,.docx,.xlsx,.pptx,.txt,.md,.csv,.tsv,.json,.html,.htm,.rtf"><span class="note" id="ckStatus"></span></span><span class="row">${CHAT.busy ? `<button class="btn" id="ckStop">Stop</button>` : `<button class="btn primary" id="ckSend">Send</button>`}</span></div></div>
    </div>`;
  const log = $("#ckLog"); log.scrollTop = log.scrollHeight;
  if (keepText && !CHAT.busy) $("#ckIn").value = keepText;
  $("#ckAttach").onclick = () => $("#ckFile").click();
  $("#ckFile").onchange = e => { const f = e.target.files; chatAttach(f); };
  root.querySelectorAll("[data-unattach]").forEach(b => b.onclick = () => { const cc = chatCur(); if (!cc) return; cc.files.splice(+b.dataset.unattach, 1); chatSave(); renderChat(); });
  if (!root.dataset.dropBound) {
    root.dataset.dropBound = "1";
    root.addEventListener("dragover", e => { if (e.dataTransfer && [...(e.dataTransfer.types || [])].includes("Files")) { e.preventDefault(); e.dataTransfer.dropEffect = "copy"; root.style.outline = "2px dashed var(--accent)"; } });
    root.addEventListener("dragleave", e => { if (!root.contains(e.relatedTarget)) root.style.outline = ""; });
    root.addEventListener("drop", e => { if (!e.dataTransfer || !e.dataTransfer.files.length) return; e.preventDefault(); e.stopPropagation(); root.style.outline = ""; if (!CHAT.busy) chatAttach(e.dataTransfer.files); });
  }
  $("#ckNew").onclick = () => { if (CHAT.busy) return; const cur = chatCur(); if (cur && !cur.messages.length) { $("#ckIn").focus(); return; } const n = chatNew(); if (cur) n.sources = Object.assign({}, cur.sources); renderChat().then(() => $("#ckIn").focus()); };
  root.querySelectorAll("[data-conv]").forEach(b => b.onclick = () => { if (CHAT.busy) return; CHAT.cur = b.dataset.conv; renderChat(); });
  root.querySelectorAll("[data-sugg]").forEach(b => b.onclick = () => { const t = $("#ckIn"); t.value = CHAT_SUGG[+b.dataset.sugg]; t.focus(); t.setSelectionRange(t.value.length, t.value.length); });
  const su = $("#ckSetup"); if (su) su.onclick = () => showTab("settings");
  $("#ckSrc").onclick = () => chatPickSources(chatCur() || chatNew());
  const rn = $("#ckRename"); if (rn) rn.onclick = async () => { const t = ((await ckPrompt("Name this chat", c.title)) || "").trim(); if (t) { c.title = t.slice(0, 80); chatSave(); renderChat(); } };
  const dl = $("#ckDel"); if (dl) dl.onclick = async () => { if (!(await ckConfirm(`Delete the chat “${c.title}”?`, { ok: "Delete", danger: true }))) return; CHAT.list = CHAT.list.filter(x => x !== c); CHAT.cur = CHAT.list[0] ? CHAT.list[0].id : null; chatSave(); renderChat(); };
  const inp = $("#ckIn");
  inp.onkeydown = e => { if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); chatSend(); } };
  const sd = $("#ckSend"); if (sd) sd.onclick = () => chatSend();
  const sp = $("#ckStop"); if (sp) sp.onclick = () => { if (CHAT.ctrl) CHAT.ctrl.abort(); };
  log.querySelectorAll("[data-act]").forEach(b => b.onclick = () => chatAct(b.dataset.act, +b.dataset.i));
  log.querySelectorAll("[data-cite]").forEach(b => b.onclick = () => { selectedId = b.dataset.cite; editing = false; showTab("library"); renderAll(); });
}
function chatMsgHtml(c, m, i) {
  if (m.role === "user") return `<div class="ck-msg user"><div class="ck-who">You${(m.files || []).length ? ` · with ${esc(m.files.join(", "))}` : ""}</div><div class="ck-body">${esc(m.content)}</div></div>`;
  const text = chatStrip(m.content);
  const cited = (m.cites || []).map(id => items.find(x => x.id === id)).filter(Boolean);
  const unk = m.unknown || [];
  return `<div class="ck-msg ai" data-msg="${i}"><div class="ck-who">${esc(m.by || "AI")}</div><div class="ck-body">${text ? mdHtml(text, unk) : m.error ? "" : `<p class="note">Thinking…</p>`}</div>
    ${m.error ? `<div class="banner" style="margin:4px 0">${esc(m.error)}</div>` : ""}
    ${m.done ? `<div class="ck-tools"><button class="copy" data-act="copy" data-i="${i}">Copy</button><button class="copy" data-act="word" data-i="${i}">Save as Word</button>${i === c.messages.length - 1 ? `<button class="copy" data-act="again" data-i="${i}">Regenerate</button>` : ""}${cited.length ? `<span class="note">Cites: ${cited.map(it => `<button class="copy" data-cite="${it.id}" title="Show in the Library">${esc(citeForms(it).parenthetical)}</button>`).join(" ")}</span>` : ""}${unk.length ? `<span class="note" title="These citations match nothing in your library">Not in your library: ${esc(unk.join("; "))}</span>` : ""}${m.note ? `<span class="note">${esc(m.note)}</span>` : ""}${m.took ? `<span class="note">${m.took < 60 ? m.took + " s" : Math.floor(m.took / 60) + " min " + (m.took % 60) + " s"}</span>` : ""}</div>` : ""}</div>`;
}
async function chatAct(act, i) {
  const c = chatCur(); if (!c) return; const m = c.messages[i]; if (!m) return;
  const text = chatStrip(m.content);
  if (act === "copy") { copyText(text, mdHtml(text)); return; }
  if (act === "word") { const cited = (m.cites || []).map(id => items.find(x => x.id === id)).filter(Boolean); await chatSaveWord(text, cited, c.title); return; }
  if (act === "again" && !CHAT.busy) { c.messages.splice(i, 1); chatSave(); await chatRun(c); }
}
async function chatSend() {
  if (CHAT.busy) return;
  const inp = $("#ckIn"); const text = (inp.value || "").trim(); if (!text) return; inp.value = "";
  await aiLoad();
  const c = chatCur() || chatNew();
  c.messages.push({ role: "user", content: text, at: Date.now(), files: (c.files || []).map(f => f.name) });
  if (c.title === "New chat") c.title = text.replace(/\s+/g, " ").slice(0, 60) + (text.length > 60 ? "…" : "");
  c.updated = Date.now(); chatSave();
  await chatRun(c);
}
async function chatRun(c) {
  const s = AI.settings;
  const m = { role: "assistant", content: "", at: Date.now(), by: aiLabel() };
  c.messages.push(m); CHAT.busy = true; CHAT.ctrl = new AbortController();
  await renderChat();
  const status = t => { const n = document.getElementById("ckStatus"); if (n) n.textContent = t; };
  const body = () => document.querySelector(`#ckLog [data-msg="${c.messages.indexOf(m)}"] .ck-body`);
  try {
    // room for the sources: the model's context, less the conversation and the reply
    const hist = c.messages.slice(0, -1).map(x => ({ role: x.role === "user" ? "user" : "assistant", content: x.role === "user" ? x.content : chatStrip(x.content) })).filter(x => x.content);
    const histChars = hist.reduce((n, x) => n + x.content.length, 0);
    const total = s.provider === "claude" ? 600000 : Math.floor((s.ctx - 4500) * 3.2);
    let keep = hist; let used = histChars;
    while (keep.length > 1 && used > total * 0.45) { used -= keep[0].content.length; keep = keep.slice(1); }
    if (keep[0] && keep[0].role !== "user") keep = keep.slice(1);
    const ctx = await chatContext(c, Math.max(3000, total - used - 2500), status);
    const sys = chatSystem(c, ctx);
    // progress while waiting: what the program is doing, and for how long
    const words = Math.round((sys.length + keep.reduce((n, x) => n + x.content.length, 0)) / 6);
    const t0 = Date.now(); CHAT.nostream = false;
    const clock = () => { const n = Math.floor((Date.now() - t0) / 1000); return `${Math.floor(n / 60)}:${String(n % 60).padStart(2, "0")}`; };
    const phase = () => {
      const raw = m.content, shown = chatStrip(raw), name = aiProv(s).name && s.provider !== "claude" ? aiProv(s).name : "Claude";
      if (shown) return `Writing… ${clock()}`;
      if (/<think>/i.test(raw)) return `${name} is thinking before it writes… ${clock()}`;
      return CHAT.nostream ? `Waiting for ${name}'s whole answer (it doesn't send answers word by word)… ${clock()}` : `Waiting for ${name} to read ${words.toLocaleString()} words${words > 4000 ? ", which can take a few minutes on a local model" : ""}… ${clock()}`;
    };
    const tick = setInterval(() => { status(phase()); const b = body(); if (b && !chatStrip(m.content)) b.innerHTML = `<p class="note">${esc(phase())}</p>`; }, 1000);
    status(phase());
    let last = 0;
    try { await chatStream(sys, keep, CHAT.ctrl.signal, raw => {
      m.content = raw;
      if (Date.now() - last > 80) { last = Date.now(); const b = body(); if (b) { const t = chatStrip(raw); b.innerHTML = t ? mdHtml(t) : `<p class="note">${esc(phase())}</p>`; const log = $("#ckLog"); if (log && log.scrollHeight - log.scrollTop - log.clientHeight < 160) log.scrollTop = log.scrollHeight; } }
    }); } finally { clearInterval(tick); m.took = Math.round((Date.now() - t0) / 1000); }
    if (!chatStrip(m.content)) m.error = "The AI program sent back an empty answer. Try again, or try another model.";
    const notes = [];
    if (ctx.n && ctx.withText < chatSourceItems(c).filter(itemPdfLocal).length && (c.sources || {}).text !== false) notes.push(`Text of ${ctx.withText} of ${chatSourceItems(c).filter(itemPdfLocal).length} linked files fit; the rest were sent as references and matrix notes`);
    if (keep.length < hist.length) notes.push("The earliest messages were left out to make room");
    if (ctx.filesCut) notes.push(`${ctx.filesCut} attached file${ctx.filesCut === 1 ? " was" : "s were"} too long to send whole; the middle was left out`);
    m.note = notes.join(". ");
  } catch (e) {
    if (e.name === "AbortError") { m.note = "Stopped"; if (!chatStrip(m.content)) m.error = "Stopped before any answer."; }
    else m.error = e.message || "The AI program didn't answer.";
  }
  const t = chatStrip(m.content);
  m.cites = t ? chatCites(t, c).map(x => x.id) : []; m.unknown = t ? chatUnknownCites(t) : [];
  m.done = true; CHAT.busy = false; CHAT.ctrl = null; c.updated = Date.now();
  chatSave(true); await renderChat();
  const inp = $("#ckIn"); if (inp && !$("#tab-write").hidden) inp.focus();
}

// ---------- choosing sources ----------
function chatPickSources(c) {
  const S = Object.assign({ mode: "none", text: true }, c.sources || {});
  const tags = typeof tagTree === "function" ? tagTree() : allTags();
  const box = document.createElement("div"); box.className = "modal-back"; box.dataset.esc = "1"; box.id = "ckSrcBox";
  const picked = new Set(S.ids || []);
  const draw = () => {
    const n = chatSourceItems({ sources: S }).length;
    box.innerHTML = `<div class="modal" role="dialog" aria-modal="true" style="max-width:720px;max-height:86vh;overflow:auto">
      <div class="row" style="justify-content:space-between"><h2 style="margin:0">Sources for this chat</h2><button class="copy" data-x>Cancel</button></div>
      <p class="note">The AI gets each source's reference and your matrix notes, and, if ticked, as much of the linked files' text as fits in its context.</p>
      <div style="display:grid;gap:6px">${Object.keys(SRC_MODES).map(k => `<label class="row" style="gap:8px"><input type="radio" name="ckMode" value="${k}" ${S.mode === k ? "checked" : ""}> ${esc(SRC_MODES[k])}
        ${k === "tag" ? `<select data-f="tag" ${S.mode !== "tag" ? "disabled" : ""}><option value="">Choose a tag</option>${tags.map(t => `<option ${t === S.tag ? "selected" : ""}>${esc(t)}</option>`).join("")}</select>` : ""}
        ${k === "kind" ? `<select data-f="kind" ${S.mode !== "kind" ? "disabled" : ""}><option value="">Choose a kind</option>${SRC_KINDS.map(x => `<option value="${x.id}" ${x.id === S.kind ? "selected" : ""}>${esc(x.name)}</option>`).join("")}</select>` : ""}
        ${k === "role" ? `<select data-f="role" ${S.mode !== "role" ? "disabled" : ""}><option value="">${ROLES.length ? "Choose a category" : "No categories yet"}</option>${ROLES.map(x => `<option value="${esc(x.id)}" ${x.id === S.role ? "selected" : ""}>${esc(x.name)}</option>`).join("")}</select>` : ""}</label>`).join("")}</div>
      ${S.mode === "pick" ? `<input type="search" id="ckPickQ" placeholder="Search your library" style="margin-top:8px;width:100%"><div id="ckPickList" style="max-height:38vh;overflow:auto;border:1px solid var(--line);border-radius:8px;margin-top:6px"></div>` : ""}
      <label class="row" style="gap:8px;margin-top:10px"><input type="checkbox" id="ckText" ${S.text !== false ? "checked" : ""}> Include the text of linked files (as much as fits)</label>
      <div class="row" style="justify-content:space-between;margin-top:12px"><span class="note">${n} reference${n === 1 ? "" : "s"}${n && S.text !== false ? `, ${chatSourceItems({ sources: S }).filter(itemPdfLocal).length} with a linked file` : ""}</span><button class="btn primary" data-ok>Use these sources</button></div></div>`;
    const pl = box.querySelector("#ckPickList");
    if (pl) {
      const q = box.querySelector("#ckPickQ");
      const list = () => { const w = (q.value || "").toLowerCase().split(/\s+/).filter(Boolean); pl.innerHTML = sorted().filter(it => { const h = (citeForms(it).parenthetical + " " + (it.title || "") + " " + (it.tags || []).join(" ")).toLowerCase(); return w.every(x => h.includes(x)); }).slice(0, 400).map(it => `<label class="row" style="gap:8px;padding:5px 8px;border-bottom:1px solid var(--line);flex-wrap:nowrap"><input type="checkbox" data-pk="${it.id}" ${picked.has(it.id) ? "checked" : ""}><span style="min-width:0"><span>${esc(citeForms(it).parenthetical)}</span> <span class="note">${esc((it.title || "").slice(0, 90))}</span></span></label>`).join(""); pl.querySelectorAll("[data-pk]").forEach(cb => cb.onchange = () => { cb.checked ? picked.add(cb.dataset.pk) : picked.delete(cb.dataset.pk); S.ids = [...picked]; const nn = box.querySelector(".modal > .row:last-child .note"); if (nn) nn.textContent = `${picked.size} reference${picked.size === 1 ? "" : "s"}`; }); };
      q.oninput = list; list();
    }
  };
  draw(); document.body.appendChild(box);
  box.addEventListener("change", e => {
    const t = e.target;
    if (t.name === "ckMode") { S.mode = t.value; draw(); }
    else if (t.dataset && t.dataset.f) { S[t.dataset.f] = t.value; draw(); }
    else if (t.id === "ckText") { S.text = t.checked; draw(); }
  });
  box.addEventListener("click", e => {
    if (e.target === box || e.target.closest("[data-x]")) { box.remove(); return; }
    if (e.target.closest("[data-ok]")) { S.ids = [...picked]; c.sources = S; c.updated = Date.now(); chatSave(); box.remove(); renderChat(); }
  });
}

// ---------- wiring ----------
{ const st = showTab; showTab = function (name) { st(name); if (name === "write") renderChat(); }; }
(function () {
  const go = () => { if (!$("#tab-write").hidden) renderChat(); };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", go); else setTimeout(go, 80);
})();
