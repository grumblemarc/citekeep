// ===== The Citekeep password: it encrypts your keys (Claude API key, Google sign-in, local AI key) and is asked for
// when Citekeep opens. A recovery code also unlocks them. Your library is never locked, so nothing else depends on it. =====
var LOCK = { enabled: false, unlocked: false };
const LOCK_MIN = 8;
const LOGO = '<svg width="40" height="40" viewBox="0 0 512 512" aria-hidden="true"><rect x="16" y="16" width="480" height="480" rx="108" fill="#2C6A4E"/><path d="M120 420 V170 H162 V120 H210 V170 H232 V120 H280 V170 H302 V120 H350 V170 H392 V420 Z" fill="#F4F5F1"/><path d="M214 420 V320 a42 42 0 0 1 84 0 V420 Z" fill="#2C6A4E"/></svg>';

function lockModal(html, opaque) {
  const box = document.createElement("div");
  box.className = "modal-back"; if (opaque) box.style.background = "var(--paper)";
  box.innerHTML = `<div class="modal" role="dialog" aria-modal="true" style="max-width:420px">${html}</div>`;
  document.body.appendChild(box);
  return box;
}
function pwFields(prefix) {
  return `<label class="f"><span>${prefix || "Password"}</span><input type="password" id="lkP1" autocomplete="new-password"></label>
    <label class="f"><span>Type it again</span><input type="password" id="lkP2" autocomplete="new-password"></label>
    <p class="note" style="margin:0">At least ${LOCK_MIN} characters. A short sentence is easy to remember and hard to guess.</p>`;
}
function pwCheck(box) {
  const a = box.querySelector("#lkP1").value, b = box.querySelector("#lkP2").value;
  if (a.length < LOCK_MIN) return `Use at least ${LOCK_MIN} characters.`;
  if (a !== b) return "The two passwords don't match.";
  return "";
}
// the recovery code, shown once
function showCode(code, then) {
  const box = lockModal(`<h2 style="margin:0 0 6px">Your recovery code</h2>
    <p style="margin:0 0 10px">If you forget your password, this code unlocks your keys instead. It's shown only now. Print it or save it somewhere safe, away from this computer.</p>
    <div style="font-family:var(--mono);font-size:clamp(13px,4.2vw,17px);letter-spacing:.02em;white-space:nowrap;overflow-x:auto;text-align:center;padding:12px;border:1px dashed var(--line);border-radius:var(--r);background:var(--sunk);user-select:all">${esc(code)}</div>
    <div class="row" style="margin-top:10px"><button class="btn" id="lkCopy">Copy</button><button class="btn" id="lkSave">Save as a text file</button></div>
    <label class="note" style="display:flex;gap:6px;align-items:center;margin-top:12px"><input type="checkbox" id="lkSaved">I've saved my recovery code</label>
    <div class="row" style="margin-top:12px;justify-content:flex-end"><button class="btn primary" id="lkDone" disabled>Done</button></div>`);
  box.querySelector("#lkCopy").onclick = async () => { try { await navigator.clipboard.writeText(code); toast("Copied"); } catch (e) { toast("Select the code and copy it"); } };
  box.querySelector("#lkSave").onclick = async () => {
    const text = `Citekeep recovery code\r\n\r\n${code}\r\n\r\nThis code unlocks your Citekeep keys if you forget your password.\r\nKeep it somewhere safe. Saved ${new Date().toLocaleDateString()}.\r\n`;
    try { const where = await window.citekeepApp.saveFile("Citekeep recovery code.txt", new TextEncoder().encode(text)); if (where) { toast("Saved"); window.citekeepApp.showFile(where); } } catch (e) { toast("Couldn't save the file. Copy the code instead."); }
  };
  box.querySelector("#lkSaved").onchange = e => { box.querySelector("#lkDone").disabled = !e.target.checked; };
  box.querySelector("#lkDone").onclick = () => { box.remove(); if (then) then(); };
}

// ---------- at startup ----------
async function lockStartup() {
  try { Object.assign(LOCK, await window.citekeepApp.lockStatus()); } catch (e) { return; }
  if (LOCK.enabled && !LOCK.unlocked) lockScreen();
  if (document.getElementById("dataCard")) renderDataCard();
}
function lockScreen() {
  const box = lockModal(`<div style="display:flex;gap:12px;align-items:center;margin-bottom:10px">${LOGO}<div><h2 style="margin:0">Citekeep is locked</h2><div class="note">Enter your Citekeep password.</div></div></div>
    <div id="lkMode">
      <label class="f"><span>Password</span><input type="password" id="lkPw" autocomplete="current-password"></label>
      <div class="row" style="margin-top:10px"><button class="btn primary" id="lkGo">Unlock</button><span class="note" id="lkMsg" role="alert"></span></div>
    </div>
    <div class="row" style="margin-top:14px;justify-content:space-between"><button class="copy" id="lkUseCode">Use my recovery code</button><button class="copy" id="lkForgot">Forgot both?</button></div>`, true);
  const msg = t => { box.querySelector("#lkMsg").textContent = t; };
  const go = async () => {
    const pw = box.querySelector("#lkPw").value; if (!pw) return;
    msg("Unlocking…"); box.querySelector("#lkGo").disabled = true;
    const ok = await window.citekeepApp.unlock(pw);
    box.querySelector("#lkGo").disabled = false;
    if (!ok) { msg("That password didn't work."); box.querySelector("#lkPw").select(); return; }
    location.reload();
  };
  box.querySelector("#lkGo").onclick = go;
  box.querySelector("#lkPw").onkeydown = e => { if (e.key === "Enter") go(); };
  setTimeout(() => box.querySelector("#lkPw").focus(), 50);
  box.querySelector("#lkUseCode").onclick = () => {
    box.querySelector("#lkMode").innerHTML = `<label class="f"><span>Recovery code</span><input type="text" id="lkCode" placeholder="KEEP-XXXX-XXXX-XXXX-XXXX-XXXX" autocomplete="off" spellcheck="false" style="font-family:var(--mono)"></label>
      <div class="row" style="margin-top:10px"><button class="btn primary" id="lkCodeGo">Unlock</button><span class="note" id="lkMsg" role="alert"></span></div>`;
    const cgo = async () => {
      const c = box.querySelector("#lkCode").value; if (!c.trim()) return;
      msg("Unlocking…");
      if (!(await window.citekeepApp.unlockWithCode(c))) { msg("That code didn't work."); return; }
      // in with the code: choose a new password now
      box.querySelector(".modal").innerHTML = `<h2 style="margin:0 0 6px">Choose a new password</h2><p class="note" style="margin:0 0 10px">Your recovery code still works afterward.</p>${pwFields("New password")}
        <div class="row" style="margin-top:10px"><button class="btn primary" id="lkNew">Save password</button><span class="note" id="lkMsg2" role="alert"></span></div>`;
      box.querySelector("#lkNew").onclick = async () => { const bad = pwCheck(box); if (bad) { box.querySelector("#lkMsg2").textContent = bad; return; } await window.citekeepApp.setPassword(box.querySelector("#lkP1").value); location.reload(); };
    };
    box.querySelector("#lkCodeGo").onclick = cgo;
    box.querySelector("#lkCode").onkeydown = e => { if (e.key === "Enter") cgo(); };
    box.querySelector("#lkCode").focus();
  };
  box.querySelector("#lkForgot").onclick = () => {
    box.querySelector(".modal").innerHTML = `<h2 style="margin:0 0 6px">Start over with your keys</h2>
      <p style="margin:0 0 8px">Without the password or the recovery code, the saved keys can't be unlocked by anyone. Citekeep can clear them and turn the password off:</p>
      <ul class="stylist" style="margin:0 0 8px;padding-left:20px"><li>You'll sign in to Google Drive again and paste your Claude API key again (Settings).</li><li>Your library, matrix, PDFs, claim checks and settings are not affected.</li><li>If the library is shared, the other computer will need this too.</li></ul>
      <div class="row" style="margin-top:10px;justify-content:space-between"><button class="copy" id="lkBack">Go back</button><button class="btn danger" id="lkReset">Clear my keys</button></div>`;
    box.querySelector("#lkBack").onclick = () => { box.remove(); lockScreen(); };
    box.querySelector("#lkReset").onclick = async () => { await window.citekeepApp.resetKeys(); location.reload(); };
  };
}

// ---------- in Settings → Your Citekeep data ----------
function lockSectionHtml() {
  if (!window.citekeepApp || !window.citekeepApp.lockStatus) return "";
  return `<details id="lkSection" ${LOCK.enabled ? "" : ""}><summary class="note" style="cursor:pointer">Citekeep password${LOCK.enabled ? ": on" : ""}</summary>
    ${LOCK.enabled ? `<p class="note">Your Claude API key, Google sign-in and local AI key are encrypted with your password, and Citekeep asks for it when it opens. Computers sharing this library unlock them with the same password.</p>
      <div class="row"><button class="btn" id="lkChange">Change password</button><button class="btn" id="lkCodeNew">New recovery code</button><button class="btn" id="lkLock">Lock now</button><button class="copy" id="lkOff">Turn off</button></div>`
    : `<p class="note">Protect your Claude API key, Google sign-in and local AI key with a password. They're stored encrypted, so they're safe even in a shared Google Drive folder, and Citekeep asks for the password when it opens. Your library itself isn't locked. Without a password, keys stay on this computer only.</p>
      <div class="row"><button class="btn" id="lkOn">Set a password</button></div>`}</details>`;
}
// ask for the current password before changing anything
function lockConfirm(title, then) {
  const box = lockModal(`<h2 style="margin:0 0 10px">${esc(title)}</h2><label class="f"><span>Current password</span><input type="password" id="lkCur" autocomplete="current-password"></label>
    <div class="row" style="margin-top:10px;justify-content:space-between"><button class="copy" id="lkX">Cancel</button><span class="note" id="lkMsg" role="alert"></span><button class="btn primary" id="lkOk">Continue</button></div>`);
  const ok = async () => { if (!(await window.citekeepApp.checkPassword(box.querySelector("#lkCur").value))) { box.querySelector("#lkMsg").textContent = "That password didn't work."; return; } box.remove(); then(); };
  box.querySelector("#lkOk").onclick = ok; box.querySelector("#lkCur").onkeydown = e => { if (e.key === "Enter") ok(); };
  box.querySelector("#lkX").onclick = () => box.remove();
  setTimeout(() => box.querySelector("#lkCur").focus(), 50);
}
function lockNewPassword(title, intro, done) {
  const box = lockModal(`<h2 style="margin:0 0 6px">${esc(title)}</h2>${intro ? `<p class="note" style="margin:0 0 10px">${intro}</p>` : ""}${pwFields()}
    <div class="row" style="margin-top:10px;justify-content:space-between"><button class="copy" id="lkX">Cancel</button><span class="note" id="lkMsg" role="alert"></span><button class="btn primary" id="lkOk">Save password</button></div>`);
  box.querySelector("#lkX").onclick = () => box.remove();
  box.querySelector("#lkOk").onclick = async () => {
    const bad = pwCheck(box); if (bad) { box.querySelector("#lkMsg").textContent = bad; return; }
    box.querySelector("#lkMsg").textContent = "Saving…";
    const r = await window.citekeepApp.setPassword(box.querySelector("#lkP1").value);
    box.remove(); done(r);
  };
  setTimeout(() => box.querySelector("#lkP1").focus(), 50);
}
function lockBind() {
  const q = id => document.getElementById(id);
  const refresh = async () => { Object.assign(LOCK, await window.citekeepApp.lockStatus()); renderDataCard(); const s = q("lkSection"); if (s) s.open = true; };
  if (q("lkOn")) q("lkOn").onclick = () => lockNewPassword("Set a Citekeep password", "You'll enter it each time Citekeep opens. On a computer that shares this library, use the same password.", code => showCode(code, () => { toast("Password set. Your keys are encrypted."); refresh(); }));
  if (q("lkChange")) q("lkChange").onclick = () => lockConfirm("Change your password", () => lockNewPassword("Choose a new password", "Your recovery code stays the same.", () => { toast("Password changed"); refresh(); }));
  if (q("lkCodeNew")) q("lkCodeNew").onclick = () => lockConfirm("Make a new recovery code", async () => { const code = await window.citekeepApp.newRecoveryCode(); if (code) showCode(code, () => toast("The old recovery code no longer works.")); });
  if (q("lkLock")) q("lkLock").onclick = async () => { if (window.citekeepFlush) await window.citekeepFlush(); await window.citekeepApp.lockNow(); location.reload(); };
  if (q("lkOff")) q("lkOff").onclick = () => lockConfirm("Turn off the password", async () => { await window.citekeepApp.removePassword(); toast("Password off. Your keys are kept on this computer only."); refresh(); });
}
{ const rdc = renderDataCard; renderDataCard = function () { rdc(); const c = document.getElementById("dataCard"); if (!c || !window.citekeepApp || !window.citekeepApp.lockStatus) return; const s = c.querySelector("details"); const html = lockSectionHtml(); if (s) s.insertAdjacentHTML("afterend", html); else c.insertAdjacentHTML("beforeend", html); lockBind(); }; }
(function () { const go = () => lockStartup(); if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", go); else go(); })();
